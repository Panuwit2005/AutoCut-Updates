"""Speech-to-text: word timings for smarter cutting + text for subtitles.

Runs faster-whisper to get **word-level timestamps + VAD speech boundaries**,
which let the cutter:
  • keep whole words (cut only in the gaps between words — never mid-word),
  • trim dead air precisely, and
  • pick the parts where someone is actually talking,
and gives the caption module accurate Thai/English text to burn in.

The ONE model for the whole app is **th-large-v2** (Thonburian Whisper — a Thai
fine-tune of Whisper large-v2, biodatlab, CT2-converted; bundled for fully-offline
use) — the most accurate Thai word capture, used for BOTH cut timing and subtitle
text.  If the model/engine isn't available the pipeline falls back to ffmpeg
silence detection, so a job never fails for lack of AI.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Word:
    start: float
    end: float
    text: str


@dataclass
class Segment:
    start: float
    end: float
    text: str
    words: list[Word] = field(default_factory=list)


@dataclass
class Transcript:
    segments: list[Segment]
    language: str = ""
    engine: str = ""

    @property
    def words(self) -> list[Word]:
        out: list[Word] = []
        for s in self.segments:
            out.extend(s.words)
        return out


class TranscribeUnavailable(RuntimeError):
    """No working speech-to-text engine is available."""


_FW_MODELS: dict[str, object] = {}


# Aliases for models that aren't in faster-whisper's built-in registry.
# "th-large-v2" = Thonburian Whisper (biodatlab Thai fine-tune, CT2 conversion).
_MODEL_ALIASES = {
    "th-large-v2": "mort666/faster-whisper-large-v2-th",
}


def _model(model_size: str):
    if model_size in _FW_MODELS:
        return _FW_MODELS[model_size]
    import os
    from faster_whisper import WhisperModel  # may raise ImportError
    from . import tools
    # Prefer a bundled local copy so both the built app AND the dev server run
    # fully offline (no download).  Candidates in priority order:
    #   <bundle>/models/faster-whisper-<size>            (frozen app)
    #   <repo>/packaging/payload/models/faster-whisper-<size>  (running from source)
    # Fall back to the model name / HF repo id (downloaded once) only if neither.
    here = os.path.dirname(os.path.abspath(__file__))
    cands = [
        os.path.join(tools.bundle_dir(), "models", f"faster-whisper-{model_size}"),
        os.path.join(os.path.dirname(here), "packaging", "payload", "models",
                     f"faster-whisper-{model_size}"),
    ]
    src = next((c for c in cands if os.path.isdir(c)),
               _MODEL_ALIASES.get(model_size, model_size))
    m = WhisperModel(src, device="cpu", compute_type="int8",
                     cpu_threads=min(os.cpu_count() or 4, 8))   # use the cores → faster
    _FW_MODELS[model_size] = m
    return m


def transcribe(path: str, *, language: str = "th", model_size: str = "small",
               log=None) -> Transcript:
    """Return a :class:`Transcript` with word timings, or raise on failure."""
    try:
        model = _model(model_size)
    except ImportError as e:
        raise TranscribeUnavailable(f"faster-whisper not installed ({e})") from e
    if log:
        log("🤖 AI กำลังวิเคราะห์เสียง (เบื้องหลัง)…")
    try:
        segments_iter, info = model.transcribe(
            path,
            language=language or None,
            word_timestamps=True,        # precise word boundaries → no clipped words
            beam_size=1,                 # greedy = ~1.5-2x faster; Gemini fixes wording
            vad_filter=True,             # Silero VAD → accurate speech regions
            # Smaller min-silence + speech padding so trailing/quiet speech at the
            # END of a clip isn't trimmed away ("ตอนท้ายพูดอยู่แต่ไม่จับคำ").
            vad_parameters={"min_silence_duration_ms": 250, "speech_pad_ms": 400},
            condition_on_previous_text=False,
            no_speech_threshold=0.45,    # keep quieter speech (was 0.6)
        )
        segments: list[Segment] = []
        for seg in segments_iter:
            words = [Word(float(w.start), float(w.end), w.word)
                     for w in (seg.words or [])
                     if w.start is not None and w.end is not None]
            segments.append(Segment(float(seg.start), float(seg.end),
                                    (seg.text or "").strip(), words))
    except Exception as e:  # noqa: BLE001
        raise TranscribeUnavailable(str(e)) from e
    return Transcript(segments, getattr(info, "language", language) or language,
                      f"faster-whisper:{model_size}")


def available() -> bool:
    try:
        import faster_whisper  # noqa: F401
        return True
    except ImportError:
        return False
