"""Cut, concatenate and mix audio with ffmpeg.

Because every source has already been run through :mod:`media.normalize`, all
clips share one codec / fps / resolution / sample rate.  That makes the editing
operations here simple and reliable: cuts re-encode from the canonical format,
and concatenation uses the ffmpeg ``concat`` filter (which re-encodes) so there
are never timestamp or parameter mismatches at the seams.

The L-cut / J-cut hook lives in :func:`concat` (``audio_overlap``): when it is
positive the audio of adjacent clips is cross-laid across each seam so it
overlaps the visual cut, giving professional-feeling transitions.  The graph is
built defensively — if anything in the L/J path fails it falls back to the plain
``concat`` so a job is never lost to a fancy transition.
"""

from __future__ import annotations

import os

from . import tools
from .analyze import Clip

# Final-delivery container/codec settings.
FORMATS = {
    "mp4":  {"v": ["libx264"], "a": ["aac"],        "extra": ["-movflags", "+faststart"]},
    "mov":  {"v": ["libx264"], "a": ["aac"],        "extra": []},
    "avi":  {"v": ["mpeg4", "-q:v", "5"], "a": ["libmp3lame"], "extra": []},
    "webm": {"v": ["libvpx-vp9", "-b:v", "0", "-crf", "32"], "a": ["libopus"], "extra": []},
}
MIME = {
    "mp4": "video/mp4", "mov": "video/quicktime",
    "avi": "video/x-msvideo", "webm": "video/webm",
}


def fmt_settings(fmt: str) -> dict:
    return FORMATS.get(fmt, FORMATS["mp4"])


def _venc(fmt: str, crf: int | None = None) -> list[str]:
    s = fmt_settings(fmt)
    out = ["-c:v", *s["v"]]
    # Quality is configurable only for the H.264 formats; AVI/WEBM keep the
    # rate-control baked into FORMATS.  Default 20 preserves prior behaviour.
    if fmt in ("mp4", "mov"):
        out += ["-crf", str(crf if crf is not None else 20)]
    # ALWAYS deliver 8-bit 4:2:0.  x264 follows the source's bit depth, so a
    # 10-bit phone/camera clip would otherwise stay "High 10" — which a browser
    # <video> renders as a BLACK screen (and many players choke on).
    out += ["-pix_fmt", "yuv420p"]
    return out


def _aenc(fmt: str) -> list[str]:
    s = fmt_settings(fmt)
    return ["-c:a", *s["a"]]


# ---------------------------------------------------------------------------
# Cutting
# ---------------------------------------------------------------------------
def cut_clip(src: str, clip: Clip, dst: str, *, fmt: str = "mp4",
             crf: int | None = None, log=None) -> str | None:
    """Extract [clip.start, clip.end] from *src* into *dst*. Returns dst or None."""
    dur = clip.duration
    if dur <= 0:
        return None
    args = [
        "-y", "-ss", f"{clip.start:.3f}", "-i", src, "-t", f"{dur:.3f}",
        "-map", "0:v:0", "-map", "0:a:0?",
        *_venc(fmt, crf),
        "-preset", "veryfast" if fmt in ("mp4", "mov") else "good",
        "-pix_fmt", "yuv420p",
        *_aenc(fmt), "-ar", "48000", "-ac", "2",
        "-avoid_negative_ts", "make_zero", "-reset_timestamps", "1",
        *fmt_settings(fmt)["extra"],
        dst,
    ]
    try:
        tools.ffmpeg(args, check=True, log=log, timeout=1800)
    except tools.ToolError as e:
        if log:
            log(f"⚠️ cut failed ({os.path.basename(dst)}): {e}")
        return None
    if os.path.exists(dst) and os.path.getsize(dst) > 1024:
        return dst
    return None


def cut_clips(src: str, clips: list[Clip], out_dir: str, *, prefix: str = "clip",
              fmt: str = "mp4", crf: int | None = None, log=None) -> list[str]:
    paths = []
    for i, clip in enumerate(clips, 1):
        dst = os.path.join(out_dir, f"{prefix}_{i:02d}.{fmt}")
        result = cut_clip(src, clip, dst, fmt=fmt, crf=crf, log=log)
        if result:
            paths.append(result)
            if log:
                log(f"  ✂️ {prefix}_{i:02d}: {clip.start:.1f}s→{clip.end:.1f}s")
    return paths


# ---------------------------------------------------------------------------
# Concatenation
# ---------------------------------------------------------------------------
def concat(clip_paths: list[str], dst: str, *, fmt: str = "mp4",
           max_duration: float | None = None, audio_overlap: float = 0.0,
           lj_mode: str = "l", crf: int | None = None, log=None) -> str:
    """Concatenate clips into one file (re-encode).

    With ``audio_overlap <= 0`` this is a plain hard-cut concat.  With
    ``audio_overlap > 0`` and at least two clips it performs a real **L-cut /
    J-cut**: the video is still hard-cut, but the audio of adjacent clips is
    cross-laid across each seam so it overlaps the visual cut by
    ``audio_overlap`` seconds.

    * ``lj_mode='l'`` — the *current* clip's audio keeps ringing over the next
      clip's picture (audio lags the cut).
    * ``lj_mode='j'`` — the *next* clip's audio comes in under the current
      picture (audio leads the cut).

    If the L/J graph fails for any reason it degrades to :func:`_concat_plain`,
    so a fancy transition can never lose a job.
    """
    if not clip_paths:
        raise tools.ToolError("concat: no clips")
    if len(clip_paths) == 1:
        return _reencode(clip_paths[0], dst, fmt=fmt, max_duration=max_duration,
                         crf=crf, log=log)

    if audio_overlap and audio_overlap > 0:
        try:
            return _concat_lj(clip_paths, dst, fmt=fmt, max_duration=max_duration,
                              overlap=audio_overlap, mode=lj_mode, crf=crf, log=log)
        except tools.ToolError as e:
            if log:
                log(f"⚠️ L/J cut ไม่สำเร็จ — ใช้การต่อแบบปกติแทน: {e}")

    return _concat_plain(clip_paths, dst, fmt=fmt, max_duration=max_duration,
                         crf=crf, log=log)


def _concat_plain(clip_paths: list[str], dst: str, *, fmt: str = "mp4",
                  max_duration: float | None = None, crf: int | None = None,
                  log=None) -> str:
    """Hard-cut concatenation via the ffmpeg ``concat`` filter."""
    inputs: list[str] = []
    for p in clip_paths:
        inputs += ["-i", p]
    n = len(clip_paths)
    streams = "".join(f"[{i}:v:0][{i}:a:0]" for i in range(n))
    filtergraph = f"{streams}concat=n={n}:v=1:a=1[v][a]"

    args = ["-y", *inputs, "-filter_complex", filtergraph,
            "-map", "[v]", "-map", "[a]",
            *_venc(fmt, crf), *_aenc(fmt), "-ar", "48000", "-ac", "2"]
    if max_duration:
        args += ["-t", f"{max_duration:.3f}"]
    args += [*fmt_settings(fmt)["extra"], dst]
    tools.ffmpeg(args, check=True, log=log, timeout=3600)
    return dst


def _duration(path: str) -> float:
    """Best-effort container duration in seconds (0.0 if unknown)."""
    try:
        res = tools.ffprobe([
            "-v", "quiet", "-show_entries", "format=duration",
            "-of", "default=nokey=1:noprint_wrappers=1", path,
        ])
        return float((res.stdout or "").strip() or 0.0)
    except (tools.ToolError, ValueError):
        return 0.0


def _concat_lj(clip_paths: list[str], dst: str, *, fmt: str, overlap: float,
               mode: str = "l", max_duration: float | None = None,
               crf: int | None = None, log=None) -> str:
    """Concatenate with an L-cut / J-cut audio bleed across every seam.

    The video is hard-cut, with each clip trimmed by ``overlap`` on the side the
    neighbour's picture takes over; the audio is cross-faded with ``acrossfade``
    so it spans the cut.  Both video and audio shorten by exactly ``overlap`` per
    seam, so they stay frame-aligned with no cumulative drift — only the seam
    itself carries the intentional audio/picture offset that *is* the L/J cut.
    """
    n = len(clip_paths)
    mode = "j" if str(mode).lower().startswith("j") else "l"

    durs = [_duration(p) for p in clip_paths]
    if any(d <= 0 for d in durs):
        raise tools.ToolError("L/J: could not read clip durations")
    # Keep the overlap safely shorter than the shortest clip so every trim and
    # cross-fade has material to work with (acrossfade needs each input >= d).
    v = min(overlap, min(durs) * 0.45)
    if v < 0.05:
        raise tools.ToolError("L/J: clips too short for an audio overlap")

    inputs: list[str] = []
    for p in clip_paths:
        inputs += ["-i", p]

    chains: list[str] = []

    # --- video: hard cuts, each clip trimmed on the overlapped side ----------
    vlabels: list[str] = []
    for i, d in enumerate(durs):
        lbl = f"v{i}"
        vlabels.append(f"[{lbl}]")
        if mode == "l" and i < n - 1:
            # L-cut: this clip's picture ends early; the next clip covers the seam.
            chains.append(f"[{i}:v:0]trim=0:{d - v:.3f},setpts=PTS-STARTPTS[{lbl}]")
        elif mode == "j" and i > 0:
            # J-cut: this clip's picture starts late; the previous clip held the seam.
            chains.append(f"[{i}:v:0]trim={v:.3f}:{d:.3f},setpts=PTS-STARTPTS[{lbl}]")
        else:
            chains.append(f"[{i}:v:0]setpts=PTS-STARTPTS[{lbl}]")
    chains.append(f"{''.join(vlabels)}concat=n={n}:v=1:a=0[v]")

    # --- audio: cross-fade every seam by v seconds (overlaps the visual cut) --
    prev = "[0:a:0]"
    for i in range(1, n):
        out = "[a]" if i == n - 1 else f"[ax{i}]"
        chains.append(f"{prev}[{i}:a:0]acrossfade=d={v:.3f}:c1=tri:c2=tri{out}")
        prev = out

    filtergraph = ";".join(chains)
    args = ["-y", *inputs, "-filter_complex", filtergraph,
            "-map", "[v]", "-map", "[a]",
            *_venc(fmt, crf), *_aenc(fmt), "-ar", "48000", "-ac", "2"]
    if max_duration:
        args += ["-t", f"{max_duration:.3f}"]
    args += [*fmt_settings(fmt)["extra"], dst]
    if log:
        log(f"🎞 L/J cut ({mode.upper()}-cut, overlap {v:.2f}s, {n} clips)")
    tools.ffmpeg(args, check=True, log=log, timeout=3600)
    return dst


# A browser <video> decodes only 8-bit 4:2:0 H.264.  "High 10" (yuv420p10le),
# 4:2:2 and 4:4:4 all report codec_name=h264 but play as a BLACK screen, so the
# pixel format — not just the codec name — decides whether we can stream-copy.
_WEB_PIX_FMTS = {"yuv420p", "yuvj420p"}


def web_playable(path: str) -> bool:
    """True when a browser can play *path* as-is (→ safe to remux, no re-encode)."""
    try:
        res = tools.ffprobe([
            "-v", "error", "-select_streams", "v:0",
            "-show_entries", "stream=codec_name,pix_fmt",
            "-of", "default=noprint_wrappers=1:nokey=1", path,
        ])
        v = [ln.strip() for ln in (res.stdout or "").splitlines() if ln.strip()]
        if len(v) < 2 or v[0] != "h264" or v[1] not in _WEB_PIX_FMTS:
            return False
        res = tools.ffprobe([
            "-v", "error", "-select_streams", "a:0",
            "-show_entries", "stream=codec_name",
            "-of", "default=noprint_wrappers=1:nokey=1", path,
        ])
        audio = (res.stdout or "").strip().splitlines()
        return not audio or audio[0].strip() in ("", "aac")
    except tools.ToolError:
        return False


def remux(src: str, dst: str, *, log=None) -> str:
    """Repackage *src* into an mp4 WITHOUT re-encoding (stream copy) — near-instant.

    Only safe when the source is already browser-friendly (h264 video + aac/none
    audio); the caller checks that.  ``+faststart`` moves the moov atom to the
    front so the editor preview starts playing immediately.
    """
    args = ["-y", "-i", src, "-map", "0:v:0", "-map", "0:a:0?",
            "-c", "copy", "-dn", "-movflags", "+faststart", dst]
    tools.ffmpeg(args, check=True, log=log, timeout=600)
    return dst


def _reencode(src: str, dst: str, *, fmt: str, max_duration: float | None = None,
              crf: int | None = None, log=None) -> str:
    q = crf if crf is not None else 20

    def _build(venc):
        a = ["-y", "-i", src, "-map", "0:v:0", "-map", "0:a:0?",
             *venc, *_aenc(fmt), "-ar", "48000", "-ac", "2"]
        if max_duration:
            a += ["-t", f"{max_duration:.3f}"]
        return a + [*fmt_settings(fmt)["extra"], dst]

    # Non-H.264 containers (webm/avi) keep their baked-in CPU codec.
    if fmt not in ("mp4", "mov"):
        tools.ffmpeg(_build(_venc(fmt, crf)), check=True, log=log, timeout=1800)
        return dst

    # H.264: use the GPU encoder if this machine has a working one (much faster);
    # if the real encode fails, pin to CPU and retry so an import never fails.
    kind = tools.h264_encoder_kind(log=log)
    try:
        tools.ffmpeg(_build([*tools.h264_video_args(q), "-pix_fmt", "yuv420p"]),
                     check=True, log=log, timeout=1800)
    except tools.ToolError:
        if kind == "cpu":
            raise
        if log:
            log("⚠️ GPU เข้ารหัสไม่สำเร็จ — เปลี่ยนไปใช้ CPU")
        tools.force_cpu_h264()
        tools.ffmpeg(_build([*tools.h264_video_args(q), "-pix_fmt", "yuv420p"]),
                     check=True, log=log, timeout=1800)
    return dst


# ---------------------------------------------------------------------------
# Colour / image adjustments (the in-app editor's "ปรับภาพ" tab)
# ---------------------------------------------------------------------------
ADJUST_DEFAULTS = {"brightness": 0.0, "contrast": 1.0, "saturation": 1.0,
                   "sharpen": 0.0}
_ADJUST_RANGE = {"brightness": (-0.3, 0.3), "contrast": (0.5, 1.6),
                 "saturation": (0.0, 2.0), "sharpen": (0.0, 1.5)}


def clean_adjust(adjust: dict | None) -> dict:
    """Clamp the editor's image-adjust values into safe ffmpeg ranges."""
    out = {}
    for k, default in ADJUST_DEFAULTS.items():
        lo, hi = _ADJUST_RANGE[k]
        try:
            out[k] = min(hi, max(lo, float((adjust or {}).get(k, default))))
        except (TypeError, ValueError):
            out[k] = default
    return out


def is_default_adjust(adjust: dict | None) -> bool:
    a = clean_adjust(adjust)
    return all(abs(a[k] - d) < 1e-3 for k, d in ADJUST_DEFAULTS.items())


def apply_filters(src: str, dst: str, *, adjust: dict, fmt: str = "mp4",
                  crf: int | None = None, log=None) -> str:
    """Re-encode *src* with the customer's colour/sharpness adjustments
    (ffmpeg ``eq`` + ``unsharp``).  Fail-safe: returns *src* unchanged if the
    values are all defaults or the render fails."""
    a = clean_adjust(adjust)
    filters = []
    if (abs(a["brightness"]) > 1e-3 or abs(a["contrast"] - 1) > 1e-3
            or abs(a["saturation"] - 1) > 1e-3):
        filters.append(f"eq=brightness={a['brightness']:.3f}"
                       f":contrast={a['contrast']:.3f}"
                       f":saturation={a['saturation']:.3f}")
    if a["sharpen"] > 1e-3:
        filters.append(f"unsharp=5:5:{a['sharpen']:.2f}:5:5:0.0")
    if not filters:
        return src
    args = ["-y", "-i", src, "-vf", ",".join(filters),
            *_venc(fmt, crf),
            "-preset", "veryfast" if fmt in ("mp4", "mov") else "good",
            "-pix_fmt", "yuv420p", "-c:a", "copy",
            *fmt_settings(fmt)["extra"], dst]
    try:
        tools.ffmpeg(args, check=True, log=log, timeout=3600)
    except tools.ToolError as e:
        if log:
            log(f"⚠️ ปรับภาพไม่สำเร็จ — ใช้ภาพเดิมแทน: {e}")
        return src
    return dst if os.path.exists(dst) and os.path.getsize(dst) > 1024 else src


# ---------------------------------------------------------------------------
# Audio extraction (separate MP3)
# ---------------------------------------------------------------------------
def extract_audio_segment(src: str, dst_wav: str, *, start: float = 0.0,
                          duration: float | None = None, log=None) -> str | None:
    """Extract [start, start+duration] of *src*'s audio to a 16 kHz mono WAV for
    transcription. Accurate seek (``-ss`` after ``-i``) so subtitle times line up
    with the piece. Returns dst or None if the segment has no usable audio."""
    args = ["-y", "-i", src, "-ss", f"{max(0.0, float(start)):.3f}"]
    if duration and duration > 0:
        args += ["-t", f"{float(duration):.3f}"]
    args += ["-vn", "-map", "0:a:0?", "-ac", "1", "-ar", "16000",
             "-c:a", "pcm_s16le", dst_wav]
    try:
        tools.ffmpeg(args, check=True, log=log, timeout=1800)
    except tools.ToolError as e:
        if log:
            log(f"⚠️ แยกเสียงช่วงคลิปไม่สำเร็จ: {e}")
        return None
    if os.path.exists(dst_wav) and os.path.getsize(dst_wav) > 1024:
        return dst_wav
    return None


def extract_audio(src: str, dst_mp3: str, *, log=None) -> str | None:
    """Extract the audio track of *src* to an MP3 file. Returns dst or None."""
    args = ["-y", "-i", src, "-vn", "-map", "0:a:0?",
            "-c:a", "libmp3lame", "-q:a", "2", "-ar", "48000", "-ac", "2",
            dst_mp3]
    try:
        tools.ffmpeg(args, check=True, log=log, timeout=1800)
    except tools.ToolError as e:
        if log:
            log(f"⚠️ แยกเสียง MP3 ไม่สำเร็จ: {e}")
        return None
    if os.path.exists(dst_mp3) and os.path.getsize(dst_mp3) > 256:
        return dst_mp3
    return None


# ---------------------------------------------------------------------------
# Background music
# ---------------------------------------------------------------------------
def add_music(video: str, music: str, dst: str, *, fmt: str = "mp4",
              music_volume: float = 0.2, max_duration: float | None = None,
              crf: int | None = None, log=None) -> str:
    """Duck background music under the original audio and mux it in."""
    filtergraph = (
        f"[0:a]volume=1.0[a0];"
        f"[1:a]volume={music_volume}[a1];"
        f"[a0][a1]amix=inputs=2:duration=first:dropout_transition=2[aout]"
    )
    args = ["-y", "-i", video, "-i", music,
            "-filter_complex", filtergraph,
            "-map", "0:v:0", "-map", "[aout]",
            *_venc(fmt, crf), *_aenc(fmt), "-ar", "48000", "-ac", "2"]
    if max_duration:
        args += ["-t", f"{max_duration:.3f}"]
    args += [*fmt_settings(fmt)["extra"], dst]
    try:
        tools.ffmpeg(args, check=True, log=log, timeout=1800)
    except tools.ToolError as e:
        if log:
            log(f"⚠️ music mix failed, keeping original audio: {e}")
        return video
    return dst


def _has_audio(path: str) -> bool:
    """True if *path* has at least one audio stream (editor base clips may not —
    e.g. silent product footage)."""
    try:
        res = tools.ffprobe([
            "-v", "quiet", "-select_streams", "a",
            "-show_entries", "stream=index", "-of", "csv=p=0", path,
        ])
        return bool((res.stdout or "").strip())
    except tools.ToolError:
        return False


# ---------------------------------------------------------------------------
# AI voiceover
# ---------------------------------------------------------------------------
def add_voiceover(video: str, voice: str, dst: str, *, fmt: str = "mp4",
                  mute_original: bool = True, original_volume: float = 0.0,
                  voice_volume: float = 1.0, music: str | None = None,
                  music_volume: float = 0.2, crf: int | None = None,
                  log=None) -> str:
    """Lay an AI voiceover (WAV/any audio) over *video*, muxing to *dst*.

    The video stream is copied (only audio is rebuilt).  By default the original
    audio is **muted** (target customers don't want their own voice); pass
    ``mute_original=False`` with an ``original_volume`` to keep it under the voice.
    An optional ``music`` bed is ducked in like :func:`add_music`.

    Output length is locked to the **video** length (voice/music are padded with
    silence if shorter, capped if longer — the customer fine-tunes timing in the
    editor).  Fail-safe: returns *video* unchanged on any error, so generating a
    voiceover can never destroy the clip.
    """
    if not (voice and os.path.isfile(voice)):
        return video
    dur = _duration(video)
    keep_orig = (not mute_original) and original_volume > 0 and _has_audio(video)

    inputs = ["-i", video, "-i", voice]
    parts: list[str] = []
    labels: list[str] = []
    if keep_orig:
        parts.append(f"[0:a]volume={original_volume:.3f}[ao]")
        labels.append("[ao]")
    parts.append(f"[1:a]volume={voice_volume:.3f}[av]")
    labels.append("[av]")
    if music and os.path.isfile(music):
        inputs += ["-i", music]
        parts.append(f"[{len(inputs)//2 - 1}:a]volume={music_volume:.3f}[am]")
        labels.append("[am]")

    if len(labels) == 1:
        parts.append(f"{labels[0]}apad[aout]")
    else:
        parts.append(f"{''.join(labels)}amix=inputs={len(labels)}:duration=longest"
                     f":dropout_transition=0:normalize=0,apad[aout]")
    graph = ";".join(parts)

    args = ["-y", *inputs, "-filter_complex", graph,
            "-map", "0:v:0", "-map", "[aout]", "-c:v", "copy",
            *_aenc(fmt), "-ar", "48000", "-ac", "2"]
    if dur > 0:
        args += ["-t", f"{dur:.3f}"]     # lock to video length (apad fills the tail)
    args += [*fmt_settings(fmt)["extra"], dst]
    try:
        tools.ffmpeg(args, check=True, log=log, timeout=1800)
    except tools.ToolError as e:
        if log:
            log(f"⚠️ ใส่เสียงพากย์ไม่สำเร็จ — ใช้เสียงเดิมแทน: {e}")
        return video
    return dst if os.path.exists(dst) and os.path.getsize(dst) > 1024 else video


def add_audio(video: str, items: list, dst: str, *, fmt: str = "mp4",
              crf: int | None = None, log=None) -> str:
    """Mix editable audio clips onto *video*'s existing sound.

    Each item is ``{path, at, in, out, vol}``: the slice ``[in, out]`` of the file
    is placed at ``at`` seconds on the timeline at ``vol``.  That covers both a
    background track and short effects — the customer trims and drags them the
    same way.  The video stream is copied (only audio is rebuilt).

    Fail-safe: returns *video* unchanged if anything goes wrong.
    """
    good = []
    for it in (items or []):
        path = it.get("path") or ""
        if not os.path.isfile(path):
            continue
        t_in = max(0.0, float(it.get("in") or 0.0))
        t_out = float(it.get("out") or 0.0)
        good.append({
            "path": path, "at": max(0.0, float(it.get("at") or 0.0)),
            "in": t_in, "out": t_out if t_out > t_in else None,
            "vol": min(4.0, max(0.05, float(it.get("vol") or 1.0))),
        })
    if not good:
        return video

    args = ["-y", "-i", video]
    for it in good:
        args += ["-i", it["path"]]
    parts, mix = [], "[0:a]"
    for i, it in enumerate(good, 1):
        trim = f"atrim=start={it['in']:.3f}"
        if it["out"] is not None:
            trim += f":end={it['out']:.3f}"
        ms = int(round(it["at"] * 1000))
        parts.append(f"[{i}:a]{trim},asetpts=PTS-STARTPTS,"
                     f"adelay={ms}:all=1,volume={it['vol']:.3f}[m{i}]")
        mix += f"[m{i}]"
    graph = (";".join(parts) +
             f";{mix}amix=inputs={len(good) + 1}:duration=first"
             f":dropout_transition=0:normalize=0[aout]")
    args += ["-filter_complex", graph, "-map", "0:v:0", "-map", "[aout]",
             "-c:v", "copy", *_aenc(fmt), "-ar", "48000", "-ac", "2",
             *fmt_settings(fmt)["extra"], dst]
    try:
        tools.ffmpeg(args, check=True, log=log, timeout=1800)
    except tools.ToolError as e:
        if log:
            log(f"⚠️ ผสมเสียงไม่สำเร็จ — ใช้เสียงเดิมแทน: {e}")
        return video
    return dst if os.path.exists(dst) and os.path.getsize(dst) > 1024 else video


def add_sfx(video: str, sfx: list, dst: str, *, fmt: str = "mp4",
            crf: int | None = None, log=None) -> str:
    """Overlay sound effects onto the video's audio at given times.

    *sfx* = list of ``(path, at_seconds, volume)``.  The video stream is copied
    (no re-encode) so this is fast.  Fail-safe: returns *video* on any error."""
    sfx = [(p, max(0.0, float(t)), min(2.0, max(0.05, float(v))))
           for p, t, v in (sfx or []) if os.path.isfile(p)]
    if not sfx:
        return video
    args = ["-y", "-i", video]
    for pth, _, _ in sfx:
        args += ["-i", pth]
    parts, mix = [], "[0:a]"
    for i, (_, at, vol) in enumerate(sfx, 1):
        ms = int(round(at * 1000))
        parts.append(f"[{i}:a]adelay={ms}:all=1,volume={vol}[s{i}]")
        mix += f"[s{i}]"
    graph = (";".join(parts) +
             f";{mix}amix=inputs={len(sfx) + 1}:duration=first"
             f":dropout_transition=0:normalize=0[aout]")
    args += ["-filter_complex", graph, "-map", "0:v:0", "-map", "[aout]",
             "-c:v", "copy", *_aenc(fmt), "-ar", "48000", "-ac", "2",
             *fmt_settings(fmt)["extra"], dst]
    try:
        tools.ffmpeg(args, check=True, log=log, timeout=1800)
    except tools.ToolError as e:
        if log:
            log(f"⚠️ sfx mix failed, keeping original audio: {e}")
        return video
    return dst
