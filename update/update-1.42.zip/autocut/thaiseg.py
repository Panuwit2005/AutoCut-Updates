"""In-app Thai word boundaries — no third-party dependency.

Thai is written without spaces, so an AI that splits a caption into lines (Gemini
transcription, or a script→subs pass) sometimes cuts a word in two across the line
boundary ("ด้านล่าง" → "…ด้านล่" / "าง", "สั่งเลย" → "…สั่งเล" / "ย").  The burn can't
fix that — the word is already in two separate line chunks.

This module gives dictionary maximal-matching word boundaries so the caller can
shift text between adjacent lines and keep every word whole.  The dictionary is a
bundled copy of ICU's ``thaidict.txt`` — the SAME word list Chrome uses for Thai
line breaking, so the burned captions break where the editor preview does.

Everything degrades gracefully: if the word list can't be loaded, ``available()``
is False and ``tokenize()`` returns the text as a single token, so callers no-op.
"""
from __future__ import annotations

import os
import sys

_WORDS: set[str] | None = None
_MAXLEN = 1

# Thai marks + trailing vowels that can never START a token — a fallback cluster
# keeps them attached to the preceding base glyph so a break never strands them.
_NO_START = set("ัำิีึืฺุู"
                "็่้๊๋์ํ๎"
                "ะาๆฯ")


def _wordlist_path() -> str | None:
    """Locate thaiwords.txt across dev, the OTA overlay, and the frozen bundle."""
    here = os.path.dirname(os.path.abspath(__file__))
    cands = [
        os.path.join(here, "thaiwords.txt"),                       # source / OTA overlay
        os.path.join(os.environ.get("AUTOCUT_CODE_DIR", "") or "",
                     "autocut", "thaiwords.txt"),                  # OTA overlay (explicit)
        os.path.join(getattr(sys, "_MEIPASS", "") or "",
                     "autocut", "thaiwords.txt"),                  # PyInstaller datas
    ]
    for p in cands:
        if p and os.path.isfile(p):
            return p
    return None


def _load() -> None:
    global _WORDS, _MAXLEN
    if _WORDS is not None:
        return
    words: set[str] = set()
    p = _wordlist_path()
    if p:
        try:
            with open(p, encoding="utf-8") as f:
                for ln in f:
                    ln = ln.strip()
                    if ln and not ln.startswith("#"):
                        words.add(ln)
        except OSError:
            words = set()
    _WORDS = words
    _MAXLEN = max((len(w) for w in words), default=1)


def available() -> bool:
    _load()
    return bool(_WORDS)


def _word_at(text: str, i: int) -> str:
    """Longest dictionary word starting at index *i* (maximal match), or ''."""
    hi = min(_MAXLEN, len(text) - i)
    for L in range(hi, 0, -1):
        if text[i:i + L] in _WORDS:
            return text[i:i + L]
    return ""


def tokenize(text: str) -> list[str]:
    """Split *text* into tokens at Thai word boundaries.

    Dictionary maximal-matching for Thai; a non-dictionary Thai run falls back to
    one cluster at a time (base + attached marks/vowels) so a break never strands a
    vowel/tone mark.  Spaces and non-Thai runs (English/digits) stay whole tokens.
    ``"".join(tokenize(t)) == t``.
    """
    _load()
    if not _WORDS or not text:
        return [text] if text else []
    out: list[str] = []
    i, n = 0, len(text)
    while i < n:
        ch = text[i]
        if ch.isspace():
            out.append(ch)
            i += 1
        elif "฀" <= ch <= "๿":            # Thai
            w = _word_at(text, i)
            if w:
                out.append(w)
                i += len(w)
            else:                                   # unknown → one cluster
                j = i + 1
                while j < n and text[j] in _NO_START:
                    j += 1
                out.append(text[i:j])
                i = j
        else:                                       # non-Thai run stays together
            j = i + 1
            while j < n and not text[j].isspace() and not ("฀" <= text[j] <= "๿"):
                j += 1
            out.append(text[i:j])
            i = j
    return out
