"""Decide which parts of the footage to keep.

Two strategies, depending on what we have:

* With a transcript — :func:`select_review_clips` scores every spoken segment for
  "review value" (product, quality, recommendation …), treats **price / promo
  talk** as the most important moment (always kept), keeps a short tail so the
  last words aren't clipped, drops dead air, and **tops up toward the target
  length** so a "≤ 60s" job fills toward 60s instead of leaving a 13s sliver.
* Without a transcript — fall back to ffmpeg silence detection and keep the
  spoken zones.  This guarantees the pipeline always produces *something*.

:func:`trim_dead_air` tightens whatever was chosen by dropping the pauses where
nobody is actually speaking.  It prefers the transcript's word-level timing
(which survives loud background music, common in these review intros) and falls
back to acoustic silence detection when no transcript is available.
"""

from __future__ import annotations

import random
import re
from dataclasses import dataclass

from . import tools
from .transcribe import Transcript

# Words that signal a useful review moment (Thai + English).
REVIEW_KEYWORDS = [
    "ดี", "แนะนำ", "คุณภาพ", "ราคา", "ซื้อ", "ใช้", "สินค้า", "รีวิว", "ชอบ",
    "เยี่ยม", "สุด", "มาก", "จริง", "เหมาะ", "คุ้ม", "ประทับ", "น่า", "สวย",
    "ครบ", "ใหม่", "พอใจ", "ต้องการ", "เด่น", "โดด", "ลอง", "ผิดหวัง", "โอเค",
    "ทน", "แข็งแรง", "เบา", "พกพา", "วัสดุ", "งานประกอบ", "ฟีเจอร์", "ฟังก์ชัน",
    "ข้อดี", "ข้อเสีย", "เทียบ", "รุ่น", "แบรนด์", "ยี่ห้อ", "สเปก", "แบต",
    "เสียง", "จอ", "กล้อง", "นุ่ม", "เนียน", "หอม", "อร่อย", "ใช้ดี", "บอกเลย",
    "good", "great", "recommend", "quality", "buy", "product", "review", "like",
    "love", "best", "value", "worth", "nice", "perfect", "amazing", "excellent",
    "pros", "cons", "feature", "battery", "screen", "camera", "durable",
]

# Price / promotion talk is usually the single most important moment in a review —
# the viewer almost always wants the price in the cut.  It is detected separately
# from the keyword list (numbers + บาท/฿, "ราคา", discounts, freebies …), scored
# heavily, and segments that mention it are *always* kept (see ``Clip.must``).
PRICE_RE = re.compile(
    r"\d[\d,\.]*\s*(บาท|฿|baht|bath)"           # 290 บาท, 1,290฿, 990 baht
    r"|บาท|฿"
    r"|ราคา|กี่บาท|กี่ตังค์|เท่าไหร่|เท่าไร"
    r"|ลดราคา|ลดเหลือ|ลดแล้ว|ส่วนลด"
    r"|โปรโมชั่น|โปรโมชัน|โปรโม|ดีล|deal|sale|เซล"
    r"|ส่งฟรี|แถม|ของแถม|ผ่อน|คุ้มราคา|คุ้มค่า|ถูก|แพง"
    # purchase / call-to-action talk (live-selling & reviews) — also always kept
    r"|ตะกร้า|จิ้มตะกร้า|จิ้มที่ตะกร้า|จิ้มลิงก์|กดที่ตะกร้า|กดตะกร้า"
    r"|สั่งซื้อ|กดสั่ง|สั่งเลย|กดเลข|ลิงก์|ลิงค์|โค้ด|คูปอง|พร้อมส่ง"
    r"|หยิบใส่|กดติดตาม|รีบเลย|ของมีจำนวนจำกัด|จำนวนจำกัด"
    # closing summary of a review — usually worth keeping
    r"|สรุปแล้ว|สรุปคือ|โดยรวมแล้ว|โดยรวมก็",
    re.IGNORECASE,
)

# --- Review structure -------------------------------------------------------
# A good cut has a recognisable SHAPE — a hook, the product being shown, the
# price, and a closing summary — not a flat "keep every sentence" dump (which is
# what made cuts feel like "เอาเนื้อหาอะไรมาไม่รู้").  These patterns tag each
# segment with its structural role so the cutter can EMPHASISE the moments that
# carry the review and, when it must drop something, drop the off-topic chatter
# first while keeping the structure intact.  ``PRICE_RE`` already covers price,
# call-to-action and "สรุปแล้ว/โดยรวมแล้ว" (those are also Clip.must keeps); the
# patterns below add the product showcase, the opening hook and a broader
# closing summary.
SHOWCASE_RE = re.compile(
    r"ตัวนี้|รุ่นนี้|อันนี้|เจ้านี้|ชิ้นนี้|ตัวนี้เลย"
    r"|วัสดุ|ดีไซน์|งานประกอบ|ฟีเจอร์|ฟังก์ชัน|สเปก|จุดเด่น|ข้อดี|ข้อเสีย"
    r"|ขนาด|น้ำหนัก|หน้าตา|แพ็กเกจ|แพ็คเกจ|กล่อง|แกะกล่อง|ภายใน|มาดู|ลองดู|โชว์"
    r"|ลองใช้|ใช้งาน|ทดสอบ|ใช้จริง|เวลาใช้|ตอนใช้|สาธิต|วิธีใช้",
    re.IGNORECASE,
)
INTRO_RE = re.compile(
    r"สวัสดี|วันนี้|จะมารีวิว|มารีวิว|จะรีวิว|จะมาแนะนำ|มาแนะนำ|ขอแนะนำ"
    r"|คลิปนี้|วิดีโอนี้|ช่องเรา|ยินดีต้อนรับ|กลับมาพบ",
    re.IGNORECASE,
)
SUMMARY_RE = re.compile(
    r"สรุป|โดยรวม|ทั้งหมดนี้|ปิดท้าย|สุดท้ายนี้|ก่อนจาก|จบคลิป|แนะนำเลย|คุ้มมาก",
    re.IGNORECASE,
)
CTA_RE = re.compile(
    r"ตะกร้า|สั่งซื้อ|กดสั่ง|สั่งเลย|ลิงก์|ลิงค์|โค้ด|คูปอง|พร้อมส่ง|หยิบใส่"
    r"|กดติดตาม|กดไลก์|กดแชร์|รีบเลย",
    re.IGNORECASE,
)

# How strongly each structural role is emphasised when ranking.  Price & CTA are
# already boosted (+3) and force-kept via PRICE_RE / Clip.must, so they're 0 here
# — the new emphasis is for the product showcase, the hook and the summary.
SECTION_BOOST = {
    "showcase": 2.0, "summary": 1.5, "intro": 1.0,
    "price": 0.0, "cta": 0.0, "body": 0.0,
}
SECTION_PRIORITY = {"price": 5, "cta": 5, "summary": 4, "showcase": 3,
                    "intro": 2, "body": 1}
ANCHOR_SECTIONS = ("price", "cta", "summary", "showcase", "intro")
NEIGHBOUR_BONUS = 0.8   # a plain line next to an anchor is kept so runs stay whole

# Pure filler — if a whole segment is just this, it is worthless.
FILLERS = {"อืม", "เอ่อ", "ก็", "นะ", "อ่า", "เอ้อ", "ครับ", "ค่ะ",
           "hmm", "uh", "um", "ah", "er", "you know"}

MIN_CLIP = 0.6      # seconds — anything shorter is a fragment
MERGE_GAP = 0.6     # merge kept clips separated by a gap this small
TAIL_HOLD = 0.60    # room kept after a segment so the last words + a breath fit
VISUAL_DROP = 0.60  # a segment whose visual score is below this is dropped (no clear subject/face)


@dataclass
class Clip:
    start: float
    end: float
    text: str = ""
    score: float = 0.0
    must: bool = False   # always keep (e.g. price talk), even when the budget is tight
    rank: float = 0.0    # score + a one-time jitter, used only for ordering
    visual: float = 1.0  # local visual-quality score 0..1 (1 = unknown/good)
    section: str = "body"  # review-structure role (intro/showcase/price/cta/summary/body)

    @property
    def duration(self) -> float:
        return max(0.0, self.end - self.start)


def _has_price(text: str) -> bool:
    """True if the segment talks about price / promotion / value-for-money."""
    return bool(PRICE_RE.search(text or ""))


def _section(text: str, position: float = 0.5) -> str:
    """Tag a segment with its coarse review-structure role.

    ``position`` is the segment's relative place in the video (0 = start, 1 =
    end); the opening hook only counts near the start.  Overlaps are resolved by
    priority: summary > call-to-action > price > showcase > intro > body."""
    t = text or ""
    if SUMMARY_RE.search(t):
        return "summary"
    if CTA_RE.search(t):
        return "cta"
    if _has_price(t):
        return "price"
    if SHOWCASE_RE.search(t):
        return "showcase"
    if position <= 0.22 and INTRO_RE.search(t):
        return "intro"
    return "body"


def _better_section(a: str, b: str) -> str:
    """The more important of two section labels (used when merging clips)."""
    return a if SECTION_PRIORITY.get(a, 1) >= SECTION_PRIORITY.get(b, 1) else b


def _score(text: str, duration: float) -> float:
    """Rank a segment.  Ordinary speech scores fine (it stays in the cut); review
    keywords are a *mild* boost and price a stronger one, so they're emphasised
    (kept when something has to be dropped) without turning the cut into a
    keyword-only montage.  Price is also hard-guaranteed via ``Clip.must``."""
    low = text.lower()
    score = 1.0                      # baseline: ordinary speech is worth keeping
    hits = sum(1 for kw in REVIEW_KEYWORDS if kw in low)
    score += min(hits, 3) * 1.0      # mild emphasis for review vocabulary (capped)
    if _has_price(text):
        score += 3.0                 # price/promo talk — emphasise + always keep (must)
    if 2.0 <= duration <= 9.0:
        score += 0.5                 # natural sentence length
    elif duration < MIN_CLIP:
        score -= 6.0                 # too short to be useful
    stripped = re.sub(r"[\s.,!?]", "", low)
    if stripped in FILLERS or not stripped:
        score -= 6.0                 # pure filler / empty
    return score


def _candidates(transcript: Transcript, rnd: random.Random | None,
                visual_scores: dict | None = None) -> list[Clip]:
    """Turn transcript segments into scored candidate clips.

    Each clip gets a small **tail hold** (up to :data:`TAIL_HOLD`, never bleeding
    into the next segment) so the last spoken words / Thai end-particles finish
    before the cut instead of being clipped.  ``rnd`` (set only for the variation
    button) adds a *one-time* jitter to ``rank``.  ``visual_scores`` (from
    :mod:`autocut.vision`, keyed by ``round(start, 2)``) penalises — and clearly
    bad ones drops — ugly shots (blurry/dark/empty), but **never a price moment**.
    """
    segs = [s for s in transcript.segments if (s.end - s.start) >= 0.2]
    out: list[Clip] = []
    n = len(segs)
    for i, seg in enumerate(segs):
        text = seg.text.strip()
        dur = seg.end - seg.start
        nxt = segs[i + 1].start if i + 1 < len(segs) else seg.end + TAIL_HOLD
        end = min(seg.end + TAIL_HOLD, max(seg.end, nxt - 0.05))
        position = i / (n - 1) if n > 1 else 0.0
        c = Clip(seg.start, end, text, _score(text, dur))
        c.section = _section(text, position)
        c.score += SECTION_BOOST.get(c.section, 0.0)        # emphasise structural roles
        c.must = _has_price(text)
        if visual_scores:
            c.visual = visual_scores.get(round(seg.start, 2), 1.0)
            if not c.must:
                c.score -= (1.0 - c.visual) * 6.0           # penalise weak visuals
                if c.visual < VISUAL_DROP:
                    c.score -= 10.0                         # clearly bad → excluded
        out.append(c)
    # Keep plain lines that sit right next to an anchor (price/showcase/summary/…)
    # so the cut stays in coherent runs instead of isolated keyword sentences —
    # this is what keeps it from feeling choppy / "เนื้อหามั่ว".
    anchored = [c.must or c.section in ANCHOR_SECTIONS for c in out]
    for i, c in enumerate(out):
        if not anchored[i] and ((i > 0 and anchored[i - 1]) or
                                (i + 1 < len(out) and anchored[i + 1])):
            c.score += NEIGHBOUR_BONUS
    for c in out:
        c.rank = c.score + (rnd.uniform(-2.0, 2.0) if rnd else 0.0)
    return out


def _fit_to_budget(clips: list[Clip], budget: float) -> list[Clip]:
    """Fit a tightened, chronological set within *budget* seconds.

    Whole clips are dropped (so cuts stay on natural clip boundaries, never
    mid-sentence) — the **weakest** ones first, and **never a price moment** — so
    keyword / price talk is what survives when something has to go.  If it already
    fits, nothing is dropped (the whole clip is kept → representative, not a
    sliver).
    """
    total = sum(c.duration for c in clips)
    if total <= budget:
        return clips
    keep = list(clips)
    for c in sorted((c for c in clips if not c.must),
                    key=lambda x: (x.rank, x.duration)):  # weakest, then longest
        if total <= budget:
            break
        keep.remove(c)
        total -= c.duration
    keep.sort(key=lambda c: c.start)
    return keep


def _log_structure(cands: list[Clip], log) -> None:
    """Tell the user what review structure was recognised (transparency — so the
    cut isn't a black box).  Counts the structural roles across the whole video."""
    secs = [c.section for c in cands]
    n_show = secs.count("showcase")
    n_money = secs.count("price") + secs.count("cta")
    kind = "รีวิว/ขายสินค้า" if (n_show or n_money) else "ทั่วไป"
    log("📋 เข้าใจโครงคลิป: {} · เปิดตัว {} · โชว์สินค้า {} ช่วง · ราคา/โปรโม {} · สรุป {}".format(
        kind,
        "✓" if "intro" in secs else "–", n_show, n_money,
        "✓" if "summary" in secs else "–"))


def select_review_clips(transcript: Transcript, max_duration: float, *,
                        variation: int = 0, dead_air_on: bool = True,
                        aggressiveness: str = "medium", path: str | None = None,
                        visual_scores: dict | None = None, log=None) -> list[Clip]:
    """Build the review cut, capped at **<= max_duration** (quality over length).

    Flow:

    1. keep every spoken segment that isn't junk — so the cut represents the whole
       video (not a montage of only keyword lines), each with a tail hold so the
       last words finish;
    2. drop the dead air inside them;
    3. if the result is **longer** than the target, drop whole sentences — weakest
       first, **never a price moment** — re-measuring the real cut each time, until
       it fits.  The result is never padded to fill the target: if the good
       content is shorter than the limit, the clip is simply shorter (we don't
       drag in weak parts just to reach the set time).
    """
    rnd = random.Random(variation) if variation else None
    cands = _candidates(transcript, rnd, visual_scores)
    if not cands:
        return []
    if log:
        _log_structure(cands, log)
    usable = [c for c in cands if c.score > -3] or cands
    has_words = bool(getattr(transcript, "words", []))

    def render(subset: list[Clip]) -> list[Clip]:
        out = _merge_adjacent(sorted(subset, key=lambda c: c.start))
        if dead_air_on:
            out = trim_dead_air(out, transcript=transcript, path=path,
                                aggressiveness=aggressiveness, log=None)
        return out

    chosen = list(usable)
    clips = render(chosen)
    if sum(c.duration for c in clips) > max_duration:
        if has_words or not dead_air_on:
            # Re-measuring word-based trims is cheap → drop the weakest whole
            # sentences (keeping price) until the *real* cut fits the target.
            weak = sorted((c for c in usable if not c.must),
                          key=lambda c: (c.rank, c.duration))
            i = 0
            while sum(c.duration for c in clips) > max_duration and i < len(weak):
                chosen.remove(weak[i])
                i += 1
                clips = render(chosen)
        else:
            clips = _fit_to_budget(clips, max_duration)  # silence path: 1 coarse cap
    clips = _fit_to_budget(clips, max_duration)           # hard ceiling (<= target)
    if rnd:
        clips = _jitter_bounds(clips, rnd)
    if log:
        got = sum(c.duration for c in clips)
        extra = " · เน้นช่วงราคา/คำสำคัญ" if any(getattr(c, "must", False) for c in clips) else ""
        log(f"🎯 ตัดได้ {len(clips)} ช่วง รวม {got:.1f}s / ไม่เกิน {max_duration:.0f}s{extra}")
    return clips


def finish_clips(clips: list[Clip], transcript, max_duration: float, *,
                 dead_air_on: bool = True, aggressiveness: str = "medium",
                 path: str | None = None, log=None) -> list[Clip]:
    """Turn a *chosen* set of clips (e.g. from the AI) into the final cut.

    Same finishing as the offline cutter so both behave alike: merge touching
    clips → drop dead air → cap at ``max_duration`` (<=, never padded)."""
    if not clips:
        return []
    out = _merge_adjacent(sorted(clips, key=lambda c: c.start))
    if dead_air_on:
        out = trim_dead_air(out, transcript=transcript, path=path,
                            aggressiveness=aggressiveness, log=log)
    return _fit_to_budget(out, max_duration)


def _jitter_bounds(clips: list[Clip], rnd: random.Random) -> list[Clip]:
    """Nudge each clip's in/out points slightly for visible variety (safe-clamped)."""
    out: list[Clip] = []
    for c in clips:
        start = max(0.0, c.start + rnd.uniform(-0.20, 0.20))
        end = max(start + MIN_CLIP, c.end + rnd.uniform(-0.20, 0.40))
        out.append(Clip(start, end, c.text, c.score))
    return out


def _copy(c: Clip) -> Clip:
    return Clip(c.start, c.end, c.text, c.score, c.must, c.rank, c.visual, c.section)


def _merge_adjacent(clips: list[Clip]) -> list[Clip]:
    """Join clips separated by only a tiny gap to avoid choppy micro-cuts.

    Returns **fresh** clips and never mutates its inputs — important because the
    selection re-renders the same candidate list many times, and mutating shared
    objects would corrupt later passes.
    """
    if not clips:
        return []
    merged = [_copy(clips[0])]
    for c in clips[1:]:
        last = merged[-1]
        if c.start - last.end <= MERGE_GAP:
            last.end = max(last.end, c.end)
            last.text = (last.text + " " + c.text).strip()
            last.score = max(last.score, c.score)
            last.rank = max(last.rank, c.rank)
            last.must = last.must or c.must     # a merged run keeps its price flag
            last.section = _better_section(last.section, c.section)  # … and its role
        else:
            merged.append(_copy(c))
    return merged


# ---------------------------------------------------------------------------
# Fallback: cut by silence when there is no transcript
# ---------------------------------------------------------------------------
def speech_zones(path: str, duration: float, max_duration: float, *,
                 noise_db: int = -32, min_silence: float = 0.6,
                 variation: int = 0, log=None) -> list[Clip]:
    """Return spoken (non-silent) zones via ffmpeg silencedetect."""
    starts, ends = _silence_intervals(path, noise_db, min_silence, log)
    if not starts:
        return [Clip(0.0, min(duration, max_duration) or max_duration,
                     "ทั้งคลิป", 0.0)]

    zones: list[Clip] = []
    prev_end = 0.0
    for i, s_start in enumerate(starts):
        if s_start > prev_end + 0.2:
            zones.append(Clip(prev_end, s_start, "", 1.0))
        prev_end = ends[i] if i < len(ends) else s_start
    if duration and prev_end < duration - 0.2:
        zones.append(Clip(prev_end, duration, "", 1.0))

    # With a variation seed, drop a few zones at random so a re-run keeps a
    # different subset of the spoken parts (still chronological).
    if variation and len(zones) > 2:
        rnd = random.Random(variation)
        zones = [z for z in zones if rnd.random() > 0.25] or zones

    # Trim to the time budget, keeping chronological order.
    out: list[Clip] = []
    total = 0.0
    for z in zones:
        if z.duration < MIN_CLIP:
            continue
        take = min(z.duration, max_duration - total)
        if take <= 0:
            break
        out.append(Clip(z.start, z.start + take, "", 1.0))
        total += take
        if total >= max_duration:
            break
    return out or [Clip(0.0, min(duration, max_duration) or max_duration, "", 0.0)]


def _silence_intervals(path: str, noise_db: int, min_silence: float, log=None):
    try:
        # silencedetect logs its results at the *info* level; tools.ffmpeg pins
        # -loglevel error, so override it here (the last -loglevel wins) or we
        # would silently parse an empty stderr and "find" no silence at all.
        res = tools.ffmpeg([
            "-i", path,
            "-af", f"silencedetect=noise={noise_db}dB:d={min_silence}",
            "-loglevel", "info", "-f", "null", "-",
        ], log=log, timeout=600)
        stderr = res.stderr or ""
    except tools.ToolError as e:
        if log:
            log(f"⚠️ silencedetect failed: {e}")
        return [], []
    starts, ends = [], []
    for line in stderr.splitlines():
        m1 = re.search(r"silence_start:\s*(-?[0-9.]+)", line)
        m2 = re.search(r"silence_end:\s*(-?[0-9.]+)", line)
        if m1:
            starts.append(max(0.0, float(m1.group(1))))
        if m2:
            ends.append(float(m2.group(1)))
    return starts, ends


# ---------------------------------------------------------------------------
# Dead-air removal — tighten the chosen clips by dropping non-speech pauses
# ---------------------------------------------------------------------------
# How long a pause has to be before we treat it as dead air, per aggressiveness.
# These are deliberately LONG: a person naturally pauses ~0.3-0.8s between phrases
# (a breath / beat) and that rhythm is what makes speech sound human — cutting it
# out makes the result feel robotic and choppy.  So we only remove *clearly long*
# dead air (someone stopped talking) and KEEP the natural pauses (see BREATH).
# max_gap: word-path — a gap between words longer than this is real dead air.
# min_silence: silence-path fallback — same idea, acoustic.
DEAD_AIR_PRESETS = {
    "gentle": {"max_gap": 1.20, "min_silence": 1.40},
    "medium": {"max_gap": 0.90, "min_silence": 1.10},
    "strong": {"max_gap": 0.60, "min_silence": 0.80},
}
EDGE_PAD = 0.30     # silence-path padding around kept speech (onsets/tails + breath)
# Word-path: a small HEAD so onsets aren't clipped, and after each spoken run we
# keep a SHORT BREATH of trailing pause before the cut — "พูดจบ → เว้นนิดนึง → ตัด"
# — just enough that a cut isn't abrupt, without dragging.
HEAD_PAD = 0.12
BREATH = 0.10    # short trailing pause after speech (tuned tight per user feedback)


def trim_dead_air(clips: list[Clip], transcript=None, path: str | None = None, *,
                  aggressiveness: str = "medium", log=None) -> list[Clip]:
    """Drop the dead air *inside* the chosen clips, returning tighter clips.

    Prefers the transcript's word timing (robust to loud background music); falls
    back to acoustic silence detection on *path* when there are no words.  Never
    raises and never returns nothing — on any doubt it returns *clips* unchanged
    so the pipeline degrades gracefully.
    """
    if not clips:
        return clips
    preset = DEAD_AIR_PRESETS.get(aggressiveness, DEAD_AIR_PRESETS["medium"])
    words = getattr(transcript, "words", []) if transcript else []

    try:
        if words:
            out = _dead_air_by_words(clips, words, preset["max_gap"])
            method = "transcript"
        elif path:
            out = _dead_air_by_silence(clips, path, preset["min_silence"], log=log)
            method = "silence"
        else:
            return clips
    except Exception as e:  # noqa: BLE001 - tightening must never break a job
        if log:
            log(f"⚠️ ตัด dead air ไม่สำเร็จ ({e}) — ใช้ช่วงเดิม")
        return clips

    before = sum(c.duration for c in clips)
    after = sum(c.duration for c in out)
    if not out or after < min(1.0, before * 0.25):
        return clips                       # suspiciously aggressive — keep originals
    if log:
        log(f"🤫 ตัด dead air ({method}/{aggressiveness}) ~{max(0.0, before - after):.1f}s "
            f"→ {len(out)} ช่วง")
    return out


def _dead_air_by_words(clips: list[Clip], words, max_gap: float,
                       head_pad: float = HEAD_PAD,
                       breath: float = BREATH) -> list[Clip]:
    """Split each clip into runs of speech, dropping word gaps > *max_gap*.

    Only *clearly long* gaps split a run; ordinary phrase pauses stay, so a
    sentence isn't chopped into rapid-fire fragments.  After each kept run we keep
    a real **breath** of trailing pause (up to *breath* seconds of the real
    footage, never overlapping the next run) before the cut — so it sounds like a
    person finishing a thought, not an abrupt jump.
    """
    out: list[Clip] = []
    for c in clips:
        ws = sorted((w for w in words
                     if w.end > w.start and w.end > c.start and w.start < c.end),
                    key=lambda w: w.start)
        if not ws:
            out.append(c)                  # no word timing here — leave it alone
            continue
        run_start = max(c.start, ws[0].start)
        run_end = ws[0].end
        runs: list[tuple[float, float]] = []
        for w in ws[1:]:
            if w.start - run_end > max_gap:
                runs.append((run_start, run_end))
                run_start = w.start
            run_end = max(run_end, w.end)
        runs.append((run_start, run_end))
        for i, (s, e) in enumerate(runs):
            s = max(c.start, s - head_pad)
            nxt = runs[i + 1][0] if i + 1 < len(runs) else c.end
            e = min(c.end, nxt, e + breath)   # keep a breath, but don't overlap next
            if e - s >= MIN_CLIP:
                out.append(Clip(s, e, c.text, c.score))
    return out


def _dead_air_by_silence(clips: list[Clip], path: str, min_silence: float, *,
                         noise_db: int = -32, edge_pad: float = EDGE_PAD,
                         log=None) -> list[Clip]:
    """Subtract detected silence spans from each clip, then tidy the result so it
    reads smoothly (no choppy micro-cuts, no dropped audio fragments)."""
    spans = _silence_spans(path, noise_db, min_silence, log)
    if not spans:
        return clips
    out: list[Clip] = []
    for c in clips:
        pieces = _subtract_silences(c.start, c.end, spans, edge_pad)
        out.extend(_tidy_pieces(pieces, c))
    return out or clips


def _tidy_pieces(pieces: list[tuple[float, float]], c: Clip) -> list[Clip]:
    """Absorb too-short speech fragments into the previous kept piece (keeps the
    audio continuous and avoids jarring micro-cuts), then drop any leading runt."""
    merged: list[list[float]] = []
    for s, e in pieces:
        if merged and (e - s) < MIN_CLIP:
            merged[-1][1] = e                 # swallow a short fragment + its gap
        else:
            merged.append([s, e])
    return [Clip(s, e, c.text, c.score) for s, e in merged if (e - s) >= MIN_CLIP]


def _silence_spans(path: str, noise_db: int, min_silence: float, log=None):
    """Paired (start, end) silence spans; an unmatched final start runs to EOF."""
    starts, ends = _silence_intervals(path, noise_db, min_silence, log)
    spans: list[tuple[float, float | None]] = []
    for i, s in enumerate(starts):
        spans.append((s, ends[i] if i < len(ends) else None))
    return spans


def _subtract_silences(cs: float, ce: float, spans, pad: float):
    """Return the speech pieces of [cs, ce] after removing the padded silences."""
    cuts: list[tuple[float, float]] = []
    for ss, se in spans:
        se = ce if se is None else se
        a, b = max(cs, ss) + pad, min(ce, se) - pad
        if b > a:
            cuts.append((a, b))
    cuts.sort()
    pieces: list[tuple[float, float]] = []
    cur = cs
    for a, b in cuts:
        if a > cur:
            pieces.append((cur, a))
        cur = max(cur, b)
    if ce > cur:
        pieces.append((cur, ce))
    return pieces
