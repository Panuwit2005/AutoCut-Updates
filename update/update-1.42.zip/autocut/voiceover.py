"""AI Thai voiceover: turn an (editable) script into spoken audio via Gemini TTS.

Product shape (see the editor's "🎙️ เสียงพากย์ AI" panel):
  • the customer always sees an **editable script box** — the words the AI will
    speak — seeded either from typed product info (``llm`` drafts it) or from the
    video's own audio (``transcribe`` re-voices it).  They tweak, then generate;
  • provider: **Google Gemini TTS** (steerable single-speaker), reusing the same
    key resolution as :mod:`llm` (customer key > env > baked dev key);
  • **Thai only** — all customers are Thai, so the language is fixed and the
    Style / Pace "director's note" is expressed as a natural-language Thai prompt
    prefix (Gemini TTS is *steerable* — style is not a separate API parameter);
  • **online-only, fail-loud** — TTS needs the network + a key.  There is no
    offline Thai TTS fallback (quality would be poor and a *visible* bad voice is
    worse than a clear "ต่อเน็ต/ใส่คีย์ก่อน").  A failure raises, it never returns
    a broken/silent clip.  (Muxing the voice onto the video, by contrast, is
    fail-safe and keeps the original — see :func:`editor.add_voiceover`.)

Networking is stdlib-only (via :func:`llm._http_post`) so the frozen build needs
no new dependency.  :func:`synthesize` accepts an injectable ``_transport``
(``callable(url, body, headers, timeout) -> bytes``) so the prompt-building and
audio-decoding logic is unit-testable without hitting the network.
"""

from __future__ import annotations

import base64
import json
import re
import struct

from . import llm

# Reuse llm's endpoint template + key resolution so there is one source of truth.
_ENDPOINT = llm._ENDPOINT
DEFAULT_MODEL = "gemini-3.1-flash-tts-preview"


class VoiceoverUnavailable(RuntimeError):
    """TTS mode can't run — no API key configured."""


class VoiceoverError(RuntimeError):
    """The TTS call failed (network, bad key, empty/malformed audio …)."""


# ---------------------------------------------------------------------------
# Customer-facing choices (kept small on purpose — simple surface).
# Voice names are Gemini prebuilt voices; the gender/character labels are our
# best pick for Thai product narration and can be re-tuned after listening.
# ---------------------------------------------------------------------------
VOICES = [
    # ⭐ เสียงยอดนิยม — ลูกค้าเลือกเองหลังฟังเทียบ 12 เสียง (2026-07-29): เป็น
    # เสียง Gemini ที่ฟังเป็นธรรมชาติ/เหมือนคนจริงที่สุด ทั้งหญิงและชาย.
    {"id": "female_sulafat", "label": "หญิง — อบอุ่น น่าฟัง",   "voice": "Sulafat", "popular": True},
    {"id": "male_achird",    "label": "ชาย — เป็นกันเอง",       "voice": "Achird",  "popular": True},
    # หญิง — คงเดิม (ลูกค้าบอกโอเคแล้ว) + เพิ่มอีกนิด
    {"id": "female_warm",   "label": "หญิง — นุ่มนวล",        "voice": "Aoede"},
    {"id": "female_bright", "label": "หญิง — สดใส",            "voice": "Kore"},
    {"id": "female_soft",   "label": "หญิง — อ่อนโยน เสียงสูง", "voice": "Achernar"},
    {"id": "female_gentle", "label": "หญิง — ละมุน",           "voice": "Vindemiatrix"},
    # ชาย — หลายคาแรกเตอร์ (ลูกค้าอยากได้ผู้ชายหลากหลาย ไม่ให้เหมือนกันหมด)
    {"id": "male_warm",     "label": "ชาย — สุภาพ ทางการ",      "voice": "Charon"},
    {"id": "male_strong",   "label": "ชาย — มีพลัง สดใส",       "voice": "Fenrir"},
    {"id": "male_firm",     "label": "ชาย — หนักแน่น มั่นใจ",    "voice": "Alnilam"},
    {"id": "male_deep",     "label": "ชาย — ทุ้มลึก",           "voice": "Enceladus"},
    {"id": "male_gravel",   "label": "ชาย — ห้าว เสียงหยาบ",     "voice": "Algenib"},
    {"id": "male_smooth",   "label": "ชาย — นุ่มลื่น",          "voice": "Algieba"},
    {"id": "male_clear",    "label": "ชาย — ชัดเจน สุขุม",       "voice": "Iapetus"},
    {"id": "male_trust",    "label": "ชาย — น่าเชื่อถือ",        "voice": "Rasalgethi"},
]
_VOICE_BY_ID = {v["id"]: v for v in VOICES}
DEFAULT_VOICE = "female_sulafat"

# Style / Pace = the "director's note" — expressed as a Thai instruction prefix.
STYLES = [
    {"id": "confident",  "label": "มั่นใจ ขายของ",      "hint": "ด้วยน้ำเสียงมั่นใจ น่าเชื่อถือ แบบพรีเซนต์ขายสินค้า"},
    {"id": "empathetic", "label": "เห็นอกเห็นใจ",        "hint": "ด้วยน้ำเสียงอบอุ่น เป็นกันเอง เห็นอกเห็นใจ"},
    {"id": "energetic",  "label": "สดใส กระตือรือร้น",    "hint": "ด้วยน้ำเสียงสดใส กระตือรือร้น ชวนติดตาม"},
    {"id": "promo",      "label": "โปรโมสุดพลัง",         "hint": "ด้วยน้ำเสียงพลังสูง เน้นคำหนักแน่น กระตุ้นความตื่นเต้น แบบโฆษณาโปรโมชั่น"},
    {"id": "newscaster", "label": "ทางการ (ผู้ประกาศ)",  "hint": "ด้วยน้ำเสียงชัดเจน เป็นทางการ จังหวะสม่ำเสมอ แบบผู้ประกาศข่าว"},
    {"id": "calm",       "label": "สงบ ผ่อนคลาย",        "hint": "ด้วยน้ำเสียงสงบ นุ่มนวล ผ่อนคลาย"},
]
_STYLE_HINT = {s["id"]: s["hint"] for s in STYLES}
DEFAULT_STYLE = "confident"

PACES = [
    {"id": "natural", "label": "ปกติ",          "hint": "ในจังหวะปกติ"},
    {"id": "slow",    "label": "ช้า ชัดถ้อยคำ",  "hint": "ในจังหวะช้า ชัดถ้อยชัดคำ"},
    {"id": "fast",    "label": "เร็ว กระชับ",     "hint": "ในจังหวะเร็ว กระชับ"},
]
_PACE_HINT = {p["id"]: p["hint"] for p in PACES}
DEFAULT_PACE = "natural"

# Gemini TTS returns raw little-endian PCM; default sample rate when the response
# mimeType doesn't spell it out.
_DEFAULT_RATE = 24000
# Guard against runaway bills / API limits: TTS input is a short narration.
MAX_CHARS = 5000
# Short, gender-neutral sample for the "▶ ฟังตัวอย่างเสียง" button.
PREVIEW_TEXT = "สวัสดี นี่คือตัวอย่างเสียงพากย์เอไอ ลองฟังโทนเสียงนี้กันดูนะ"
# Model "temperature" (same knob as Google AI Studio): low = steady and
# predictable, high = more varied/expressive delivery.  Range 0–2.
TEMP_MIN, TEMP_MAX, DEFAULT_TEMP = 0.0, 2.0, 1.0


def clean_temp(value) -> float:
    try:
        return round(min(TEMP_MAX, max(TEMP_MIN, float(value))), 2)
    except (TypeError, ValueError):
        return DEFAULT_TEMP


# ---------------------------------------------------------------------------
# Config / availability
# ---------------------------------------------------------------------------
def _model() -> str:
    return (llm._cfg().get("tts_model") or DEFAULT_MODEL).strip()


def available() -> bool:
    """A key is present, so a TTS call *can* be attempted (network permitting)."""
    return bool(llm.api_key())


def resolve_voice(voice_id: str | None) -> str:
    """Map a customer voice id → Gemini prebuilt voice name (default on unknown)."""
    v = _VOICE_BY_ID.get((voice_id or "").strip()) or _VOICE_BY_ID[DEFAULT_VOICE]
    return v["voice"]


def status() -> dict:
    """For the editor panel / settings UI."""
    return {
        "provider": "gemini",
        "model": _model(),
        "key_set": bool(llm.api_key()),
        "available": available(),
        "voices": VOICES,
        "styles": STYLES,
        "paces": PACES,
        "defaults": {"voice": DEFAULT_VOICE, "style": DEFAULT_STYLE,
                     "pace": DEFAULT_PACE, "temperature": DEFAULT_TEMP},
        "temperature": {"min": TEMP_MIN, "max": TEMP_MAX, "default": DEFAULT_TEMP},
        "max_chars": MAX_CHARS,
    }


# ---------------------------------------------------------------------------
# Prompt building (Thai "director's note" prefix + the script)
# ---------------------------------------------------------------------------
def build_prompt(text: str, *, style: str = DEFAULT_STYLE, pace: str = DEFAULT_PACE) -> str:
    """Compose the steerable Thai instruction Gemini TTS will speak.

    Style/Pace are natural-language hints (not API params) — Gemini TTS reads the
    leading instruction and applies it to the words that follow the colon.
    """
    lead = ["อ่านออกเสียงข้อความต่อไปนี้เป็นภาษาไทย"]
    s = _STYLE_HINT.get((style or "").strip())
    p = _PACE_HINT.get((pace or "").strip())
    if s:
        lead.append(s)
    if p:
        lead.append(p)
    return " ".join(lead) + ":\n" + text.strip()


# ---------------------------------------------------------------------------
# PCM → WAV (browser-playable + ffmpeg-muxable, no extra dependency)
# ---------------------------------------------------------------------------
def _rate_from_mime(mime: str) -> int:
    m = re.search(r"rate=(\d+)", mime or "")
    return int(m.group(1)) if m else _DEFAULT_RATE


def pcm_to_wav(pcm: bytes, *, rate: int = _DEFAULT_RATE, channels: int = 1,
               bits: int = 16) -> bytes:
    """Wrap raw little-endian PCM in a minimal WAV container."""
    byte_rate = rate * channels * bits // 8
    block_align = channels * bits // 8
    return (
        b"RIFF" + struct.pack("<I", 36 + len(pcm)) + b"WAVE"
        + b"fmt " + struct.pack("<IHHIIHH", 16, 1, channels, rate, byte_rate, block_align, bits)
        + b"data" + struct.pack("<I", len(pcm)) + pcm
    )


def _extract_audio(raw: bytes) -> bytes:
    """Pull the WAV bytes out of a Gemini generateContent(AUDIO) response."""
    try:
        data = json.loads(raw.decode("utf-8", "replace"))
    except (ValueError, AttributeError) as e:
        raise VoiceoverError("ตอบกลับจาก AI อ่านไม่ได้ (ไม่ใช่ JSON)") from e

    cands = data.get("candidates") or []
    for cand in cands:
        for part in (cand.get("content", {}).get("parts") or []):
            inline = part.get("inlineData") or part.get("inline_data")
            if inline and inline.get("data"):
                try:
                    pcm = base64.b64decode(inline["data"])
                except (ValueError, TypeError) as e:
                    raise VoiceoverError("เสียงที่ได้จาก AI เสียหาย (ถอดรหัสไม่ได้)") from e
                mime = inline.get("mimeType") or inline.get("mime_type") or ""
                # Already a container (rare)?  Pass through; else wrap raw PCM.
                if mime.startswith("audio/wav") or pcm[:4] == b"RIFF":
                    return pcm
                return pcm_to_wav(pcm, rate=_rate_from_mime(mime))
    # No audio — surface any text/error the model returned instead.
    fb = json.dumps(data.get("promptFeedback") or data.get("error") or {}, ensure_ascii=False)
    raise VoiceoverError(f"AI ไม่ส่งไฟล์เสียงกลับมา {fb[:300]}".strip())


# ---------------------------------------------------------------------------
# The call
# ---------------------------------------------------------------------------
def synthesize(text: str, *, voice: str = DEFAULT_VOICE, style: str = DEFAULT_STYLE,
               pace: str = DEFAULT_PACE, temperature: float = DEFAULT_TEMP,
               timeout: float = 60.0, _transport=None) -> bytes:
    """Return WAV bytes of *text* spoken by Gemini TTS.

    Raises :class:`VoiceoverUnavailable` if no key is configured, or
    :class:`VoiceoverError` on any provider/decoding failure (the caller decides
    how to surface it — a voiceover is optional, so a job need not hard-fail).

    ``_transport`` is a test seam: ``callable(url, body, headers, timeout) -> bytes``.
    """
    text = (text or "").strip()
    if not text:
        raise VoiceoverError("ยังไม่มีบทพูด — พิมพ์บทก่อนสร้างเสียง")
    if len(text) > MAX_CHARS:
        raise VoiceoverError(f"บทพูดยาวเกินไป (เกิน {MAX_CHARS} ตัวอักษร) — ตัดให้สั้นลง")

    key = llm.api_key()
    if not key:
        raise VoiceoverUnavailable("ยังไม่ได้ใส่ Gemini API key — เสียงพากย์ AI ต้องใช้คีย์")

    prompt = build_prompt(text, style=style, pace=pace)
    body = json.dumps({
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {
            "responseModalities": ["AUDIO"],
            "temperature": clean_temp(temperature),
            "speechConfig": {
                "voiceConfig": {
                    "prebuiltVoiceConfig": {"voiceName": resolve_voice(voice)}
                }
            },
        },
    }).encode("utf-8")
    url = _ENDPOINT.format(model=_model())
    headers = {"Content-Type": "application/json", "x-goog-api-key": key}

    try:
        if _transport is not None:
            raw = _transport(url, body, headers, timeout)
        else:
            raw = llm._http_post(url, body, headers, timeout)
    except llm.LLMError as e:
        # Reuse llm's friendly Thai HTTP/offline/quota messages, re-typed for TTS.
        raise VoiceoverError(str(e)) from e

    return _extract_audio(raw)


def synthesize_to_file(text: str, dst: str, **kwargs) -> str:
    """:func:`synthesize` then write the WAV to *dst*.  Returns *dst*."""
    wav = synthesize(text, **kwargs)
    with open(dst, "wb") as f:
        f.write(wav)
    return dst


# ---------------------------------------------------------------------------
# Script drafting (mode A: product info → Thai sales voiceover script)
# ---------------------------------------------------------------------------
def _extract_text(raw: bytes) -> str:
    """Pull the plain text out of a Gemini generateContent(text) response."""
    try:
        data = json.loads(raw.decode("utf-8", "replace"))
    except (ValueError, AttributeError) as e:
        raise VoiceoverError("ตอบกลับจาก AI อ่านไม่ได้ (ไม่ใช่ JSON)") from e
    for cand in (data.get("candidates") or []):
        texts = [pt.get("text", "") for pt in
                 (cand.get("content", {}).get("parts") or []) if pt.get("text")]
        if texts:
            return "\n".join(texts).strip()
    fb = json.dumps(data.get("promptFeedback") or data.get("error") or {}, ensure_ascii=False)
    raise VoiceoverError(f"AI ไม่ส่งบทกลับมา {fb[:300]}".strip())


def draft_script(product_info: str, *, target_seconds: int = 45,
                 timeout: float = 40.0, _transport=None) -> str:
    """Draft a natural Thai sales voiceover script from typed product info.

    Uses the Gemini *text* model (``llm.model()``), not the TTS model.  Returns
    spoken words only (no stage directions) — ready to drop into the editable
    script box.  Same failure semantics as :func:`synthesize`.
    """
    info = (product_info or "").strip()
    if not info:
        raise VoiceoverError("ยังไม่มีข้อมูลสินค้า — พิมพ์รายละเอียดก่อนให้ AI ร่างบท")
    key = llm.api_key()
    if not key:
        raise VoiceoverUnavailable("ยังไม่ได้ใส่ Gemini API key — ให้ AI ร่างบทต้องใช้คีย์")
    target_seconds = max(10, min(180, int(target_seconds or 45)))

    prompt = (
        "คุณเป็นนักเขียนบทพากย์เสียงโฆษณาสินค้าออนไลน์ภาษาไทยมืออาชีพ\n"
        f"เขียน \"บทพากย์เสียง\" สำหรับคลิปสั้นความยาวประมาณ {target_seconds} วินาที "
        "จากข้อมูลสินค้าด้านล่าง\n"
        "กติกา:\n"
        "- เป็นภาษาพูดที่ลื่นไหล เป็นธรรมชาติ ชวนซื้อแต่ไม่โอเวอร์\n"
        "- ส่งออกมาเป็น \"คำพูดที่จะให้เสียงอ่าน\" ล้วน ๆ ห้ามมีหัวข้อ วงเล็บ คำกำกับฉาก อีโมจิ หรือ bullet\n"
        f"- ยาวพอดีให้พูดจบใน ~{target_seconds} วินาที\n"
        "- ปิดท้ายด้วยประโยคชวนกดสั่งซื้อ/ทักแชท/ดูสินค้า\n\n"
        f"ข้อมูลสินค้า:\n{info}"
    )
    body = json.dumps({
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.8, "responseMimeType": "text/plain"},
    }).encode("utf-8")
    url = _ENDPOINT.format(model=llm.model())
    headers = {"Content-Type": "application/json", "x-goog-api-key": key}
    try:
        if _transport is not None:
            raw = _transport(url, body, headers, timeout)
        else:
            raw = llm._http_post(url, body, headers, timeout)
    except llm.LLMError as e:
        raise VoiceoverError(str(e)) from e
    return _extract_text(raw)
