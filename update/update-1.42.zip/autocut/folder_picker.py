"""Native folder chooser, run in its own process.

A Tk dialog must own the main thread, which the Flask/waitress worker threads
don't have — so the server shells out to a fresh process that runs *only* this
dialog and prints the selected path on stdout (empty line if cancelled).

Invoked as:
    AutoCutPro.exe --pick-folder        (frozen build; handled in launcher)
    python -m autocut.folder_picker     (from source)
"""

from __future__ import annotations


def pick(initial: str | None = None) -> str | None:
    try:
        import tkinter as tk
        from tkinter import filedialog
    except Exception:
        return None
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    try:
        path = filedialog.askdirectory(
            title="เลือกโฟลเดอร์สำหรับเก็บไฟล์ AI-SmartSale",
            initialdir=initial or None,
            mustexist=False,
        )
    finally:
        root.destroy()
    return path or None


def pick_file(initial: str | None = None) -> str | None:
    """Native "choose a video" dialog — returns the file's real path.

    Lets the app open a clip WITHOUT uploading/copying it (CapCut-style: the
    project just references the original file), so importing is instant.
    """
    try:
        import tkinter as tk
        from tkinter import filedialog
    except Exception:
        return None
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    try:
        path = filedialog.askopenfilename(
            title="เลือกวิดีโอเพื่อตัดต่อ",
            initialdir=initial or None,
            filetypes=[
                ("ไฟล์วิดีโอ", "*.mp4 *.mov *.mkv *.avi *.webm *.flv *.ts *.m4v "
                               "*.mpg *.mpeg *.wmv *.3gp"),
                ("ทุกไฟล์", "*.*"),
            ],
        )
    finally:
        root.destroy()
    return path or None


def pick_files(initial: str | None = None) -> list[str]:
    """Native "choose videos" dialog allowing MULTI-select (media library import).

    Returns the chosen paths (empty list when cancelled).
    """
    try:
        import tkinter as tk
        from tkinter import filedialog
    except Exception:
        return []
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    try:
        paths = filedialog.askopenfilenames(
            title="เลือกวิดีโอเข้าคลังมีเดีย (เลือกได้หลายไฟล์)",
            initialdir=initial or None,
            filetypes=[
                ("ไฟล์วิดีโอ", "*.mp4 *.mov *.mkv *.avi *.webm *.flv *.ts *.m4v "
                               "*.mpg *.mpeg *.wmv *.3gp"),
                ("ทุกไฟล์", "*.*"),
            ],
        )
    finally:
        root.destroy()
    return list(paths or [])


if __name__ == "__main__":
    import sys
    # The caller reads this path off stdout — force UTF-8 so a Thai file/folder
    # name can't raise UnicodeEncodeError (which would look like "cancelled").
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass
    if "--files" in sys.argv:              # multi-select → one path per line
        for _p in pick_files():
            print(_p)
    else:
        print((pick_file() if "--file" in sys.argv else pick()) or "")
