Thai caption fonts bundled with AutoCut (burned-in subtitles + UI previews).

  Kanit, Prompt, Mali, Itim      — Google Fonts, SIL Open Font License 1.1
  Noto Sans Thai                 — Noto Project,  SIL Open Font License 1.1

License: https://openfontlicense.org
These files are committed to the repo on purpose so builds never depend on
downloading them (packaging/payload/* is otherwise git-ignored).
