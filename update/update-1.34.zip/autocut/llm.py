"""Online "smart brain": let an LLM pick the review clips from the transcript.

Scope (current product):
  • provider: **Google Gemini** (model ``gemini-flash-latest`` + fallbacks), free tier, with a single
    **baked developer key** (``autocut/_secret.py``) so customers get AI with zero
    setup — no key paste, no backend;
  • input: the **transcript text + per-segment hints** — the offline cutter's
    structure label (intro / showcase / price / cart / summary) and the local
    visual-quality score — so the AI judges *content and shot quality* without
    sending heavy images (lighter on the shared free quota);
  • AI is a **smart layer over the offline cutter**: if the key is missing, the
    network is down, or the free quota is hit, the caller silently falls back to
    the offline "เข้าใจโครงคลิป" cut — a job never fails because of AI.

The LLM only *chooses which spoken segments* tell a coherent story (and which
key moments — price / cart / "ตะกร้า" — to keep).  The chosen segments then go
through the same finishing as the offline cutter
(``analyze.finish_clips``: merge → trim dead air → fit), so the length stays
within the target.

Networking is stdlib-only (urllib) so the frozen build needs no new dependency.
``select_story`` accepts an injectable ``_transport`` so the parsing / mapping
logic is unit-testable without hitting the network.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
import time
import urllib.error
import urllib.request

from . import storage
from .analyze import Clip

PROVIDER = "gemini"
# ``gemini-flash-latest`` is Google's maintained alias that always points at the
# current stable Flash model, so a Google-side deprecation (e.g. gemini-2.5-flash
# being pulled for new keys) doesn't break customers.  _MODEL_FALLBACKS is tried in
# order when a model returns 404 (deprecated / unavailable), and the first that
# works is remembered for the rest of the session.
DEFAULT_MODEL = "gemini-flash-latest"
_MODEL_FALLBACKS = ("gemini-flash-latest", "gemini-3.5-flash", "gemini-2.5-flash",
                    "gemini-2.0-flash", "gemini-flash-lite-latest")
_working_model: str | None = None       # cached once a model call succeeds

# Map the offline cutter's structure label → a short Thai hint shown to the AI.
_SECTION_TH = {"intro": "เปิดตัว", "showcase": "โชว์สินค้า", "price": "ราคา",
               "cta": "ตะกร้า", "summary": "สรุป", "body": ""}
_GET_KEY_URL = "https://aistudio.google.com/apikey"
_ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"

# Cutting modes — each just swaps the AI's "role" + what to prioritise, so ONE
# engine serves reviews, vlogs, tutorials, … (to add a use-case: add an entry).
MODES = {
    "review": {
        "label": "รีวิว / ขายของ",
        "role": "นักตัดต่อคลิปรีวิว/ขายของออนไลน์ภาษาไทยมืออาชีพ",
        "focus": "เก็บช่วงสำคัญ: เปิดตัวสินค้า, จุดเด่น/รีวิวการใช้งาน, ราคา/โปรโมชั่น, การกดสั่งซื้อ/ตะกร้า/ลิงก์",
    },
    "general": {
        "label": "ทั่วไป (อัตโนมัติ)",
        "role": "นักตัดต่อวิดีโอภาษาไทยมืออาชีพ",
        "focus": "เก็บช่วงที่เป็นใจความสำคัญและน่าสนใจที่สุด ให้ได้คลิปสั้นกระชับที่ยังเล่าเรื่องครบ",
    },
    "tutorial": {
        "label": "สอน / ติวเตอร์",
        "role": "นักตัดต่อคลิปสอน/ติวเตอร์ภาษาไทยมืออาชีพ",
        "focus": "เก็บขั้นตอนและประเด็นสำคัญตามลำดับ + บทสรุป/ทริค/ข้อควรระวัง ตัดช่วงเกริ่นยืดยาดและพูดนอกเรื่อง",
    },
    "vlog": {
        "label": "วล็อก / เล่าเรื่อง",
        "role": "นักตัดต่อคลิปวล็อก/เล่าเรื่องภาษาไทยมืออาชีพ",
        "focus": "เก็บช่วงที่เล่าเรื่องลื่นไหล มีอารมณ์ร่วมหรือเป็นไฮไลต์ ตัดช่วงเงียบ/น่าเบื่อ/ซ้ำ",
    },
}
DEFAULT_MODE = "review"


def valid_mode(mode) -> str:
    """Coerce an incoming mode string to a known one (default: review)."""
    return mode if mode in MODES else DEFAULT_MODE


class LLMUnavailable(RuntimeError):
    """AI mode is off, or no API key is configured."""


class LLMError(RuntimeError):
    """The provider call failed (network, bad key, bad response …)."""


class LLMModelUnavailable(LLMError):
    """The requested model is gone (404 — deprecated / not available for this key).
    The caller falls back to the next candidate model."""


# ---------------------------------------------------------------------------
# Configuration (stored in the app's config.json, alongside data_dir etc.)
# ---------------------------------------------------------------------------
def _cfg() -> dict:
    try:
        return storage.load_config()
    except Exception:  # noqa: BLE001
        return {}


def use_ai() -> bool:
    """Master switch — default **OFF** (offline-first).  The customer opts in from
    the settings UI ("ใช้ AI Gemini") *and* pastes their **own** API key; only then
    do cuts use Gemini.  A config ``use_ai: true`` (set by that switch) turns it on.
    If the key quota runs out or the network is down, the caller still falls back to
    the offline cutter automatically — so turning this on never breaks a job."""
    return bool(_cfg().get("use_ai", False))


def use_vision() -> bool:
    """Also send video thumbnails so the AI judges shots *visually* (skip camera
    moving / no subject / blurry) — not just "has speech".  Default ON; uses a bit
    more quota + time.  Set ``use_vision: false`` in config to turn off."""
    return bool(_cfg().get("use_vision", True))


def _baked_key() -> str:
    """The developer's key bundled in ``autocut/_secret.py`` (git-ignored, and
    excluded from OTA packages).  Returns '' if the file is absent (public repo /
    fresh clone) or empty."""
    try:
        from ._secret import GEMINI_KEY
        return (GEMINI_KEY or "").strip()
    except Exception:  # noqa: BLE001
        return ""


def api_key() -> str:
    """Resolve the key: customer override (config) > env var > baked dev key."""
    return (_cfg().get("llm_key")
            or os.environ.get("AUTOCUT_LLM_KEY")
            or os.environ.get("GEMINI_API_KEY")
            or _baked_key() or "").strip()


def model() -> str:
    return (_cfg().get("llm_model") or DEFAULT_MODEL).strip()


def enabled() -> bool:
    """AI mode is on AND a key is present → we will use the LLM."""
    return use_ai() and bool(api_key())


def required() -> bool:
    """Whether the customer *asked* for Gemini (switch on).  Note: even when true,
    the caller still falls back to the offline cutter on any AI failure (missing
    key / quota / offline) — turning AI on never makes a job hard-fail."""
    return use_ai()


def _key_source() -> str:
    if (_cfg().get("llm_key") or "").strip():
        return "config"
    if (os.environ.get("AUTOCUT_LLM_KEY") or os.environ.get("GEMINI_API_KEY") or "").strip():
        return "env"
    if _baked_key():
        return "baked"
    return "none"


def status() -> dict:
    """For the settings UI / debugging."""
    return {
        "provider": PROVIDER,
        "model": model(),
        "use_ai": use_ai(),
        "use_vision": use_vision(),
        "key_set": bool(api_key()),
        "key_source": _key_source(),
        "enabled": enabled(),
        "get_key_url": _GET_KEY_URL,
    }


def save_settings(*, use_ai=None, key=None, model_name=None) -> dict:
    cfg = _cfg()
    if use_ai is not None:
        cfg["use_ai"] = bool(use_ai)
    if key is not None:
        key = str(key).strip()
        if key:
            cfg["llm_key"] = key
        else:
            cfg.pop("llm_key", None)          # blank = clear the key
    if model_name:
        cfg["llm_model"] = str(model_name).strip()
    storage.save_config(cfg)
    return status()


# ---------------------------------------------------------------------------
# Prompt + response handling
# ---------------------------------------------------------------------------
def _hint_tag(hints, s) -> str:
    """A compact "«โชว์สินค้า·ภาพ✓»" annotation for one segment, from the offline
    cutter's structure label + local visual score (keyed by round(start, 2))."""
    h = hints.get(round(s.start, 2)) if hints else None
    if not h:
        return ""
    sec = _SECTION_TH.get(h.get("section", ""), "")
    v = h.get("visual")
    vt = "" if v is None else ("ภาพ✓" if v >= 0.6 else "ภาพ✗")
    inside = "·".join(x for x in (sec, vt) if x)
    return f" «{inside}»" if inside else ""


def _hint_rule(hints) -> str:
    """Explain the «...» hints to the model (only when hints are supplied)."""
    if not hints:
        return ""
    return (
        "- ในวงเล็บ «...» คือคำใบ้จากระบบ: **บทบาทของช่วง** (เปิดตัว/โชว์สินค้า/ราคา/ตะกร้า/สรุป) "
        "และ **คุณภาพภาพ** (ภาพ✓ = เห็นคน/สินค้าชัด · ภาพ✗ = ภาพไม่สื่อ/เบลอ/มืด/กำลังยกกล้อง)\n"
        "- ใช้คำใบ้ช่วยตัดสินใจ: ช่วง «ภาพ✗» ส่วนใหญ่ควร **ตัดทิ้งแม้จะมีเสียงพูด**; "
        "ช่วง โชว์สินค้า/ราคา/ตะกร้า/สรุป มักเป็นหัวใจของคลิป **ควรเก็บไว้**\n")


def _build_prompt(segs, target_seconds: float, mode: str = DEFAULT_MODE,
                  vision: bool = False, hints: dict | None = None) -> str:
    m = MODES.get(mode, MODES[DEFAULT_MODE])
    if vision:
        intro = ("ด้านล่างจะส่ง 'ประโยคที่ถอดเสียง' พร้อม **ภาพตัวอย่างจากวิดีโอของแต่ละช่วง** "
                 "มาให้ (แต่ละช่วงมี [i] เวลา ข้อความ แล้วตามด้วยรูปของช่วงนั้น)\n\n")
        transcript_block = ""           # the per-segment text+image parts carry it
        visual_rule = (
            "- **กฎเรื่องภาพ (สำคัญที่สุด) — ดูภาพของแต่ละช่วงด้วย ไม่ใช่มีเสียงพูดก็เอามาหมด:**\n"
            "  เก็บเฉพาะช่วงที่ **ภาพสื่อถึงเนื้อหาที่กำลังพูด** — เห็น **คนกำลังพูด/รีวิว** "
            "หรือเห็น **สิ่งที่กำลังพูดถึง** (เช่น สินค้า/ของที่รีวิว/หัวข้อ) อย่างชัดเจน ภาพดูรู้เรื่อง\n"
            "  ถ้าภาพ **ไม่สื่ออะไร** เช่น เห็นแต่ลำตัว/ขา/มือเปล่า/พื้น/กระเบื้อง/กำแพง/เพดาน "
            "หรือกำลังยก-หันกล้อง ภาพสั่น/เบลอ/มืด — ให้ **ตัดทิ้ง แม้จะมีเสียงพูดก็ตาม**\n")
    else:
        lines = [f"[{i}] ({s.start:.1f}-{s.end:.1f}s){_hint_tag(hints, s)} {s.text.strip()}"
                 for i, s in enumerate(segs)]
        intro = ("ด้านล่างคือ 'ประโยคที่ถอดเสียงจากวิดีโอ' แต่ละบรรทัดมีหมายเลข [i] ช่วงเวลา "
                 "และคำใบ้จากระบบในวงเล็บ «...»\n\n")
        transcript_block = "\n".join(lines) + "\n\n"
        visual_rule = _hint_rule(hints)
    return (
        f"คุณเป็น{m['role']}\n"
        + intro + transcript_block +
        f"งานของคุณ: เลือกชุดช่วงที่ร้อยเรียงเป็น 'เรื่องราวต่อเนื่อง' สำหรับคลิปยาวประมาณ "
        f"{target_seconds:.0f} วินาที โดย:\n"
        f"- {m['focus']}\n"
        + visual_rule +
        "- ตัดช่วงน้ำท่วมทุ่ง พูดวกวน พูดนอกเรื่อง หรือซ้ำ\n"
        "- เรียงตามลำดับเวลาเดิม (ห้ามสลับ) และอย่าตัดกลางความคิด ให้เนื้อหาฟังรู้เรื่อง\n"
        "- **เลือกเป็นช่วงต่อเนื่องยาว ๆ ดีกว่ากระโดดเก็บทีละประโยค** — อย่าข้ามประโยคที่เชื่อมเรื่อง "
        "เพราะการกระโดดข้ามจะทำให้คนดูรู้สึกว่า 'ตัดสะดุด/หายไปดื้อ ๆ'\n"
        "- เลือกให้รวมความยาวใกล้เคียงเป้าหมาย (ระบบจะปรับให้พอดีเป๊ะภายหลังเอง)\n\n"
        'ตอบเป็น JSON เท่านั้น รูปแบบ: {"clips":[<หมายเลข>, ...]} '
        "เรียงจากน้อยไปมากตามเวลา ไม่ต้องมีคำอธิบายอื่น"
    )


def _build_parts(segs, target_seconds: float, mode: str, frames,
                 hints: dict | None = None) -> list[dict]:
    """Gemini ``contents.parts`` — text-only (with structure/visual *hints*), or
    text+image interleaved per segment when *frames* (``{seg_index: base64-jpeg}``)
    is given (legacy multimodal path)."""
    if not frames:
        return [{"text": _build_prompt(segs, target_seconds, mode, vision=False, hints=hints)}]
    parts: list[dict] = [{"text": _build_prompt(segs, target_seconds, mode, vision=True)}]
    for i, s in enumerate(segs):
        parts.append({"text": f"[{i}] ({s.start:.1f}-{s.end:.1f}s) {s.text.strip()}"})
        b64 = frames.get(i)
        if b64:
            parts.append({"inline_data": {"mime_type": "image/jpeg", "data": b64}})
    return parts


def _parse_indices(raw: str, n: int) -> list[int]:
    """Pull the chosen segment indices out of the model's JSON reply, defensively."""
    text = (raw or "").strip()
    if text.startswith("```"):  # strip ```json … ``` fences if present
        text = re.sub(r"^```[a-zA-Z]*\s*|\s*```$", "", text).strip()
    data = None
    try:
        data = json.loads(text)
    except ValueError:
        m = re.search(r"\{.*\}|\[.*\]", text, re.DOTALL)
        if m:
            try:
                data = json.loads(m.group(0))
            except ValueError:
                data = None
    items = []
    if isinstance(data, dict):
        items = data.get("clips") or data.get("indices") or data.get("segments") or []
    elif isinstance(data, list):
        items = data
    if not isinstance(items, list):     # guard against an unexpected shape
        items = []
    out: list[int] = []
    seen: set[int] = set()
    for it in items:
        idx = it.get("i") if isinstance(it, dict) else it
        try:
            idx = int(idx)
        except (TypeError, ValueError):
            continue
        if 0 <= idx < n and idx not in seen:
            seen.add(idx)
            out.append(idx)
    return out


# Gemini's free tier returns 503 "high demand / UNAVAILABLE" in short bursts, so a
# single retry often isn't enough — retry a few times with exponential backoff so a
# transient spike is ridden out automatically instead of forcing the user to re-click.
_HTTP_TRIES = 4          # total attempts on a transient failure (429 / 5xx / network)
_HTTP_BACKOFF_CAP = 6.0  # seconds


def _http_post(url: str, body: bytes, headers: dict, timeout: float) -> bytes:
    """POST, retrying transient failures (network blip / 429 / 5xx) with backoff."""
    last: Exception | None = None
    for attempt in range(_HTTP_TRIES):
        req = urllib.request.Request(url, data=body, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read()
        except urllib.error.HTTPError as e:  # 4xx/5xx — surface a useful Thai message
            if e.code == 404:                # model deprecated / not found → try another
                raise LLMModelUnavailable("โมเดลนี้ใช้ไม่ได้แล้ว") from e
            if e.code in (400, 403):         # bad key / no access → no point retrying
                raise LLMError("API key ไม่ถูกต้องหรือไม่มีสิทธิ์ใช้งาน — ตรวจสอบคีย์ Gemini") from e
            if e.code in (429, 500, 502, 503, 504) and attempt < _HTTP_TRIES - 1:
                last = e
                time.sleep(min(1.5 * (2 ** attempt), _HTTP_BACKOFF_CAP))   # 1.5 → 3 → 6s
                continue                     # transient → keep retrying
            if e.code == 429:
                raise LLMError("ใช้ Gemini เกินโควต้าฟรีชั่วคราว — รอสักครู่แล้วลองใหม่") from e
            if e.code in (500, 502, 503, 504):   # model busy / server hiccup
                raise LLMError("ตอนนี้ AI มีผู้ใช้งานเยอะ (โมเดลไม่ว่าง) — ลองใหม่อีกครั้งในอีกสักครู่") from e
            detail = ""
            try:
                detail = e.read().decode("utf-8", "replace")[:300]
            except Exception:  # noqa: BLE001
                pass
            raise LLMError(f"เรียก AI ไม่สำเร็จ (HTTP {e.code}) {detail}") from e
        except urllib.error.URLError as e:   # offline / DNS / timeout
            if attempt < _HTTP_TRIES - 1:
                last = e
                time.sleep(min(1.5 * (2 ** attempt), _HTTP_BACKOFF_CAP))
                continue                     # transient → keep retrying
            raise LLMError("เชื่อมต่ออินเทอร์เน็ตไม่ได้ — ฟีเจอร์ AI ต้องใช้เน็ต (ลองใหม่อีกครั้ง)") from e
    raise LLMError("เชื่อมต่อ AI ไม่สำเร็จ — ลองใหม่อีกครั้ง") from last


def _gemini_call(parts: list[dict], key: str, model_name: str, timeout: float,
                 transport, *, thinking_budget: int | None = None) -> str:
    """POST a Gemini ``generateContent`` request (text-only or multimodal) and
    return the model's text reply.

    ``thinking_budget`` (Gemini 2.5+) caps the model's internal reasoning tokens;
    pass 0 to turn thinking OFF for simple, latency-sensitive tasks (e.g. subtitle
    text cleanup — several seconds faster)."""
    global _working_model
    gen_cfg = {"temperature": 0.2, "responseMimeType": "application/json"}
    if thinking_budget is not None:
        gen_cfg["thinkingConfig"] = {"thinkingBudget": int(thinking_budget)}
    body = json.dumps({
        "contents": [{"role": "user", "parts": parts}],
        "generationConfig": gen_cfg,
    }).encode("utf-8")
    headers = {"Content-Type": "application/json"}

    # Try the requested model first (or the one already known to work this session),
    # then the fallbacks — so a Google-side deprecation just rolls to the next model.
    candidates: list[str] = []
    for m in (_working_model, model_name, *_MODEL_FALLBACKS):
        if m and m not in candidates:
            candidates.append(m)

    last: Exception | None = None
    for m in candidates:
        url = _ENDPOINT.format(model=m) + f"?key={key}"
        try:
            raw = transport(url, body, headers) if transport else _http_post(url, body, headers, timeout)
        except LLMModelUnavailable as e:
            last = e
            continue                         # this model is gone → try the next one
        _working_model = m                   # remember the model that answered
        try:
            data = json.loads(raw)
            return data["candidates"][0]["content"]["parts"][0]["text"]
        except (ValueError, KeyError, IndexError, TypeError) as e:
            raise LLMError("AI ตอบกลับมาในรูปแบบที่อ่านไม่ได้") from e
    raise last or LLMError("ไม่พบโมเดล Gemini ที่ใช้งานได้ — อัปเดตแอปเป็นเวอร์ชันล่าสุด")


# ---------------------------------------------------------------------------
# Result cache — reuse a past selection for the same transcript+target so a
# re-cut of the same video doesn't spend quota again.  Best-effort & fail-safe:
# any cache error is swallowed and we just call the API.
# ---------------------------------------------------------------------------
def _cache_path() -> str:
    base = os.environ.get("AUTOCUT_DATA_DIR")
    if base:
        return os.path.join(base, "ai_cache.json")
    base = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or tempfile.gettempdir()
    return os.path.join(base, "AutoCutPro", "ai_cache.json")


def _cache_key(segs, target: float, mode: str = DEFAULT_MODE, vision: bool = False,
               hinted: bool = False) -> str:
    blob = "\n".join(f"{s.start:.2f}|{s.end:.2f}|{s.text.strip()}" for s in segs)
    tag = ("v" if vision else "t") + ("h" if hinted else "")
    return hashlib.sha256(
        f"{model()}|{mode}|{tag}|{int(round(target))}|{blob}".encode("utf-8")).hexdigest()


def _cache_load() -> dict:
    try:
        with open(_cache_path(), encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:  # noqa: BLE001
        return {}


def _cache_get(key: str):
    entry = _cache_load().get(key)
    if isinstance(entry, list):
        try:
            return [Clip(float(c["start"]), float(c["end"]), c.get("text", "")) for c in entry]
        except Exception:  # noqa: BLE001
            return None
    return None


def _cache_put(key: str, clips: list[Clip]) -> None:
    try:
        data = _cache_load()
        data[key] = [{"start": c.start, "end": c.end, "text": c.text} for c in clips]
        if len(data) > 300:                        # keep the file bounded
            for k in list(data)[: len(data) - 300]:
                data.pop(k, None)
        path = _cache_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
        os.replace(tmp, path)                       # atomic replace
    except Exception:  # noqa: BLE001 — caching must never break a job
        pass


# ---------------------------------------------------------------------------
# Public: pick the story
# ---------------------------------------------------------------------------
def select_story(transcript, target_seconds: float, *, mode: str = DEFAULT_MODE,
                 frames=None, hints=None, log=None, timeout: float = 90.0,
                 use_cache: bool = True, _transport=None) -> list[Clip]:
    """Ask the LLM which transcript segments form a coherent ~target-second story.

    ``mode`` picks the use-case prompt (review / general / tutorial / vlog).
    ``frames`` (``{seg_index: base64-jpeg}``) turns on **visual analysis**: each
    segment's thumbnail is sent too, so the AI rejects bad shots (camera moving,
    no subject, blurry) — not just "has speech → keep".  Cached by
    transcript+target+mode+vision so re-cutting the same video is free.
    ``_transport`` is a test injection point: ``callable(url, body, headers) -> bytes``.
    """
    mode = valid_mode(mode)
    key = api_key()
    if not key:
        raise LLMUnavailable("ยังไม่ได้ตั้งค่า Gemini API key ในหน้าตั้งค่า")
    segs = [s for s in transcript.segments
            if (s.end - s.start) >= 0.2 and s.text and s.text.strip()]
    if not segs:
        return []

    ckey = _cache_key(segs, target_seconds, mode, bool(frames), bool(hints)) if use_cache else ""
    if ckey:
        cached = _cache_get(ckey)
        if cached is not None:
            if log:
                log(f"♻️ ใช้ผลวิเคราะห์ AI ที่เคยทำกับคลิปนี้ — ไม่เปลืองโควต้า ({len(cached)} ช่วง)")
            return cached

    parts = _build_parts(segs, target_seconds, mode, frames, hints)
    raw = _gemini_call(parts, key, model(), timeout, _transport)
    idxs = _parse_indices(raw, len(segs))
    if not idxs:
        raise LLMError("AI ไม่ได้เลือกช่วงใดเลย — ลองใหม่อีกครั้ง")
    clips = [Clip(segs[i].start, segs[i].end, segs[i].text.strip()) for i in idxs]
    clips.sort(key=lambda c: c.start)
    if ckey:
        _cache_put(ckey, clips)
    if log:
        log(f"🧠 Gemini เลือก {len(clips)} ช่วง{' (ดูภาพ+เสียง)' if frames else ''} "
            f"จาก {len(segs)} ประโยค")
    return clips


def test_key(*, timeout: float = 20.0, _transport=None) -> tuple[bool, str]:
    """Validate the configured key with a tiny request (for the 'ทดสอบ' button)."""
    key = api_key()
    if not key:
        return False, "ยังไม่ได้ใส่ API key"
    try:
        _gemini_call([{"text": 'ตอบเป็น JSON: {"ok":true}'}], key, model(), timeout, _transport)
        return True, "เชื่อมต่อ Gemini สำเร็จ ✓"
    except (LLMError, LLMUnavailable) as e:
        return False, str(e)
