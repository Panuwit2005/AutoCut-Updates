"""AutoCut — automatic review-video editor (fully offline).

    media       — probe + codec-agnostic normalization (handles "any codec")
    analyze     — pick spoken parts by word timing / silence + trim dead air
    transcribe  — Thonburian Whisper th-large-v2 (Thai word timing + subtitle text)
    captions    — Thai/English subtitle lines → HarfBuzz/FreeType overlay (ASS fallback)
    editor      — cut / concat / music-mix / MP3 / colour adjust (ffmpeg)
    tools       — locate ffmpeg / ffprobe and run them safely
    storage     — choose a roomy data dir + build the output folder
    licensing   — machine-locked activation (Ed25519)
    updater     — signed OTA code updates

Orchestrated from ``app.py``; the full-screen editor UI lives in ``editor.html``.
"""

__version__ = "1.34"
