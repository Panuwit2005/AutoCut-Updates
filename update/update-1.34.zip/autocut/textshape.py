"""Correct Thai caption rendering via HarfBuzz + FreeType (bypasses libass).

libass drops/overlaps Thai *stacked* marks (upper-vowel + tone, e.g. "ที่", "นี่")
even with HarfBuzz available — the tone lands on top of the vowel instead of
above it.  Klipr-quality Thai needs a real shaper, so we shape each line with
HarfBuzz (which correctly substitutes the pre-raised mark glyphs the fonts ship)
and rasterise the exact glyphs with FreeType into an RGBA image, then ffmpeg
overlays those images on the video.

Optional deps (uharfbuzz + freetype-py + numpy).  ``available()`` is False when
any is missing, so captions.burn() falls back to the old ASS path.
"""

from __future__ import annotations

import struct


def available() -> bool:
    try:
        import freetype  # noqa: F401
        import numpy  # noqa: F401
        import uharfbuzz  # noqa: F401
        return True
    except Exception:  # noqa: BLE001
        return False


def _raster_row(text: str, font_path: str, px: int):
    """Shape one row with HarfBuzz and rasterise the substituted glyphs with
    FreeType.  Returns an ``(H, W)`` float32 alpha map (0..1), or None if empty."""
    import freetype
    import numpy as np
    import uharfbuzz as hb

    blob = hb.Blob.from_file_path(font_path)
    face = hb.Face(blob)
    font = hb.Font(face)
    upem = face.upem
    font.scale = (upem, upem)
    buf = hb.Buffer()
    buf.add_str(text)
    buf.guess_segment_properties()
    hb.shape(font, buf)
    sc = px / upem

    ft = freetype.Face(font_path)
    ft.set_pixel_sizes(0, px)

    glyphs = []
    x = 0.0
    minx = miny = 1e9
    maxx = maxy = -1e9
    for info, pos in zip(buf.glyph_infos, buf.glyph_positions):
        ft.load_glyph(info.codepoint, freetype.FT_LOAD_RENDER)
        bmp = ft.glyph.bitmap
        w, h = bmp.width, bmp.rows
        gx = x + pos.x_offset * sc + ft.glyph.bitmap_left
        gy = -(pos.y_offset * sc) - ft.glyph.bitmap_top   # y grows downward
        if w and h:
            arr = np.array(bmp.buffer, dtype=np.uint8).reshape(h, w)
            glyphs.append((gx, gy, arr))
            minx = min(minx, gx)
            maxx = max(maxx, gx + w)
            miny = min(miny, gy)
            maxy = max(maxy, gy + h)
        x += pos.x_advance * sc

    if not glyphs:
        return None
    W = int(np.ceil(maxx - minx)) + 2
    H = int(np.ceil(maxy - miny)) + 2
    canvas = np.zeros((H, W), np.float32)
    for gx, gy, arr in glyphs:
        px0 = int(round(gx - minx))
        py0 = int(round(gy - miny))
        h, w = arr.shape
        sub = canvas[py0:py0 + h, px0:px0 + w]
        np.maximum(sub, arr.astype(np.float32) / 255.0, out=sub)
    return canvas


def _dilate(alpha, r: int):
    """Grayscale circular dilation — grows the text alpha by *r* px for a clean
    uniform outline (marks stay separate because they're correctly stacked)."""
    import numpy as np
    if r <= 0:
        return alpha
    H, W = alpha.shape
    out = alpha.copy()
    for dy in range(-r, r + 1):
        for dx in range(-r, r + 1):
            if dx * dx + dy * dy > r * r:
                continue
            shifted = np.zeros_like(alpha)
            ys, ye = max(0, dy), min(H, H + dy)
            xs, xe = max(0, dx), min(W, W + dx)
            shifted[ys:ye, xs:xe] = alpha[ys - dy:ye - dy, xs - dx:xe - dx]
            np.maximum(out, shifted, out=out)
    return out


def render_block(rows: list[str], font_path: str, px: int,
                 fill=(255, 255, 255), outline=(0, 0, 0), outline_px: int = 4,
                 shadow: int = 0):
    """Render one caption (possibly several wrapped rows) to an RGBA numpy array.

    Rows are centred and stacked.  Fill is drawn over a dilated outline layer."""
    import numpy as np
    row_imgs = [r for r in (_raster_row(t, font_path, px) for t in rows) if r is not None]
    if not row_imgs:
        return None
    gap = int(px * 0.24)
    W = max(r.shape[1] for r in row_imgs)
    total_h = sum(r.shape[0] for r in row_imgs) + gap * (len(row_imgs) - 1)
    alpha = np.zeros((total_h, W), np.float32)
    y = 0
    for r in row_imgs:
        h, w = r.shape
        x0 = (W - w) // 2
        dst = alpha[y:y + h, x0:x0 + w]
        np.maximum(dst, r, out=dst)
        y += h + gap

    pad = outline_px + max(2, shadow + 2)
    A = np.pad(alpha, pad)
    oa = _dilate(A, outline_px) if outline_px > 0 else np.zeros_like(A)
    H, Wp = A.shape
    rgba = np.zeros((H, Wp, 4), np.uint8)

    if shadow > 0:                                    # soft drop shadow (offset)
        sh = np.zeros_like(A)
        s = shadow
        sh[s:, s:] = A[:H - s, :Wp - s]
        oa = np.maximum(oa, sh * 0.6)

    comb = A + oa * (1 - A)                            # fill over outline
    for c in range(3):
        col = fill[c] * A + outline[c] * oa * (1 - A)
        with np.errstate(invalid="ignore", divide="ignore"):
            rgba[..., c] = np.where(comb > 1e-4,
                                    np.clip(col / np.maximum(comb, 1e-6), 0, 255),
                                    0).astype(np.uint8)
    rgba[..., 3] = np.clip(comb * 255, 0, 255).astype(np.uint8)
    return rgba


def write_pam(rgba, path: str) -> None:
    """Write an RGBA numpy array as a binary PAM (P7) — ffmpeg reads it natively,
    so we need no Pillow/PNG encoder."""
    import numpy as np
    h, w = rgba.shape[:2]
    hdr = (f"P7\nWIDTH {w}\nHEIGHT {h}\nDEPTH 4\nMAXVAL 255\n"
           f"TUPLTYPE RGB_ALPHA\nENDHDR\n").encode("ascii")
    with open(path, "wb") as f:
        f.write(hdr)
        f.write(np.ascontiguousarray(rgba, dtype=np.uint8).tobytes())


# keep struct imported (some linters flag unused); used by callers extending PAM
_ = struct
