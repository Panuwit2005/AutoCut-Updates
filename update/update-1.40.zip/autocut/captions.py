"""Burn animated captions into a finished video — 100% local, free, every machine.

Runs AFTER cutting, on the *final* video (so word timings match what's heard):

  1. Transcribe the final video (Whisper) for per-word timing.
  2. Group words into natural caption lines — **AI (Gemini)** re-segments Thai/ม-
     English into real words (Whisper alone returns sub-word chunks that split
     mid-word); falls back to an offline heuristic when AI is off/unavailable.
  3. Author an **ASS** subtitle file with our style presets + animation
     (pop-in scale, karaoke word-highlight, colour, box, glow) — libass tags.
  4. Burn it in with **ffmpeg** (the ``subtitles`` filter).  No Node/Chrome/cloud.
  5. Optionally write a sidecar ``.srt``.

FAIL-SAFE CONTRACT: if ffmpeg is missing, transcription fails, or anything in the
render fails, this returns the ORIGINAL video unchanged and logs a warning.  A
caption failure must never sink the job.
"""

from __future__ import annotations

import base64
import json
import os
import re
import sys
import tempfile
import time

from . import tools, transcribe
from .transcribe import Word

try:
    from . import llm
except Exception:  # noqa: BLE001 — llm is optional; offline segmentation still works
    llm = None


# ---------------------------------------------------------------------------
# Style presets → ASS styling.  Colours are #RRGGBB (converted to ASS &HAABBGGRR).
#   fill = text colour · out = outline · back = box/shadow colour
#   border: 1 = outline+shadow, 3 = opaque box behind the text
#   back_a: ASS alpha for the box (00 = opaque … FF = transparent)
#   karaoke: highlight each word as it's spoken (sec = the "not yet said" colour)
# ---------------------------------------------------------------------------
# ``outw_r`` = outline width as a FRACTION of the font size (not fixed px).  A
# thick outline (>~5% of the font) merges Thai's stacked vowel+tone marks into a
# blob ("จม/ซ้อน"), so it's kept ≤~0.05 and scales with the caption size.
STYLE_PRESETS: dict[str, dict] = {
    "clean":     {"fill": "#FFFFFF", "out": "#000000", "border": 1, "outw_r": 0.040, "shadow": 1, "bold": 1},
    "box":       {"fill": "#FFFFFF", "out": "#000000", "back": "#000000", "back_a": 0x33, "border": 3, "outw_r": 0.030, "shadow": 0, "bold": 1},
    "pop":       {"fill": "#FFD400", "out": "#000000", "border": 1, "outw_r": 0.045, "shadow": 2, "bold": 1},
    "neon":      {"fill": "#2FFFB0", "out": "#06FFA5", "border": 1, "outw_r": 0.032, "shadow": 0, "bold": 1, "blur": 3},
    "karaoke":   {"fill": "#FFD400", "sec": "#FFFFFF", "out": "#000000", "border": 1, "outw_r": 0.040, "shadow": 1, "bold": 1, "karaoke": True},
    # NOTE: no letter-spacing on any Thai style — ASS ``Spacing`` is applied per
    # glyph, which shoves upper vowels/tone marks off their base ("สระ/วรรณยุกต์จม").
    "impact":    {"fill": "#FFFFFF", "out": "#000000", "border": 1, "outw_r": 0.045, "shadow": 2, "bold": 1},
    "boxYellow": {"fill": "#000000", "out": "#FFD400", "back": "#FFD400", "back_a": 0x00, "border": 3, "outw_r": 0.030, "shadow": 0, "bold": 1},
    "fire":      {"fill": "#FF6A1F", "out": "#FF2D00", "border": 1, "outw_r": 0.045, "shadow": 2, "bold": 1, "blur": 2},
}
DEFAULT_STYLE = "clean"

# Vertical placement → (ASS alignment code, margin-V as a fraction of height).
POSITIONS: dict[str, tuple[int, float]] = {
    "bottom": (2, 0.09),
    "center": (5, 0.0),
    "top":    (8, 0.09),
}

# Offline-segmentation tuning (fallback only).
_WORDS_PER_LINE = 6
_NATURAL_MAX_WORDS = 16    # high, so lines break on real PAUSES (between words), not mid-word
_NATURAL_GAP = 0.45

# Popular loopless ("ไม่มีหัว") Thai caption fonts, bundled in payload/fonts and
# loaded via libass ``fontsdir`` so mark stacking (สระบน+วรรณยุกต์) renders right.
# slug → the font's internal family name (what ASS Fontname / libass matches).
_FONTS: dict[str, str] = {
    "kanit":  "Kanit",           # ★ default — bold loopless, most popular for TH captions
    "prompt": "Prompt",          # clean modern loopless
    "mali":   "Mali",            # rounded, friendly
    "itim":   "Itim",            # rounded handwriting
    "noto":   "Noto Sans Thai",  # neutral loopless
}
# slug → actual TTF filename in the bundled fonts dir (for the HarfBuzz renderer)
_FONT_FILES: dict[str, str] = {
    "kanit":  "Kanit-Bold.ttf",
    "prompt": "Prompt-Bold.ttf",
    "mali":   "Mali-Bold.ttf",
    "itim":   "Itim-Regular.ttf",
    "noto":   "NotoSansThai-Bold.ttf",
}
DEFAULT_FONT = "kanit"


def _font_path(font: str) -> str | None:
    """Full path to the TTF for *font* (for the HarfBuzz/FreeType renderer)."""
    fd = _fonts_dir()
    if not fd:
        return None
    fn = _FONT_FILES.get(font, _FONT_FILES[DEFAULT_FONT])
    p = os.path.join(fd, fn)
    return p if os.path.isfile(p) else None


class Line:
    """One on-screen caption line (a list of timed words).

    ``style`` (optional) is a per-line override dict — {style, font, position,
    size, fill, outline, offset, anim} — so different timeline clips can each burn
    their subtitles in their own style.  None = use the burn call's defaults."""

    __slots__ = ("start", "end", "words", "style")

    def __init__(self, start: float, end: float, words: list, style: dict | None = None):
        self.start = start
        self.end = end
        self.words = words
        self.style = style

    @property
    def text(self) -> str:
        # Join with no spaces — Thai doesn't space words, and Whisper's Thai tokens
        # are sub-word pieces, so spacing them would look broken.
        return "".join(w.text for w in self.words).strip()


# ---------------------------------------------------------------------------
# Segmentation — AI (primary) + offline (fallback)
# ---------------------------------------------------------------------------
# Thai combining marks (upper/lower vowels + tone marks).  A token must never
# START with one of these — it means Whisper split mid-word; the mark would
# render on a dotted circle / stack wrongly ("สระซ้อน") and the line break would
# cut a word in half ("วันนี้ผ มจะมา").
_THAI_MARKS = set("ัำิีึืฺุู"
                  "็่้๊๋์ํ๎")


# Trailing vowels/signs that can never START a Thai word either — a token that
# begins with one of these is also a mid-word split and must merge backward.
_THAI_NO_START = _THAI_MARKS | set("ะาๆฯ")

# The app supports Thai (primary) + English (secondary) only.  Whisper sometimes
# hallucinates Arabic/CJK/Cyrillic on noisy or musical passages; those characters
# would burn into the video as garbage, so strip them before segmentation.
_ALLOWED_RE = re.compile(
    r"[^฀-๿A-Za-z0-9\s\.,!\?\-–—'\"…:;()%฿+&/@#*=]")


def _clean_foreign(words: list) -> list:
    """Drop characters outside the Thai/English/basic-punctuation repertoire.
    Tokens that end up empty (pure foreign-script hallucinations) are removed."""
    out: list = []
    for w in words:
        t = _ALLOWED_RE.sub("", w.text or "")
        if t.strip():
            out.append(Word(w.start, w.end, t))
    return out


def _merge_orphan_marks(words: list) -> list:
    """Merge any token that starts with a Thai combining mark (or a trailing
    vowel like Sara A / Sara Aa) into the previous token, so a line break can
    never orphan a vowel/tone mark or split a word."""
    out: list = []
    for w in words:
        t = (w.text or "")
        first = t.lstrip()[:1]
        if out and first and first in _THAI_NO_START:
            prev = out[-1]
            out[-1] = Word(prev.start, w.end, prev.text + t.lstrip())
        else:
            out.append(w)
    return out


def _char_times(words: list) -> list[tuple[float, float]]:
    """(start, end) for EVERY character of ``''.join(w.text)`` — each word's
    duration spread evenly across its characters, so a re-grouped substring can
    be mapped back to a precise time span."""
    out: list[tuple[float, float]] = []
    for w in words:
        n = max(1, len(w.text))
        dur = max(0.0, w.end - w.start)
        for i in range(len(w.text)):
            out.append((w.start + dur * i / n, w.start + dur * (i + 1) / n))
    return out


def _seg_prompt(full: str) -> str:
    return (
        "คุณเป็นเครื่องมือจัดบรรทัดซับไตเติลภาษาไทย (สำหรับคลิปสั้น TikTok/Reels)\n"
        "ด้านล่างคือข้อความถอดเสียง (ไทย/อังกฤษปนกัน มักไม่มีเว้นวรรค):\n\n"
        f"{full}\n\n"
        "งาน: แบ่งเป็น 'บรรทัดซับ' สั้น ๆ อ่านง่าย โดย:\n"
        "- แต่ละบรรทัด 2-5 คำ กระชับ\n"
        "- แบ่งคำให้ถูกต้อง (คำไทยเต็มคำ ห้ามตัดกลางคำ, คำอังกฤษเป็นคำเต็ม)\n"
        "- ขึ้นบรรทัดใหม่ตามจังหวะพูด/วรรคตอนที่เป็นธรรมชาติ\n"
        "- **ห้ามเพิ่ม/ลบ/แก้ตัวอักษรใด ๆ** เรียงตัวอักษรเดิมทุกตัว แค่ตัดสินใจขอบเขตคำ+บรรทัด\n\n"
        'ตอบเป็น JSON เท่านั้น: {"lines": [["คำ","คำ"], ["คำ","คำ","คำ"]]}\n'
        "โดยนำทุกคำมาต่อกัน (ไม่มีเว้นวรรค) ต้องเท่ากับข้อความเดิมเป๊ะ"
    )


def _ai_segment_lines(tr, *, log=None) -> list[Line] | None:
    """Use Gemini to group Whisper's sub-word tokens into natural caption lines
    with correct word boundaries + per-word timing.  None if AI is unavailable or
    its answer doesn't line up with the transcript (→ caller uses the offline path)."""
    if not (llm and llm.enabled()):
        return None
    words = _merge_orphan_marks(_clean_foreign(
        [w for w in tr.words if w.text and w.text.strip()]))
    if not words:
        return None
    full = "".join(w.text for w in words)
    ctimes = _char_times(words)
    try:
        raw = llm._gemini_call([{"text": _seg_prompt(full)}],
                               llm.api_key(), llm.model(), 60.0, None)
        data = json.loads(re.sub(r"^```[a-zA-Z]*|```$", "", raw.strip()).strip())
        groups = data.get("lines") if isinstance(data, dict) else None
    except Exception as e:  # noqa: BLE001
        if log:
            log(f"⚠️ AI จัดคำไม่สำเร็จ ({e}) — ใช้ตัวจัดคำสำรอง")
        return None
    if not isinstance(groups, list) or not groups:
        return None

    lines: list[Line] = []
    idx = 0                                   # cursor over `full` / `ctimes`
    n = len(full)
    for group in groups:
        if not isinstance(group, list):
            continue
        lw: list[Word] = []
        for tok in group:
            chars = [c for c in str(tok) if not c.isspace()]
            if not chars:
                continue
            wstart = wend = None
            got = 0
            while idx < n and got < len(chars):
                if not full[idx].isspace():
                    if wstart is None:
                        wstart = ctimes[idx][0]
                    wend = ctimes[idx][1]
                    got += 1
                idx += 1
            if wstart is not None:
                lw.append(Word(wstart, wend, str(tok).strip()))
        if lw:
            lines.append(Line(lw[0].start, lw[-1].end, lw))
    # If the AI dropped a lot, fall back to the offline segmenter (keeps ALL words).
    if not lines or idx < n * 0.65:
        if log:
            log("⚠️ ผล AI ไม่ตรงกับเสียง — ใช้ตัวจัดคำสำรอง")
        return None
    # Otherwise append any leftover tail so no spoken words go missing.
    if idx < n:
        tail = full[idx:].strip()
        if tail and idx < len(ctimes):
            lines.append(Line(ctimes[idx][0], ctimes[-1][1],
                              [Word(ctimes[idx][0], ctimes[-1][1], tail)]))
    return lines


def _ai_transcribe_prompt(segment: str = "natural") -> str:
    # How to break the speech into subtitle lines (user's "การแบ่งซับไตเติล").
    rule2 = {
        "none":     "2) อย่าแบ่งบรรทัด — รวมคำพูดทั้งหมดไว้ใน 1 บรรทัดเดียว",
        "words":    "2) แบ่งเป็นบรรทัดสั้นมาก บรรทัดละประมาณ 2-3 คำ (ขึ้นทีละน้อยตามจังหวะพูด)",
        "sentence": "2) แบ่งเป็นประโยคสั้น — 1 บรรทัดต่อ 1 ประโยค ถ้าประโยคยาวให้ตัดเป็นวรรคสั้นๆ",
    }.get(segment, "2) แบ่งเป็นบรรทัดซับสั้น ~3-5 คำต่อบรรทัด ขึ้นบรรทัดใหม่ที่ 'ระหว่างคำ' เท่านั้น ตามจังหวะพูด")
    return (
        "แนบไฟล์เสียงพูดภาษาไทยจากคลิปสั้นมาด้วย — ช่วยถอดเป็น 'ซับไตเติล' ให้ตรงตามที่พูดจริง\n"
        "กติกา:\n"
        "1) ฟังเสียง แล้วพิมพ์ข้อความภาษาไทยให้ถูกต้อง อ่านลื่น เป็นธรรมชาติ คงคำพูดเดิม\n"
        "   ห้ามแต่งเพิ่ม ห้ามสรุป ห้ามข้ามช่วงที่พูด (คำที่ฟังยากให้พยายามถอดให้ดีที่สุด)\n"
        f"{rule2}\n"
        "3) แต่ละบรรทัดใส่เวลาเริ่ม (start) และจบ (end) เป็น 'วินาที' นับจากต้นไฟล์เสียง\n"
        "   (ทศนิยม 1 ตำแหน่ง) ให้ตรงกับที่ได้ยินจริงมากที่สุด เรียงตามเวลา ไม่ทับซ้อนกัน\n"
        "4) สำคัญมาก: ห้ามตัดกลางคำเด็ดขาด — คำ 1 คำต้องอยู่บรรทัดเดียวกันเสมอ\n"
        "   (เช่น 'ญี่ปุ่น' ห้ามแยกเป็น 'ญี่' กับ 'ปุ่น'); ถ้าคำถัดไปจะทำให้ยาวเกิน ให้ยกทั้งคำไปบรรทัดใหม่\n\n"
        'ตอบเป็น JSON เท่านั้น (ห้ามมีข้อความอื่นนอก JSON) รูปแบบ:\n'
        '{"lines":[{"text":"ข้อความในบรรทัด","start":0.0,"end":0.0}]}'
    )


def _audio_for_llm(src: str, *, log=None) -> tuple[bytes, str] | None:
    """Encode *src* to a small mono 16 kHz MP3 so Gemini can LISTEN to the real
    speech (Whisper 'small' mishears a lot of Thai — hearing the audio, not just
    cleaning Whisper's text, is what fixes the words).  Returns (bytes, mime) or
    None if it can't be prepared / would be too big for an inline request."""
    if not src or not os.path.isfile(src):
        return None
    dst = os.path.join(tempfile.gettempdir(),
                       f"_subllm_{os.getpid()}_{int(time.time() * 1000) % 100000}.mp3")
    data = None
    try:
        tools.ffmpeg(["-y", "-i", src, "-vn", "-ac", "1", "-ar", "16000",
                      "-c:a", "libmp3lame", "-b:a", "32k", dst],
                     check=True, timeout=180)
        with open(dst, "rb") as f:
            data = f.read()
    except Exception as e:  # noqa: BLE001 — no audio for the LLM just means text-only fallback
        if log:
            log(f"⚠️ เตรียมเสียงให้ AI ฟังไม่สำเร็จ ({e}) — จะใช้เฉพาะข้อความ")
    finally:
        try:
            os.remove(dst)
        except OSError:
            pass
    if not data or len(data) > 18_000_000:      # keep well under Gemini's ~20MB inline cap
        return None
    return data, "audio/mp3"


def _ai_transcribe_audio(audio_src: str, *, segment: str = "natural", log=None) -> list[Line] | None:
    """Primary subtitle path when a Gemini key is present: Gemini LISTENS to the
    clip's audio and returns accurate Thai lines WITH timestamps.  This beats
    Whisper 'small' on Thai — correct words (Whisper mishears a lot) and it also
    catches quiet speech Whisper's VAD drops — and it needs no local ASR at all.
    Returns None on any problem so the caller falls back to the offline segmenter."""
    if not (llm and llm.api_key()):
        return None
    audio = _audio_for_llm(audio_src, log=log)
    if not audio:
        return None
    try:
        raw = llm._gemini_call(
            [{"inline_data": {"mime_type": audio[1],
                              "data": base64.b64encode(audio[0]).decode("ascii")}},
             {"text": _ai_transcribe_prompt(segment)}],
            llm.api_key(), llm.model(), 120.0, None,
            thinking_budget=0)                       # transcription → skip thinking = faster
        data = json.loads(re.sub(r"^```[a-zA-Z]*|```$", "", raw.strip()).strip())
        rows = data.get("lines") if isinstance(data, dict) else None
    except Exception as e:  # noqa: BLE001
        if log:
            log(f"⚠️ AI ถอดเสียงเป็นซับไม่สำเร็จ ({e}) — ใช้ตัวถอดเสียงสำรอง")
        return None
    if not isinstance(rows, list) or not rows:
        return None

    # Sanitise the model's times: valid, ordered, non-overlapping.
    parsed: list[tuple[float, float, str]] = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        text = str(r.get("text", "")).strip()
        try:
            s = float(r.get("start")); e = float(r.get("end"))
        except (TypeError, ValueError):
            continue
        if not text or s < 0 or e <= s:
            continue
        parsed.append((s, e, text))
    if not parsed:
        return None
    parsed.sort(key=lambda x: x[0])
    lines: list[Line] = []
    for k, (s, e, text) in enumerate(parsed):
        if k + 1 < len(parsed):                      # don't overlap the next line
            e = min(e, max(s + 0.3, parsed[k + 1][0]))
        toks = text.split() or [text]                # spaces = word boundaries; joined "" on display
        span = max(0.01, e - s)
        lw = [Word(s + span * j / len(toks), s + span * (j + 1) / len(toks), tk)
              for j, tk in enumerate(toks)]
        lines.append(Line(s, e, lw))
    return lines or None


def segment_lines(tr, mode: str) -> list[Line]:
    """Offline fallback: group Whisper words by pause / count.  Orphan Thai marks
    are merged first so a break never lands mid-word/mid-cluster."""
    words = _merge_orphan_marks(_clean_foreign(
        [w for w in tr.words if w.text and w.text.strip()]))
    if not words:
        return []
    if mode == "none":                        # keep everything on one line (no split)
        return [Line(words[0].start, words[-1].end, words)]
    if mode == "words":
        return _chunk(words, _WORDS_PER_LINE)
    if mode == "sentence":
        lines = []
        for seg in tr.segments:
            sw = _merge_orphan_marks(_clean_foreign(
                [w for w in seg.words if w.text and w.text.strip()]))
            if sw:
                lines.append(Line(sw[0].start, sw[-1].end, sw))
        return lines or _chunk(words, _WORDS_PER_LINE)
    lines, cur = [], [words[0]]               # "natural"
    for prev, w in zip(words, words[1:]):
        if (w.start - prev.end) > _NATURAL_GAP or len(cur) >= _NATURAL_MAX_WORDS:
            lines.append(Line(cur[0].start, cur[-1].end, cur))
            cur = []
        cur.append(w)
    if cur:
        lines.append(Line(cur[0].start, cur[-1].end, cur))
    return lines


def _chunk(words: list, k: int) -> list[Line]:
    return [Line(c[0].start, c[-1].end, c)
            for c in (words[i:i + k] for i in range(0, len(words), k))]


# ---------------------------------------------------------------------------
# SRT sidecar
# ---------------------------------------------------------------------------
def build_srt(lines: list[Line]) -> str:
    def ts(t: float) -> str:
        t = max(0.0, t)
        h, m, s = int(t // 3600), int(t % 3600 // 60), int(t % 60)
        return f"{h:02d}:{m:02d}:{s:02d},{int(round((t - int(t)) * 1000)):03d}"
    return "\n".join(f"{i}\n{ts(ln.start)} --> {ts(ln.end)}\n{ln.text}\n"
                     for i, ln in enumerate(lines, 1))


# ---------------------------------------------------------------------------
# ASS authoring
# ---------------------------------------------------------------------------
def _ass_color(hexrgb: str, alpha: int = 0) -> str:
    h = hexrgb.lstrip("#")
    return f"&H{alpha:02X}{h[4:6]}{h[2:4]}{h[0:2]}".upper()


def _ass_time(t: float) -> str:
    t = max(0.0, t)
    h, m, s = int(t // 3600), int(t % 3600 // 60), int(t % 60)
    cs = int(round((t - int(t)) * 100))
    if cs >= 100:
        cs, s = 0, s + 1
    return f"{h:d}:{m:02d}:{s:02d}.{cs:02d}"


def _esc(s: str) -> str:
    return (s.replace("\\", "").replace("{", "(").replace("}", ")")
             .replace("\n", "\\N").strip())


ANIMS = ("pop", "fade", "slide", "none")   # text entry animations


def _entry_tags(anim: str, blur_tag: str, cx: int, cy: int) -> str:
    """ASS override tags that play the chosen entry animation for a line."""
    if anim == "none":
        return f"{{{blur_tag}}}" if blur_tag else ""
    if anim == "fade":
        return "{\\fad(160,120)" + blur_tag + "}"
    if anim == "slide":     # rise up into place + fade
        return ("{\\fad(120,100)" + blur_tag +
                f"\\move({cx},{cy + 30},{cx},{cy},0,170)}}")
    # "pop" (default): 60% → 110% overshoot → settle 100%, with a fade.
    return ("{\\fad(90,70)" + blur_tag +
            "\\fscx60\\fscy60\\t(0,130,\\fscx110\\fscy110)"
            "\\t(130,210,\\fscx100\\fscy100)}")


def _visible_len(s: str) -> int:
    """Approximate rendered character count: Thai combining marks stack on the
    previous glyph, so they take no horizontal space."""
    return sum(1 for ch in s if ch not in _THAI_MARKS and not ch.isspace())


def _split_long(w, max_chars: int) -> list:
    """A single token longer than one row (e.g. a whole line the customer typed
    in the editor) must still fit the screen: chunk it at *max_chars*, never
    breaking right before a Thai combining mark, times spread by length."""
    t = w.text or ""
    if _visible_len(t) <= max_chars:
        return [w]
    parts: list[str] = []
    cur, n = "", 0
    for ch in t:
        mark = ch in _THAI_MARKS
        if n >= max_chars and not mark and cur:
            parts.append(cur)
            cur, n = "", 0
        cur += ch
        if not mark and not ch.isspace():
            n += 1
    if cur:
        parts.append(cur)
    dur = max(0.0, w.end - w.start)
    total = max(1, len(t))
    out, pos = [], 0
    for p in parts:
        s = w.start + dur * pos / total
        pos += len(p)
        out.append(Word(s, w.start + dur * pos / total, p))
    return out


def _wrap_rows(words: list, max_chars: int) -> list[list]:
    """Split a caption line's words into rows that fit the horizontal safe area
    (WrapStyle 2 never auto-wraps, so an unwrapped long line would spill past
    the screen edge).  Breaks BETWEEN word tokens — never mid-word (except a
    single token that is itself wider than the screen)."""
    rows: list[list] = []
    cur: list = []
    n = 0
    for w0 in words:
        for w in _split_long(w0, max_chars):
            c = max(1, _visible_len(w.text or ""))
            if cur and n + c > max_chars:
                rows.append(cur)
                cur, n = [], 0
            cur.append(w)
            n += c
    if cur:
        rows.append(cur)
    return rows


def _char_break_px(s: str, fpath: str, px: int, max_w: float) -> tuple[str, str]:
    """Largest prefix of *s* whose REAL shaped width fits *max_w*, never ending
    right before a Thai combining mark (that would strand a vowel/tone on the next
    row).  Returns (head, rest); head='' if not even one cluster fits."""
    from . import textshape
    cut = 0
    for i in range(1, len(s) + 1):
        if i < len(s) and s[i] in _THAI_NO_START:     # don't strand a mark / leading vowel (ะ า ๆ ฯ)
            continue
        if textshape.measure_width(s[:i], fpath, px) <= max_w:
            cut = i
        else:
            break
    return s[:cut], s[cut:]


def _wrap_text_px(text: str, fpath: str, px: int, max_w: float) -> list[str]:
    """Break a caption STRING into rows that each fit *max_w* by REAL shaped width
    (HarfBuzz advances — the metric the browser preview uses), breaking at SPACES so
    a whole word never lands split across two rows.  A single space-less run that is
    itself wider than a row is split at a safe char boundary (never before a Thai
    mark).  This replaces the old character-count estimate, which over-counted
    zero-width Thai marks and so wrapped — and cut mid-word — lines that actually fit."""
    from . import textshape

    def wpx(x: str) -> float:
        return textshape.measure_width(x, fpath, px) if x else 0.0

    text = " ".join((text or "").split())              # normalise whitespace
    if not text:
        return []
    rows: list[str] = []
    cur = ""
    for seg in text.split(" "):
        while wpx(seg) > max_w:                         # a lone word wider than a row
            if cur:
                rows.append(cur)
                cur = ""
            head, rest = _char_break_px(seg, fpath, px, max_w)
            if not head:                                # even one cluster won't fit
                break
            rows.append(head)
            seg = rest
        cand = seg if not cur else cur + " " + seg
        if cur and wpx(cand) > max_w:
            rows.append(cur)
            cur = seg
        else:
            cur = cand
    if cur:
        rows.append(cur)
    return rows


def _build_ass(lines: list[Line], style: str, position: str, w: int, h: int,
               font: str = DEFAULT_FONT, anim: str = "pop",
               size: float = 1.0, fill: str | None = None,
               outline_color: str | None = None, offset: float = 0.0) -> str:
    """*fill* / *outline_color* are optional #RRGGBB overrides from the editor;
    *offset* shifts the text vertically by that fraction of the video height
    (positive = toward the centre) for bottom/top placements."""
    cfg = STYLE_PRESETS.get(style, STYLE_PRESETS[DEFAULT_STYLE])
    fontname = _FONTS.get(font, _FONTS[DEFAULT_FONT])
    align, mv_frac = POSITIONS.get(position, POSITIONS["bottom"])
    size = min(1.6, max(0.6, float(size or 1.0)))
    fs = max(20, round(h * 0.060 * size))
    offset = min(0.35, max(-0.06, float(offset or 0.0)))
    margin_v = max(0, round(h * (mv_frac + (offset if align != 5 else 0.0))))
    bold = -1 if cfg.get("bold") else 0
    border = cfg.get("border", 1)
    outw = max(1, round(fs * cfg.get("outw_r", 0.040)))   # Thai-safe: scales w/ size
    shadow = cfg.get("shadow", 1)
    spacing = cfg.get("spacing", 0)
    primary = _ass_color(fill or cfg["fill"])
    secondary = _ass_color(cfg.get("sec", fill or cfg["fill"]))
    outline = _ass_color(outline_color or cfg.get("out", "#000000"))
    back = _ass_color(cfg.get("back", "#000000"), cfg.get("back_a", 0))
    blur = cfg.get("blur", 0)
    karaoke = cfg.get("karaoke", False)

    # Horizontal safe area: proportional margins + a per-row character budget so
    # captions can never overflow the frame (the old fixed 40px margin let long
    # Thai lines run past the edge).
    mx = max(24, round(w * 0.05))
    max_chars = max(6, int((w - 2 * mx) / (fs * 0.56)))

    head = (
        "[Script Info]\n"
        "ScriptType: v4.00+\nWrapStyle: 2\nScaledBorderAndShadow: yes\n"
        f"PlayResX: {w}\nPlayResY: {h}\n\n"
        "[V4+ Styles]\n"
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, "
        "OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, "
        "ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, "
        "MarginL, MarginR, MarginV, Encoding\n"
        f"Style: Def,{fontname},{fs},{primary},{secondary},{outline},{back},{bold},"
        f"0,0,0,100,100,{spacing},0,{border},{outw},{shadow},{align},{mx},{mx},{margin_v},1\n\n"
        "[Events]\n"
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, "
        "Effect, Text\n"
    )

    intro_blur = f"\\blur{blur}" if blur else ""
    # Anchor point of the alignment (for \move in the slide animation).
    cx = w // 2
    cy = {2: h - margin_v, 5: h // 2, 8: margin_v}.get(align, h - margin_v)
    events = []
    for ln in lines:
        start = _ass_time(max(0.0, ln.start - 0.06))
        end = _ass_time(ln.end + 0.20)
        base = _entry_tags(anim if anim in ANIMS else "pop", intro_blur, cx, cy)
        rows = _wrap_rows(ln.words, max_chars) or [ln.words]
        if karaoke:
            body = base + "\\N".join(
                "".join(f"{{\\kf{max(1, round((w2.end - w2.start) * 100))}}}{_esc(w2.text)}"
                        for w2 in row)
                for row in rows)
        else:
            body = base + _esc("\n".join(
                "".join(w2.text for w2 in row).strip() for row in rows))
        events.append(f"Dialogue: 0,{start},{end},Def,,0,0,0,,{body}")
    return head + "\n".join(events) + "\n"


# ---------------------------------------------------------------------------
# Render (ffmpeg / libass)
# ---------------------------------------------------------------------------
def _probe_wh_dur(video_path: str) -> tuple[int, int, float]:
    try:
        from . import media
        info = media.probe(video_path)
        return int(info.width or 1080), int(info.height or 1920), float(info.duration or 0.0)
    except Exception:  # noqa: BLE001
        return 1080, 1920, 0.0


def _q(p: str) -> str:
    """Quote+escape a path for an ffmpeg filter option (Windows drive colon +
    backslashes), wrapped in single quotes so spaces survive."""
    esc = os.path.abspath(p).replace("\\", "/").replace(":", "\\:")
    return f"'{esc}'"


def _fonts_dir() -> str | None:
    """The bundled Thai caption fonts dir — source (packaging/payload/fonts) or the
    frozen bundle — so libass loads them even when they're not installed."""
    here = os.path.dirname(os.path.abspath(__file__))
    cands = [os.path.join(os.path.dirname(here), "packaging", "payload", "fonts")]
    try:
        cands.append(os.path.join(tools.bundle_dir(), "fonts"))
    except Exception:  # noqa: BLE001
        pass
    mei = getattr(sys, "_MEIPASS", None)
    if mei:
        cands.append(os.path.join(mei, "fonts"))
    for d in cands:
        if os.path.isdir(d):
            return d
    return None


def _with_suffix(path: str, suffix: str) -> str:
    base, ext = os.path.splitext(path)
    return f"{base}{suffix}{ext}"


# ---------------------------------------------------------------------------
# Line (de)serialisation — used by the in-app editor's project files
# ---------------------------------------------------------------------------
def lines_to_json(lines: list[Line]) -> list[dict]:
    return [{"start": ln.start, "end": ln.end,
             "words": [{"s": w.start, "e": w.end, "t": w.text} for w in ln.words]}
            for ln in lines]


def lines_from_json(data) -> list[Line]:
    out: list[Line] = []
    for d in (data or []):
        ws = [Word(float(w["s"]), float(w["e"]), str(w["t"])) for w in d.get("words", [])]
        if ws:
            st = d.get("style") if isinstance(d.get("style"), dict) else None
            out.append(Line(float(d.get("start", ws[0].start)),
                            float(d.get("end", ws[-1].end)), ws, style=st))
    return out


# Offline ASR fallback model.  "small" (multilingual faster-whisper) — ~8x faster
# than the old Thonburian large-v2 on CPU and a ~2.5GB smaller bundle.  It mishears
# a lot of Thai, so it's ONLY the offline fallback: when a Gemini key is present,
# subtitles come from _ai_transcribe_audio (Gemini listens to the audio) instead.
SUB_MODELS = ("small",)


def _reline(ln: Line, start: float, end: float) -> Line:
    """Same words/text as *ln*, re-timed into [start, end] (words spread by length)."""
    words = ln.words or []
    total = sum(max(1, len(w.text)) for w in words) or 1
    acc, new = 0.0, []
    for w in words:
        wl = max(1, len(w.text))
        ws = start + (acc / total) * (end - start)
        acc += wl
        we = start + (acc / total) * (end - start)
        new.append(Word(round(ws, 2), round(we, 2), w.text))
    return Line(start, end, new or words, getattr(ln, "style", None))


def _retime_with_whisper(video_path: str, lines: list[Line],
                         model_size: str | None = None, *, log=None) -> list[Line]:
    """HYBRID timing: keep the AI's (Gemini) accurate Thai TEXT + line breaks, but
    replace its loose timestamps with Whisper's accurate word-level timing.

    Gemini writes good Thai but times it badly; Whisper times tokens well but splits
    Thai into sub-word pieces.  So we transcribe with Whisper, lay its tokens out as
    a timed CHARACTER stream, align the Gemini text onto it (difflib — tolerant of
    the ASR's Thai mistakes), and stamp each Gemini line with the start/end of the
    Whisper characters it aligns to.  Fail-safe: any weakness returns the lines
    unchanged so we never make timing worse than the current behaviour."""
    if not lines or not transcribe.available():
        return lines
    mdl = model_size or os.environ.get("AUTOCUT_WHISPER_MODEL") or "th-large-v2"
    try:
        tr = transcribe.transcribe(video_path, model_size=mdl, log=log)
    except Exception as e:  # noqa: BLE001 — never let re-timing sink subtitles
        if log:
            log(f"⚠️ ปรับเวลาซับด้วย Whisper ไม่สำเร็จ ({e}) — ใช้เวลาจาก AI")
        return lines

    # Whisper tokens → flat timed-character stream (spread each token over its chars).
    timed: list[tuple[str, float, float]] = []
    for w in tr.words:
        chars = [c for c in (w.text or "") if not c.isspace()]
        n = len(chars) or 1
        span = max(0.0, float(w.end) - float(w.start)) / n
        for i, c in enumerate(chars):
            timed.append((c, float(w.start) + i * span, float(w.start) + (i + 1) * span))
    if len(timed) < 3:
        return lines
    whisper_str = "".join(c for c, _, _ in timed)

    # Gemini text as one string + each line's [start,end) char range in it.
    line_txts = ["".join(ch for ch in ln.text if not ch.isspace()) for ln in lines]
    gem_str = "".join(line_txts)
    if not gem_str:
        return lines
    ranges, pos = [], 0
    for t in line_txts:
        ranges.append((pos, pos + len(t)))
        pos += len(t)

    # Map gem index → whisper index via longest matching blocks (handles ASR errors).
    import difflib
    g2w: list = [None] * (len(gem_str) + 1)
    for a, b, size in difflib.SequenceMatcher(None, gem_str, whisper_str,
                                              autojunk=False).get_matching_blocks():
        for k in range(size):
            g2w[a + k] = b + k

    def _near(gi: int, step: int):
        j = gi
        while 0 <= j < len(g2w):
            if g2w[j] is not None:
                return g2w[j]
            j += step
        return None

    hits, out = 0, []
    for ln, (gs, ge) in zip(lines, ranges):
        ws = _near(gs, +1) if ge > gs else None
        we = _near(ge - 1, -1) if ge > gs else None
        if ws is None or we is None:
            out.append(ln)                 # can't align this line → keep AI timing
            continue
        st = timed[max(0, min(ws, len(timed) - 1))][1]
        en = timed[max(0, min(we, len(timed) - 1))][2]
        if en <= st:
            out.append(ln)
            continue
        out.append(_reline(ln, round(st, 2), round(en, 2)))
        hits += 1

    if hits < max(1, len(lines) // 2):     # aligned too few lines → don't trust it
        if log:
            log("⚠️ จับเวลาซับกับเสียงไม่พอ — คงเวลาเดิมจาก AI")
        return lines
    out.sort(key=lambda l: l.start)        # a stray match can reorder → fix monotonicity
    for i in range(1, len(out)):
        if out[i].start < out[i - 1].end:
            out[i].start = max(out[i].start, out[i - 1].end)
        if out[i].end <= out[i].start:
            out[i].end = out[i].start + 0.3
    if log:
        log(f"⏱️ ปรับเวลาซับให้ตรงเสียงด้วย Whisper ({hits}/{len(lines)} บรรทัด)")
    return out


def generate(video_path: str, *, segment: str = "natural",
             model_size: str | None = None, use_gemini_text: bool = True,
             retime: bool | None = None, log=None) -> list[Line] | None:
    """Transcribe + group into caption lines.  None when unavailable/no speech."""
    def _log(m):
        if log:
            log(m)
    # PRIMARY: Gemini listens to the audio and returns accurate Thai lines with
    # timestamps.  Much better Thai than Whisper 'small', and it needs no local ASR
    # (works even where faster-whisper isn't installed).  Falls through to Whisper
    # when there's no key / no internet / any error.
    if use_gemini_text and llm and llm.api_key():
        try:
            _log("🧠 AI กำลังฟังเสียงเพื่อทำซับไตเติล…")
            lines = _ai_transcribe_audio(video_path, segment=segment, log=_log)
            if lines:
                # Optionally snap Gemini's (sometimes drifty) timestamps to Whisper's
                # accurate word boundaries.  This runs a FULL local Whisper pass, which
                # is very slow on long clips (minutes) — so it's OFF by default; a
                # customer asked for the old, fast behaviour back.  The cheap
                # _spread_lines_if_broken rescue (app.py) still fixes the worst garbage
                # Gemini timing without Whisper.  Re-enable per call (retime=True) or
                # globally with AUTOCUT_SUB_RETIME=1.
                do_retime = retime if retime is not None else (
                    os.environ.get("AUTOCUT_SUB_RETIME") == "1")
                if do_retime:
                    lines = _retime_with_whisper(video_path, lines, model_size, log=_log)
                _log(f"🧠 AI ถอดเสียงเป็นซับ {len(lines)} บรรทัด")
                return lines
        except Exception as e:  # noqa: BLE001 — never let the AI path sink subtitles
            _log(f"⚠️ AI ถอดเสียงเป็นซับไม่สำเร็จ ({e}) — ใช้ตัวถอดเสียงสำรอง")

    # FALLBACK: offline Whisper transcription + heuristic grouping.
    if not transcribe.available():
        _log("⚠️ ข้ามซับไตเติล: ไม่พบเครื่องมือถอดเสียง")
        return None
    try:
        _log("💬 ถอดเสียงเพื่อทำซับไตเติล…")
        tr = None
        last_err = None
        for m in ([model_size] if model_size else SUB_MODELS):
            try:
                tr = transcribe.transcribe(video_path, model_size=m, log=log)
                break
            except transcribe.TranscribeUnavailable as e:
                last_err = e
                _log(f"⚠️ โมเดล {m} ใช้ไม่ได้ — ลองตัวถัดไป")
        if tr is None:
            raise last_err or RuntimeError("no ASR model")
        return segment_lines(tr, segment) or None
    except Exception as e:  # noqa: BLE001
        _log(f"⚠️ ถอดเสียงซับไม่สำเร็จ: {e}")
        return None


def _hex_rgb(hexstr: str) -> tuple[int, int, int]:
    h = (hexstr or "#FFFFFF").lstrip("#")
    if len(h) != 6:
        h = "FFFFFF"
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))


def _burn_overlay(video_path: str, lines: list[Line], *, style: str, position: str,
                  w: int, h: int, font: str, anim: str, size: float,
                  fill: str | None, outline_color: str | None, offset: float,
                  crf: int, out_path: str, log=None) -> str | None:
    """Burn captions by shaping each line with HarfBuzz + FreeType (correct Thai
    stacked marks) into PNGs and overlaying them with ffmpeg.  Returns *out_path*
    on success, or None to let the caller fall back to the ASS path."""
    from . import textshape
    if not _font_path(font):
        return None                          # default font missing → let ASS handle it

    mx = max(24, round(w * 0.05))

    # Resolve the render params for ONE line — its own ``style`` dict overrides the
    # burn call's defaults, so each timeline clip can have its own caption style.
    def _params(st):
        st = st or {}
        _style = st.get("style") or style
        _font = st.get("font") or font
        _fill = st.get("fill") if st.get("fill") not in (None, "") else fill
        _out = st.get("outline") if st.get("outline") not in (None, "") else outline_color
        _size = st.get("size") if st.get("size") is not None else size
        _pos = st.get("position") or position
        _off = st.get("offset") if st.get("offset") is not None else offset
        cfg = STYLE_PRESETS.get(_style, STYLE_PRESETS[DEFAULT_STYLE])
        fs = max(20, round(h * 0.060 * min(1.6, max(0.6, float(_size or 1.0)))))
        align, mv_frac = POSITIONS.get(_pos, POSITIONS["bottom"])
        return {
            "fpath": _font_path(_font) or _font_path(font),
            "fill_rgb": _hex_rgb(_fill or cfg["fill"]),
            "out_rgb": _hex_rgb(_out or cfg.get("out", "#000000")),
            "fs": fs,
            "outline_px": max(1, round(fs * cfg.get("outw_r", 0.040))),
            "shadow": int(cfg.get("shadow", 1)),
            "align": align, "mv_frac": mv_frac,
            "offset": min(0.35, max(-0.06, float(_off or 0.0))),
            "max_chars": max(6, int((w - 2 * mx) / (fs * 0.56))),
            "anim": st.get("anim") or anim,
        }

    with tempfile.TemporaryDirectory(prefix="autocut_ov_",
                                     ignore_cleanup_errors=True) as td:
        inputs: list[str] = []
        fparts: list[str] = []
        cur = "0:v"
        k = 0
        for ln in lines:
            pr = _params(getattr(ln, "style", None))
            fpath = pr["fpath"]
            base_fs = pr["fs"]
            floor = max(20, round(base_fs * 0.6))
            max_w = w - 2 * mx
            text = "".join(w2.text for w2 in ln.words).strip()
            # Wrap by REAL shaped width so the burn matches the on-screen preview:
            # (1) fits → ONE row.  (2) only slightly too long → shrink the font a
            # little (down to ~80%) to keep it on ONE row.  (3) genuinely long → wrap
            # at word gaps (spaces) — never mid-word — shrinking (to ~60%) only to
            # keep it within 2 rows so it can't spill off the frame ("ซับตกบรรทัด").
            fs = base_fs
            rows = _wrap_text_px(text, fpath, fs, max_w)
            if len(rows) > 1:
                one_floor = max(floor, round(base_fs * 0.80))
                f = base_fs
                while f > one_floor:
                    f = max(one_floor, int(f * 0.94))
                    r1 = _wrap_text_px(text, fpath, f, max_w)
                    if len(r1) == 1:
                        fs, rows = f, r1
                        break
                if len(rows) > 1:                        # can't fit one row → wrap it
                    fs = base_fs
                    rows = _wrap_text_px(text, fpath, fs, max_w)
                    while len(rows) > 2 and fs > floor:
                        fs = max(floor, int(fs * 0.88))
                        rows = _wrap_text_px(text, fpath, fs, max_w)
            rows = [r for r in rows if r]
            if not rows:
                continue
            outw = max(1, round(pr["outline_px"] * fs / max(1, pr["fs"])))   # scale outline to shrunk fs
            rgba = textshape.render_block(rows, pr["fpath"], fs, fill=pr["fill_rgb"],
                                          outline=pr["out_rgb"], outline_px=outw,
                                          shadow=pr["shadow"])
            if rgba is None:
                continue
            ih, iw = rgba.shape[:2]
            pam = os.path.join(td, f"l{k}.pam")
            textshape.write_pam(rgba, pam)
            x = max(0, (w - iw) // 2)
            align, mv_frac = pr["align"], pr["mv_frac"]
            mv = round(h * (mv_frac + (pr["offset"] if align != 5 else 0.0)))
            if align == 8:        # top
                y = mv
            elif align == 5:      # centre
                y = (h - ih) // 2
            else:                 # bottom
                y = h - ih - mv
            y = max(0, min(h - ih, y))
            s = max(0.0, ln.start - 0.05)
            e = ln.end + 0.20
            dur = max(0.4, e - s + 0.1)
            k += 1
            inputs += ["-loop", "1", "-t", f"{dur:.3f}", "-i", pam]
            fout = max(s, e - 0.12)
            if pr["anim"] == "none":
                fparts.append(f"[{k}:v]setpts=PTS-STARTPTS+{s:.3f}/TB[l{k}]")
            else:
                fparts.append(
                    f"[{k}:v]setpts=PTS-STARTPTS+{s:.3f}/TB,"
                    f"fade=in:st={s:.3f}:d=0.15:alpha=1,"
                    f"fade=out:st={fout:.3f}:d=0.12:alpha=1[l{k}]")
            nxt = f"o{k}"
            fparts.append(
                f"[{cur}][l{k}]overlay={x}:{y}:enable='between(t,{s:.3f},{e:.3f})'"
                f":eof_action=pass[{nxt}]")
            cur = nxt

        if k == 0:
            return None
        graph = ";".join(fparts)
        args = ["-y", "-i", video_path, *inputs,
                "-filter_complex", graph, "-map", f"[{cur}]", "-map", "0:a?",
                "-c:v", "libx264", "-preset", "veryfast",
                "-crf", str(min(30, max(16, int(crf or 20)))),
                "-pix_fmt", "yuv420p", "-c:a", "copy", out_path]
        try:
            tools.ffmpeg(args, check=True, timeout=3600)
        except tools.ToolError as e:
            if log:
                log(f"⚠️ วาดซับแบบใหม่ไม่สำเร็จ ({str(e)[-160:]}) — ใช้วิธีเดิม")
            return None
    return out_path if os.path.exists(out_path) else None


def burn(video_path: str, *, style: str = DEFAULT_STYLE, position: str = "bottom",
         segment: str = "natural", export_srt: bool = False, font: str = DEFAULT_FONT,
         anim: str = "pop", size: float = 1.0, fill: str | None = None,
         outline_color: str | None = None, offset: float = 0.0, crf: int = 20,
         model_size: str | None = None, use_gemini_text: bool = True,
         out_path: str | None = None, lines: list[Line] | None = None,
         log=None) -> str:
    """Return a captioned copy of *video_path*, or *video_path* unchanged on any
    failure (fail-safe).  Pass *lines* (e.g. edited in the app) to skip
    transcription and burn exactly those.  Writes ``<video>.srt`` when asked."""
    def _log(m):
        if log:
            log(m)

    try:
        if not tools.status().core_ok:
            _log("⚠️ ข้ามซับไตเติล: ไม่พบ ffmpeg")
            return video_path
    except Exception:  # noqa: BLE001
        pass

    try:
        if lines is None:
            lines = generate(video_path, segment=segment, model_size=model_size,
                             use_gemini_text=use_gemini_text, log=log)
        if not lines:
            _log("⚠️ ไม่พบคำพูดสำหรับทำซับ — ข้าม")
            return video_path

        w, h, dur = _probe_wh_dur(video_path)
        out_path = out_path or _with_suffix(video_path, "_sub")

        # Preferred path: shape Thai correctly with HarfBuzz + FreeType and overlay
        # rendered PNGs — libass drops Thai stacked vowel+tone marks ("สระ/วรรณยุกต์
        # ซ้อน").  Falls back to the libass/ASS path when the shaper deps are absent.
        used_overlay = False
        try:
            from . import textshape
            if textshape.available():
                _log("🎬 กำลังใส่ซับไตเติล (วาดอักษรไทยแบบคมชัด)…")
                res = _burn_overlay(video_path, lines, style=style, position=position,
                                    w=w, h=h, font=font, anim=anim, size=size,
                                    fill=fill, outline_color=outline_color,
                                    offset=offset, crf=crf, out_path=out_path, log=log)
                used_overlay = bool(res)
        except Exception as e:  # noqa: BLE001
            _log(f"⚠️ วาดซับแบบใหม่มีปัญหา ({e}) — ใช้วิธีเดิม")

        if not used_overlay:
            ass = _build_ass(lines, style, position, w, h, font, anim, size,
                             fill=fill, outline_color=outline_color, offset=offset)
            with tempfile.TemporaryDirectory(prefix="autocut_sub_",
                                             ignore_cleanup_errors=True) as td:
                ass_path = os.path.join(td, "cap.ass")
                with open(ass_path, "w", encoding="utf-8") as f:
                    f.write(ass)
                _log("🎬 กำลังใส่ซับไตเติล (ffmpeg)…")
                vf = "subtitles=filename=" + _q(ass_path)
                fdir = _fonts_dir()
                if fdir:
                    vf += ":fontsdir=" + _q(fdir)
                try:
                    tools.ffmpeg(["-y", "-i", video_path, "-vf", vf,
                                  "-c:v", "libx264", "-preset", "veryfast",
                                  "-crf", str(min(30, max(16, int(crf or 20)))),
                                  "-c:a", "copy", out_path],
                                 check=True, timeout=3600)
                except tools.ToolError as e:
                    _log(f"⚠️ ใส่ซับไม่สำเร็จ — ส่งวิดีโอแบบไม่มีซับแทน ({str(e)[-200:]})")
                    return video_path

        if not os.path.exists(out_path):
            return video_path

        if export_srt:
            try:
                srt_path = os.path.splitext(out_path)[0] + ".srt"
                with open(srt_path, "w", encoding="utf-8") as f:
                    f.write(build_srt(lines))
                _log(f"📄 บันทึกไฟล์ซับ: {os.path.basename(srt_path)}")
            except Exception as e:  # noqa: BLE001
                _log(f"⚠️ เขียนไฟล์ .srt ไม่สำเร็จ: {e}")

        _log("✅ ใส่ซับไตเติลเรียบร้อย")
        return out_path
    except Exception as e:  # noqa: BLE001 — never let captions sink the job
        _log(f"⚠️ ข้ามซับไตเติล (มีข้อผิดพลาด): {e}")
        return video_path
