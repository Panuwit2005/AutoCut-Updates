"""AI-SmartSale — Flask backend.

The heavy work runs in a background thread per job so the HTTP request returns
immediately and the browser polls ``/status/<job_id>`` for *real* progress
(no more fake countdowns).  The pipeline is:

    upload → normalize (any codec) → transcribe → pick best moments
           → cut → optional HyperFrames captions → package (zip / merged)

Every stage is defensive: a failure in transcription falls back to silence-based
cutting, and a failure in caption rendering still delivers the cut video.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import uuid
from datetime import datetime, timezone

# Windows consoles default to a legacy code page (e.g. cp874) that cannot encode
# the emoji / Thai we log.  Force UTF-8 so logging never raises UnicodeEncodeError.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

from flask import Flask, Response, jsonify, request, send_file, send_from_directory

from autocut import (analyze, captions, editor, licensing, llm, media, storage,
                     tools, transcribe, updater, voiceover)

# Route all temp/work files to the roomiest writable drive (avoids
# "No space left on device" on machines with a full system drive) and sweep up
# any leftovers from previous runs.  Safe/idempotent if the launcher already ran it.
storage.setup()
storage.purge_stale()

app = Flask(__name__)
# NO cross-origin access on purpose: the UI (index.html / editor.html) is served
# from this same Flask app (API = ''), so requests are same-origin and need no CORS
# headers.  Leaving CORS wide open would let any website the user visits read/trigger
# the local server (projects, machine id, render, delete…) — so we don't enable it.
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024 * 1024  # 8 GB

# Where index.html / static live.  An applied OTA patch (AUTOCUT_CODE_DIR, set by
# the launcher) wins; then the frozen bundle (sys._MEIPASS); then source.
HERE = (os.environ.get("AUTOCUT_CODE_DIR")
        or getattr(sys, "_MEIPASS", None)
        or os.path.dirname(os.path.abspath(__file__)))
# Behind-the-scenes AI (word timing for smarter cuts — never shown to the user).
WHISPER_MODEL = os.environ.get("AUTOCUT_WHISPER_MODEL", "th-large-v2")
LANGUAGE = os.environ.get("AUTOCUT_LANGUAGE", "th")

# In-memory job registry.
JOBS: dict[str, "Job"] = {}
JOBS_LOCK = threading.Lock()


# ===========================================================================
#  Project metadata (project.json) — atomic, concurrency-safe writes
# ===========================================================================
# The editor fires many saves in quick succession (drag-reorder, split, audio
# edits, autosave) and Flask serves them on separate threads (threaded=True).
# A plain ``open("w") + json.dump`` lets two writers interleave and leave a
# corrupt file — valid JSON followed by a leftover tail from the longer
# version, i.e. ``json.load`` raises "Extra data". Writing to a temp file and
# ``os.replace``-ing it in is atomic, so a reader always sees one complete
# version; a per-path lock serialises writers so no update is silently lost.
_META_LOCKS: dict[str, threading.Lock] = {}
_META_LOCKS_GUARD = threading.Lock()


def _meta_lock(meta_path: str) -> threading.Lock:
    key = os.path.normcase(os.path.abspath(meta_path))
    with _META_LOCKS_GUARD:
        lock = _META_LOCKS.get(key)
        if lock is None:
            lock = _META_LOCKS[key] = threading.Lock()
        return lock


def _atomic_write_bytes(path: str, data: bytes) -> None:
    """Atomically write *data* to *path* (temp file + os.replace, per-path lock)
    so concurrent saves / reads can never see a torn file."""
    d = os.path.dirname(path)
    os.makedirs(d, exist_ok=True)
    with _meta_lock(path):
        fd, tmp = tempfile.mkstemp(prefix=".project-", suffix=".tmp", dir=d)
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
            # os.replace is atomic, but on Windows it fails with a sharing
            # violation if a reader (get_project, the video route, …) has the
            # destination open at that instant — so retry briefly.
            for attempt in range(40):
                try:
                    os.replace(tmp, path)
                    break
                except PermissionError:
                    if attempt == 39:
                        raise
                    time.sleep(0.02)
        except BaseException:
            try:
                os.remove(tmp)
            except OSError:
                pass
            raise


def _write_meta_raw(meta_path: str, meta: dict) -> None:
    """Atomic project.json write WITHOUT recording undo history — for internal
    rewrites (corrupt-file auto-heal, undo/redo restores)."""
    _atomic_write_bytes(meta_path, json.dumps(meta, ensure_ascii=False).encode("utf-8"))


def _write_meta(meta_path: str, meta: dict) -> None:
    """Atomic project.json write that records the PRIOR state for undo. Every
    edit route writes through here, so undo/redo covers all edit kinds at once."""
    try:
        with open(meta_path, "rb") as f:
            old = f.read()
    except OSError:
        old = None                              # brand-new project → nothing to undo
    _write_meta_raw(meta_path, meta)
    if old is not None:
        with _HIST_LOCK:
            h = _HIST.setdefault(_pid_key(meta_path), {"undo": [], "redo": []})
            h["undo"].append(old)
            del h["undo"][:-HIST_MAX]           # cap the stack
            h["redo"].clear()                   # a fresh edit invalidates redo


def _read_meta(meta_path: str) -> dict:
    """Load project.json, transparently repairing a corrupt "Extra data" tail
    left by an old pre-atomic write. Recovered files are rewritten cleanly."""
    text = None
    for attempt in range(40):
        try:
            with open(meta_path, encoding="utf-8") as f:
                text = f.read()
            break
        except PermissionError:
            # a concurrent _atomic_write_bytes os.replace is swapping the file in;
            # on Windows the reader's open() briefly sees a sharing violation.
            if attempt == 39:
                raise
            time.sleep(0.02)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        # Salvage the valid JSON prefix (the leading object is intact; only a
        # duplicated tail from an interleaved write trails it).
        obj, _end = json.JSONDecoder().raw_decode(text)
        if not isinstance(obj, dict) or "clips" not in obj:
            raise
        _write_meta_raw(meta_path, obj)         # heal it (not an undoable edit)
        return obj


# ---------------------------------------------------------------------------
# Undo / redo — in-memory per-project history of project.json snapshots.
# Snapshots are captured in _write_meta above, so this covers every edit route
# without wiring each one. Stacks live for the app session (a restart clears
# them, which is fine for undo).
# ---------------------------------------------------------------------------
HIST_MAX = 60
_HIST: dict[str, dict] = {}                     # folder name -> {"undo":[bytes], "redo":[bytes]}
_HIST_LOCK = threading.Lock()


def _pid_key(meta_path: str) -> str:
    """The project's folder name (…/<folder>/.project/project.json)."""
    return os.path.basename(os.path.dirname(os.path.dirname(meta_path)))


def _hist_state(key: str) -> dict:
    with _HIST_LOCK:
        h = _HIST.get(key) or {"undo": [], "redo": []}
        return {"can_undo": bool(h["undo"]), "can_redo": bool(h["redo"])}


def _hist_step(meta_path: str, redo: bool) -> dict | None:
    """Move one step through history; returns the restored meta, or None when the
    relevant stack is empty."""
    key = _pid_key(meta_path)
    with _HIST_LOCK:
        h = _HIST.setdefault(key, {"undo": [], "redo": []})
        src, dst = (h["redo"], h["undo"]) if redo else (h["undo"], h["redo"])
        if not src:
            return None
        try:
            cur = open(meta_path, "rb").read()  # current state → onto the other stack
        except OSError:
            cur = None
        data = src.pop()
        if cur is not None:
            dst.append(cur)
            del dst[:-HIST_MAX]
    _atomic_write_bytes(meta_path, data)        # restore (no new history entry)
    try:
        return json.loads(data.decode("utf-8"))
    except ValueError:
        return {}


# ===========================================================================
#  Job model
# ===========================================================================
class Job:
    def __init__(self, job_id: str, work_dir: str):
        self.id = job_id
        self.work_dir = work_dir
        self.status = "queued"          # queued | running | done | error
        self.stage = "เริ่มต้น"
        self.pct = 0
        self.message = ""
        self.logs: list[str] = []
        self.error: str | None = None
        self.output_dir: str | None = None     # folder where deliverables were saved
        self.result_name: str | None = None     # that folder's display name
        self.pid: str | None = None             # editor project id (upload-to-edit flow)
        self.created = datetime.now(timezone.utc)
        self.started_at: float | None = None   # monotonic when work began (count-up timer)
        self._lock = threading.Lock()

    def log(self, msg: str):
        line = str(msg).rstrip()
        print(f"[{self.id[:8]}] {line}", flush=True)
        with self._lock:
            self.logs.append(line)
            self.logs = self.logs[-200:]

    def set(self, *, stage: str | None = None, pct: int | None = None,
            message: str | None = None):
        with self._lock:
            if stage is not None:
                self.stage = stage
            if pct is not None:
                self.pct = max(self.pct, min(100, pct))
            if message is not None:
                self.message = message
        if message:
            self.log(message)

    def _elapsed_seconds(self) -> int:
        """Wall-clock seconds since work began (drives the count-up timer)."""
        if not self.started_at:
            return 0
        import time as _t
        return max(0, int(_t.monotonic() - self.started_at))

    def snapshot(self) -> dict:
        elapsed = self._elapsed_seconds()
        with self._lock:
            return {
                "id": self.id,
                "status": self.status,
                "stage": self.stage,
                "pct": self.pct,
                "message": self.message,
                "elapsed_seconds": elapsed,
                "output_dir": self.output_dir,
                "output_name": self.result_name,
                "pid": self.pid,
                "error": self.error,
                "ready": self.status == "done",
            }


# ===========================================================================
#  Static serving
# ===========================================================================
@app.route("/")
def index():
    return send_from_directory(HERE, "index.html")


@app.route("/editor")
def editor_page():
    """The full-screen video editor (a separate page, CapCut-style)."""
    return send_from_directory(HERE, "editor.html")


@app.route("/editor/new", methods=["POST"])
def editor_new():
    """Import a raw uploaded video straight into the editor (editing-first flow).

    Builds a single full-length clip editor project — NO auto-cut — and returns a
    job id.  The browser polls /status and jumps to /editor?pid=… when the
    normalize finishes.  Gated like /process: this is now the main paid action."""
    if not licensing.is_activated():
        return jsonify({"error": "ยังไม่ได้เปิดใช้งานโปรแกรม — กรุณากรอกคีย์เปิดใช้งานก่อน",
                        "need_activation": True}), 403

    video = request.files.get("video")
    if not video or not video.filename:
        return jsonify({"error": "ไม่พบไฟล์วิดีโอ"}), 400
    if not tools.status().core_ok:
        return jsonify({"error": "ไม่พบ ffmpeg บนเครื่อง — ติดตั้ง ffmpeg ก่อนใช้งาน"}), 500

    _purge_finished_jobs()

    job_id = uuid.uuid4().hex
    work_dir = tempfile.mkdtemp(prefix=f"editimp_{job_id[:8]}_")

    # ~2× the upload is needed: the file is saved once, then transcoded to mp4.
    needed = (request.content_length or 0) * 2
    free = storage.free_bytes(work_dir)
    if needed and free and free < needed:
        shutil.rmtree(work_dir, ignore_errors=True)
        gb = needed / (1024 ** 3)
        drive = os.path.splitdrive(work_dir)[0] or "ดิสก์"
        return jsonify({"error": (
            f"พื้นที่ดิสก์ไม่พอ — ต้องการว่างประมาณ {gb:.1f} GB บนไดรฟ์ {drive} "
            f"(ว่างอยู่ {free / (1024 ** 3):.1f} GB) กรุณาลบไฟล์ออกแล้วลองใหม่"
        )}), 507

    try:
        src = os.path.join(work_dir, _safe_name(video.filename) or "video.mp4")
        video.save(src)
    except OSError as e:
        shutil.rmtree(work_dir, ignore_errors=True)
        if e.errno == 28:  # ENOSPC
            return jsonify({"error": "พื้นที่ดิสก์ไม่พอระหว่างบันทึกไฟล์ — กรุณาลบไฟล์ออกแล้วลองใหม่"}), 507
        return jsonify({"error": f"บันทึกไฟล์ไม่สำเร็จ: {e}"}), 500

    display = os.path.splitext(os.path.basename(video.filename))[0]
    job = Job(job_id, work_dir)
    with JOBS_LOCK:
        JOBS[job_id] = job
    threading.Thread(target=_run_editor_import, args=(job, src, display),
                     daemon=True).start()
    return jsonify({"job_id": job_id})


@app.route("/editor/new-local", methods=["POST"])
def editor_new_local():
    """Instant import: pick a video with the NATIVE file dialog and reference it
    where it already lives — nothing is uploaded or copied, so the editor opens
    immediately (CapCut-style "stay in original location").

    Only works when the codec is web-playable, because the editor preview is an
    HTML5 <video>.  Anything else (HEVC/VP9…) falls back to the transcoding
    import so the customer still gets a working clip.
    """
    if not licensing.is_activated():
        return jsonify({"error": "ยังไม่ได้เปิดใช้งานโปรแกรม — กรุณากรอกคีย์เปิดใช้งานก่อน",
                        "need_activation": True}), 403
    if not tools.status().core_ok:
        return jsonify({"error": "ไม่พบ ffmpeg บนเครื่อง — ติดตั้ง ffmpeg ก่อนใช้งาน"}), 500

    path, err = _run_folder_dialog(pick_file=True)
    if err:
        return jsonify({"ok": False, "error": err}), 500
    if not path:
        return jsonify({"ok": False, "cancelled": True})
    if not os.path.isfile(path):
        return jsonify({"ok": False, "error": "ไม่พบไฟล์ที่เลือก"}), 400

    display = os.path.splitext(os.path.basename(path))[0]
    # Referencing the file in place only works if the browser can actually decode
    # it (8-bit 4:2:0 H.264 + aac) — otherwise the preview would be a black screen.
    if not editor.web_playable(path):
        # Codec the browser can't play → transcode into the project in the
        # background (the original file is never touched).
        _purge_finished_jobs()
        job_id = uuid.uuid4().hex
        job = Job(job_id, tempfile.mkdtemp(prefix=f"editimp_{job_id[:8]}_"))
        with JOBS_LOCK:
            JOBS[job_id] = job
        threading.Thread(target=_run_editor_import, args=(job, path, display),
                         daemon=True).start()
        return jsonify({"ok": True, "job_id": job_id, "converting": True})

    base = _project_base(display)
    proj_dir = storage.new_project_dir(base)
    pdir = os.path.join(proj_dir, ".project")
    os.makedirs(pdir, exist_ok=True)
    meta = {
        "name": base, "fmt": "mp4",
        "clips": {"1": {
            "src": os.path.abspath(path), "lines": [],
            "style": "clean", "position": "bottom", "font": "kanit",
            "anim": "pop", "size": 1.0, "export_srt": False,
        }},
    }
    _write_meta(os.path.join(pdir, "project.json"), meta)
    try:
        storage.hide_dir(pdir)
    except Exception:  # noqa: BLE001
        pass
    return jsonify({"ok": True, "pid": os.path.basename(proj_dir)})


def _run_editor_import(job: "Job", video_path: str, display_name: str) -> None:
    """Normalize one upload into a fresh single-clip editor project (no auto-cut).

    The clip schema matches the no-subtitle project that /process already saves,
    so the existing editor opens it with zero special-casing.  ``job.pid`` carries
    the new project id back to the browser via /status."""
    job.status = "running"
    job.started_at = time.monotonic()
    try:
        job.set(stage="เตรียมวิดีโอ", pct=8, message="🎬 กำลังเตรียมวิดีโอสำหรับตัดต่อ…")
        base = _project_base(display_name)
        proj_dir = storage.new_project_dir(base)
        pdir = os.path.join(proj_dir, ".project")
        os.makedirs(pdir, exist_ok=True)

        # Get it into a browser-friendly mp4.  Fast path: if the upload is already
        # h264 + aac (most phone videos), just REPACKAGE (stream copy) — near-instant,
        # no re-encode.  Only transcode when the codec isn't web-playable (HEVC, VP9…).
        clean = os.path.join(pdir, "base01.mp4")
        # NB: checks the PIXEL FORMAT too — 10-bit/4:2:2 H.264 also reports
        # codec_name=h264 but a browser renders it black, so it must be encoded.
        if editor.web_playable(video_path):
            job.set(stage="เตรียมไฟล์", pct=45, message="⚡ เตรียมไฟล์ (ไม่ต้องแปลง — เร็ว)…")
            try:
                editor.remux(video_path, clean, log=job.log)
            except tools.ToolError:
                job.set(stage="แปลงไฟล์", pct=35, message="⚙️ กำลังแปลงไฟล์ให้พร้อมตัดต่อ…")
                editor._reencode(video_path, clean, fmt="mp4", log=job.log)
        else:
            job.set(stage="แปลงไฟล์", pct=35, message="⚙️ กำลังแปลงไฟล์ให้พร้อมตัดต่อ…")
            editor._reencode(video_path, clean, fmt="mp4", log=job.log)

        meta = {
            "name": base, "fmt": "mp4",
            "clips": {"1": {
                "base": "base01.mp4", "lines": [],
                "style": "clean", "position": "bottom", "font": "kanit",
                "anim": "pop", "size": 1.0, "export_srt": False,
            }},
        }
        _write_meta(os.path.join(pdir, "project.json"), meta)
        try:
            storage.hide_dir(pdir)
        except Exception:  # noqa: BLE001
            pass

        job.pid = os.path.basename(proj_dir)
        job.output_dir = proj_dir
        job.result_name = base
        job.status = "done"
        job.set(stage="เสร็จแล้ว", pct=100, message="✅ พร้อมตัดต่อแล้ว")
        shutil.rmtree(job.work_dir, ignore_errors=True)
    except OSError as e:
        job.status = "error"
        job.error = ("พื้นที่ดิสก์ไม่พอระหว่างประมวลผล — กรุณาลบไฟล์ออกแล้วลองใหม่"
                     if e.errno == 28 else str(e))
        job.set(stage="ผิดพลาด", message=f"❌ {job.error}")
        job.log(traceback.format_exc())
        shutil.rmtree(job.work_dir, ignore_errors=True)
    except Exception as e:  # noqa: BLE001
        job.error = str(e)
        job.status = "error"
        job.set(stage="ผิดพลาด", message=f"❌ {e}")
        job.log(traceback.format_exc())
        shutil.rmtree(job.work_dir, ignore_errors=True)


@app.route("/static/<path:filename>")
def static_files(filename):
    return send_from_directory(os.path.join(HERE, "static"), filename)


# ===========================================================================
#  Health / debug
# ===========================================================================
@app.route("/health")
def health():
    return jsonify({"status": "ok"})


@app.route("/version")
def app_version():
    """Running app version (overlay-aware) — shown in the UI header."""
    return jsonify({"version": updater.current_version()})


@app.route("/settings", methods=["GET", "POST"])
def settings():
    """Get the current storage folder, or set a customer-chosen one."""
    if request.method == "GET":
        return jsonify(storage.info())
    body = request.get_json(silent=True) or {}
    path = (body.get("data_dir") or "").strip()
    if not path:
        return jsonify({"ok": False, "error": "ไม่ได้ระบุโฟลเดอร์"}), 400
    res = storage.set_data_dir(path)
    return jsonify(res), (200 if res.get("ok") else 400)


@app.route("/settings/reset", methods=["POST"])
def settings_reset():
    return jsonify(storage.reset_data_dir())


@app.route("/pick-folder", methods=["POST"])
def pick_folder():
    """Open a native Windows folder dialog on this machine and apply the choice."""
    import subprocess

    if getattr(sys, "frozen", False):
        cmd = [sys.executable, "--pick-folder"]
    else:
        cmd = [sys.executable, "-m", "autocut.folder_picker"]
    no_window = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
    try:
        res = subprocess.run(cmd, capture_output=True, text=True,
                             encoding="utf-8", errors="replace", timeout=300,
                             cwd=os.path.dirname(os.path.abspath(__file__)),
                             creationflags=no_window)
    except (subprocess.TimeoutExpired, OSError) as e:
        return jsonify({"ok": False, "error": f"เปิดหน้าต่างเลือกโฟลเดอร์ไม่ได้: {e}"}), 500
    path = (res.stdout or "").strip().splitlines()[-1].strip() if res.stdout.strip() else ""
    if not path:
        return jsonify({"ok": False, "cancelled": True})
    out = storage.set_data_dir(path)
    return jsonify(out), (200 if out.get("ok") else 400)


# ---------------------------------------------------------------------------
# Export location for editor renders (separate from the storage root: this only
# says WHERE the finished .mp4 lands, it does not move project storage).
# ---------------------------------------------------------------------------
def _export_dir() -> str:
    try:
        return (storage.load_config().get("export_dir") or "").strip()
    except Exception:  # noqa: BLE001
        return ""


_PICKER_FLAGS = {"--pick-folder": [], "--pick-file": ["--file"],
                 "--pick-files": ["--files"]}


def _run_picker(flag: str) -> tuple[list[str], str | None]:
    """Run the native folder/file chooser in its own process (a Tk dialog needs
    the main thread, which the web-server workers don't have).

    Returns (paths, error) — one entry per chosen file ("--pick-files" allows
    several); empty when the customer cancelled.
    """
    import subprocess
    if getattr(sys, "frozen", False):
        cmd = [sys.executable, flag]
    else:
        cmd = [sys.executable, "-m", "autocut.folder_picker", *_PICKER_FLAGS[flag]]
    no_window = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
    # The child PRINTS the chosen path.  Without this the child's stdout uses the
    # legacy Windows code page and a Thai path raises UnicodeEncodeError, so we'd
    # read an empty line and think the customer cancelled.
    env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                             errors="replace", timeout=300,
                             cwd=os.path.dirname(os.path.abspath(__file__)),
                             creationflags=no_window, env=env)
    except (subprocess.TimeoutExpired, OSError) as e:
        return [], f"เปิดหน้าต่างเลือกไฟล์ไม่ได้: {e}"
    return [ln.strip() for ln in (res.stdout or "").splitlines() if ln.strip()], None


def _run_folder_dialog(pick_file: bool = False) -> tuple[str, str | None]:
    """Single-selection wrapper around :func:`_run_picker`."""
    paths, err = _run_picker("--pick-file" if pick_file else "--pick-folder")
    return (paths[-1] if paths else ""), err


@app.route("/export-folder", methods=["GET"])
def export_folder_get():
    d = _export_dir()
    return jsonify({"export_dir": d, "auto": not d})


@app.route("/export-folder/pick", methods=["POST"])
def export_folder_pick():
    """Choose where editor renders are saved (does NOT relocate project storage)."""
    path, err = _run_folder_dialog()
    if err:
        return jsonify({"ok": False, "error": err}), 500
    if not path:
        return jsonify({"ok": False, "cancelled": True})
    if not os.path.isdir(path):
        try:
            os.makedirs(path, exist_ok=True)
        except OSError as e:
            return jsonify({"ok": False, "error": f"โฟลเดอร์ใช้ไม่ได้: {e}"}), 400
    cfg = storage.load_config()
    cfg["export_dir"] = path
    storage.save_config(cfg)
    return jsonify({"ok": True, "export_dir": path})


@app.route("/export-folder/reset", methods=["POST"])
def export_folder_reset():
    """Back to automatic — renders land in the project's own Video/ folder."""
    cfg = storage.load_config()
    cfg.pop("export_dir", None)
    storage.save_config(cfg)
    return jsonify({"ok": True, "export_dir": "", "auto": True})


@app.route("/license/status")
def license_status():
    # Best-effort: sync the admin kill-switch list when online (never blocks
    # offline use — a failure leaves the saved state untouched).
    try:
        licensing.refresh_revocation()
    except Exception:  # noqa: BLE001
        pass
    return jsonify(licensing.status())


@app.route("/license/activate", methods=["POST"])
def license_activate():
    body = request.get_json(silent=True) or {}
    key = (body.get("key") or "").strip()
    if not key:
        return jsonify({"activated": False, "machine_id": licensing.machine_id(),
                        "error": "กรุณากรอกคีย์"}), 400
    res = licensing.activate(key)
    return jsonify(res), (200 if res.get("activated") else 400)


@app.route("/update/status")
def update_status():
    """Is a newer signed version available online?  ``?fresh=1`` forces a live
    network check (bypasses the ~45s cache) — used by the manual 'check now' button."""
    ttl = 0.0 if request.args.get("fresh") else 45.0
    return jsonify(updater.check(ttl=ttl))


@app.route("/update/apply", methods=["POST"])
def update_apply():
    """Download + verify + stage the patch; it activates on next launch."""
    info = updater.check(ttl=0)  # force a fresh check
    if not info.get("available"):
        return jsonify({"ok": False, "error": "ไม่มีอัปเดตใหม่"}), 400
    try:
        version = updater.stage(info["manifest"], info["base"])
    except Exception as e:  # noqa: BLE001
        return jsonify({"ok": False, "error": f"อัปเดตไม่สำเร็จ: {e}"}), 500
    return jsonify({"ok": True, "version": version, "restart": True})


@app.route("/update/restart", methods=["POST"])
def update_restart():
    """Relaunch the app so a staged patch is promoted — one-click, like Steam.

    The overlay is only loaded at launch, so a staged patch needs a *real*
    process restart.  We answer this request first, then a moment later spawn a
    fresh instance and hard-exit this one (which releases the single-instance
    mutex so the new one can take over).  Only meaningful for the frozen .exe.
    """
    if not getattr(sys, "frozen", False):
        return jsonify({"ok": False,
                        "error": "ใช้ได้เฉพาะตัวโปรแกรมที่ติดตั้งแล้ว (.exe)"}), 400

    def _relaunch() -> None:
        time.sleep(0.6)  # let this HTTP response reach the UI first
        flags = 0
        if os.name == "nt":
            flags = (getattr(subprocess, "DETACHED_PROCESS", 0)
                     | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
        try:
            subprocess.Popen([sys.executable, "--relaunch"],
                             close_fds=True, creationflags=flags)
        except Exception as e:  # noqa: BLE001 — keep the old instance alive on failure
            print(f"[update] relaunch failed: {e}", flush=True)
            return
        os._exit(0)  # release the mutex; the new instance promotes the patch

    threading.Thread(target=_relaunch, daemon=True).start()
    return jsonify({"ok": True})


@app.route("/debug")
def debug():
    """Quick health view (open /debug) — handy to confirm the engine is wired up
    without digging through logs."""
    st = tools.status()
    ai = llm.status()
    return jsonify({
        "version": updater.current_version(),
        "ffmpeg": st.ffmpeg or "❌ not found",
        "ffprobe": st.ffprobe or "❌ not found",
        "whisper": "✅ word-timing" if transcribe.available() else "⚠️ silence-cut fallback",
        "ai": {
            "enabled": ai["enabled"],            # True → cuts use Gemini, then fall back offline
            "model": ai["model"],
            "key_source": ai["key_source"],      # baked / config / env / none
            "mode": ("🧠 AI (Gemini) + ฐานออฟไลน์" if ai["enabled"]
                     else "✂️ ออฟไลน์ เข้าใจเนื้อหา (ยังไม่ได้ใส่คีย์ AI)"),
        },
    })


# ---------------------------------------------------------------------------
# AI (Gemini) settings — the customer's own optional key + on/off switch.
# ---------------------------------------------------------------------------
@app.route("/ai/status")
def ai_status():
    """Current AI config for the settings UI (switch state, whether a key is set,
    where to get a key). Never returns the key itself."""
    return jsonify(llm.status())


@app.route("/ai/settings", methods=["POST"])
def ai_settings():
    """Persist the customer's choices: use_ai on/off and/or their own API key.

    Body: {"use_ai": bool?, "key": str?, "model": str?}
      - key == ""  clears the stored key (→ falls back to the offline cutter).
    Returns the fresh status (no key echoed back).
    """
    body = request.get_json(silent=True) or {}
    use_ai = body.get("use_ai")
    key = body.get("key")
    model_name = body.get("model")
    st = llm.save_settings(
        use_ai=(bool(use_ai) if use_ai is not None else None),
        key=(str(key) if key is not None else None),
        model_name=(str(model_name) if model_name else None),
    )
    return jsonify(st)


@app.route("/ai/test", methods=["POST"])
def ai_test():
    """Validate the currently-saved key with a tiny Gemini request (test button)."""
    ok, message = llm.test_key()
    return jsonify({"ok": ok, "message": message}), (200 if ok else 400)


@app.route("/ai/open-key", methods=["POST"])
def ai_open_key():
    """Open the 'get a free API key' page in the real browser (reliable from the
    native window). Best-effort — the UI also tries window.open as a fallback."""
    import webbrowser
    url = llm.status().get("get_key_url", "")
    try:
        if url:
            webbrowser.open(url)
    except Exception:  # noqa: BLE001
        return jsonify({"ok": False}), 200
    return jsonify({"ok": True, "url": url})


@app.route("/status/<job_id>")
def job_status(job_id):
    job = JOBS.get(job_id)
    if not job:
        return jsonify({"error": "ไม่พบงานนี้"}), 404
    return jsonify(job.snapshot())


# ===========================================================================
#  Pipeline
# ===========================================================================


def _purge_finished_jobs(max_age_min: float = 30.0) -> None:
    """Remove work dirs of done/errored jobs older than *max_age_min* minutes."""
    now = datetime.now(timezone.utc)
    with JOBS_LOCK:
        stale = [
            j for j in JOBS.values()
            if j.status in ("done", "error")
            and (now - j.created).total_seconds() > max_age_min * 60
        ]
        for j in stale:
            shutil.rmtree(j.work_dir, ignore_errors=True)
            JOBS.pop(j.id, None)


# ===========================================================================
#  Subtitle-editor projects (Phase 1) — saved next to the delivered videos so
#  the customer can fix words / restyle / re-render without re-transcribing.
# ===========================================================================


def _clip_src(project_dir: str, clip: dict) -> str | None:
    """Absolute path of a clip's source video, or None if it's gone.

    Two shapes:
      * ``src``  — a reference to the customer's OWN file, left where it is
        (the instant import: nothing copied or transcoded).  If they move,
        rename or delete it, this returns None so callers can say so plainly.
      * ``base`` — a copy/transcode stored inside the project (older flow, and
        the fallback when a codec isn't web-playable).
    """
    ext = (clip.get("src") or "").strip()
    if ext:
        return ext if os.path.isfile(ext) else None
    base = clip.get("base")
    if base:
        inside = os.path.join(project_dir, ".project", base)
        return inside if os.path.isfile(inside) else None
    return None


MISSING_SRC = ("ไฟล์วิดีโอต้นฉบับหายไป — อาจถูกย้าย เปลี่ยนชื่อ หรือลบ "
               "(โปรเจกต์นี้อ้างอิงไฟล์เดิมในเครื่อง) กรุณานำเข้าวิดีโอใหม่")


def _project_path(pid: str) -> str | None:
    """Resolve a project id (= delivery folder name) safely under the output root."""
    root = storage.output_root()
    p = os.path.normpath(os.path.join(root, _safe_name(pid)))
    if not p.startswith(os.path.normpath(root)):
        return None
    return p if os.path.isfile(os.path.join(p, ".project", "project.json")) else None


@app.route("/projects")
def list_projects():
    """Editable subtitle projects, newest first."""
    root = storage.output_root()
    out = []
    try:
        for name in os.listdir(root):
            meta = os.path.join(root, name, ".project", "project.json")
            if os.path.isfile(meta):
                out.append({"id": name, "mtime": os.path.getmtime(meta)})
    except OSError:
        pass
    out.sort(key=lambda x: x["mtime"], reverse=True)
    return jsonify(out[:30])


@app.route("/project/<pid>")
def get_project(pid):
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    try:
        return jsonify(_read_meta(os.path.join(p, ".project", "project.json")))
    except (json.JSONDecodeError, OSError) as e:
        app.logger.error("project.json unreadable for %r: %s", pid, e)
        return jsonify({"error": "ไฟล์โปรเจกต์เสียหาย เปิดไม่ได้"}), 500


@app.route("/project/<pid>/history")
def project_history(pid):
    """Undo/redo availability, for enabling the ↶ ↷ buttons."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    return jsonify(_hist_state(os.path.basename(p)))


def _do_history(pid: str, *, redo: bool):
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    meta_path = os.path.join(p, ".project", "project.json")
    meta = _hist_step(meta_path, redo)
    state = _hist_state(os.path.basename(p))
    if meta is None:                            # nothing on that stack
        state["noop"] = True
        state["error"] = "ไม่มีอะไรให้ทำซ้ำ" if redo else "ไม่มีอะไรให้ย้อนกลับ"
        return jsonify(state), 200
    state["ok"] = True
    state["meta"] = meta
    return jsonify(state)


@app.route("/project/<pid>/undo", methods=["POST"])
def project_undo(pid):
    return _do_history(pid, redo=False)


@app.route("/project/<pid>/redo", methods=["POST"])
def project_redo(pid):
    return _do_history(pid, redo=True)


_PROXY_LOCKS: dict[str, "threading.Lock"] = {}
_PROXY_LOCKS_GUARD = threading.Lock()


def _preview_proxy(project_dir: str, src: str) -> str | None:
    """A cached, web-playable (h264 8-bit / aac) copy of a clip whose codec the
    browser can't decode (HEVC, 10-bit, VP9…), used ONLY for the editor preview so
    it never shows a black frame.  Downscaled + veryfast so it's quick to make; the
    render still uses the original source.  Returns the proxy path, or None.

    A per-file lock serialises builds so an on-demand request and the background
    warm-up never transcode the same clip twice (or race on the temp file)."""
    try:
        key = hashlib.md5(
            f"{os.path.abspath(src)}|{os.path.getmtime(src)}|{os.path.getsize(src)}"
            .encode("utf-8")).hexdigest()[:14]
    except OSError:
        return None
    pdir = os.path.join(project_dir, ".project", "proxies")
    os.makedirs(pdir, exist_ok=True)
    dst = os.path.join(pdir, f"{key}.mp4")
    if os.path.isfile(dst) and os.path.getsize(dst) > 1024:
        return dst
    with _PROXY_LOCKS_GUARD:
        lock = _PROXY_LOCKS.setdefault(dst, threading.Lock())
    with lock:
        if os.path.isfile(dst) and os.path.getsize(dst) > 1024:   # built while we waited
            return dst
        tmp = dst + ".building.mp4"
        try:
            tools.ffmpeg([
                "-y", "-i", src,
                "-vf", "scale=-2:'min(720,ih)'",      # cap height at 720 → fast, plenty for preview
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "26", "-pix_fmt", "yuv420p",
                "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", tmp,
            ], check=True, timeout=1800)
            os.replace(tmp, dst)
        except Exception:  # noqa: BLE001 — preview proxy is best-effort
            try:
                os.remove(tmp)
            except OSError:
                pass
            return None
    return dst if os.path.isfile(dst) else None


def _warm_proxies_async(project_dir: str, meta: dict) -> None:
    """Pre-build preview proxies for every non-playable timeline clip in the
    background, so the editor rarely shows black while it transcodes on first view."""
    seen, srcs = set(), []
    for it in (meta.get("timeline") or []):
        s = _tl_path(project_dir, it)
        if s and s not in seen:
            seen.add(s)
            srcs.append(s)
    if not srcs:
        return

    def _work():
        for s in srcs:
            try:
                if not editor.web_playable(s):
                    _preview_proxy(project_dir, s)
            except Exception:  # noqa: BLE001
                pass
    threading.Thread(target=_work, daemon=True).start()


def _serve_video(project_dir: str, src: str):
    """Serve a clip for the HTML5 preview — the raw file when the browser can play
    it, otherwise a cached transcoded proxy (so non-h264 clips aren't a black box)."""
    if editor.web_playable(src):
        return send_file(src, conditional=True)
    proxy = _preview_proxy(project_dir, src)
    return send_file(proxy or src, conditional=True)


@app.route("/project/<pid>/video/<int:idx>")
def project_video(pid, idx):
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    meta = _read_meta(os.path.join(p, ".project", "project.json"))
    clip = meta.get("clips", {}).get(str(idx))
    if not clip:
        return jsonify({"error": "ไม่พบคลิป"}), 404
    src = _clip_src(p, clip)
    if not src:
        return jsonify({"error": MISSING_SRC}), 410
    return _serve_video(p, src)


@app.route("/project/<pid>/asset/<path:name>")
def project_asset(pid, name):
    """Serve a music/SFX file from the project's .project dir so the editor can
    PLAY it in the preview (synced to the video)."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    safe = _safe_name(name)
    proj = os.path.join(p, ".project")
    if not safe or not os.path.isfile(os.path.join(proj, safe)):
        return jsonify({"error": "ไม่พบไฟล์"}), 404
    return send_from_directory(proj, safe, conditional=True)


def _keep_ranges(cuts, duration: float) -> list[tuple[float, float]]:
    """Complement of the user's cut-out regions over [0, duration]."""
    merged: list[list[float]] = []
    for c in sorted((max(0.0, float(c[0])), min(duration, float(c[1])))
                    for c in (cuts or []) if float(c[1]) > float(c[0])):
        if merged and c[0] <= merged[-1][1] + 0.05:
            merged[-1][1] = max(merged[-1][1], c[1])
        else:
            merged.append([c[0], c[1]])
    keeps, cur = [], 0.0
    for s, e in merged:
        if s - cur >= 0.2:
            keeps.append((cur, s))
        cur = max(cur, e)
    if duration - cur >= 0.2:
        keeps.append((cur, duration))
    return keeps


def _remap_lines_json(lines_json, keeps) -> list[dict]:
    """Shift subtitle-line times onto the new (post-cut) timeline; drop lines
    that fall inside removed regions."""
    segs, acc = [], 0.0
    for s, e in keeps:
        segs.append((s, e, acc))
        acc += e - s
    out = []
    for ln in lines_json or []:
        mid = (float(ln["start"]) + float(ln["end"])) / 2
        seg = next(((s, e, off) for s, e, off in segs if s <= mid <= e), None)
        if not seg:
            continue
        s, e, off = seg
        delta = off - s
        top = off + (e - s)
        ws = [{"s": max(off, float(w["s"]) + delta), "e": min(top, float(w["e"]) + delta),
               "t": w["t"]} for w in ln.get("words", [])]
        ws = [w for w in ws if w["e"] > w["s"]]
        if ws:
            out.append({"start": max(off, float(ln["start"]) + delta),
                        "end": min(top, float(ln["end"]) + delta), "words": ws})
    return out


def _remap_time(t: float, keeps) -> float | None:
    """Map a time on the ORIGINAL timeline onto the post-cut timeline.
    None if it falls inside a removed region."""
    acc = 0.0
    for s, e in keeps:
        if s <= t <= e:
            return acc + (t - s)
        acc += e - s
    return None


@app.route("/project/<pid>/sfx", methods=["POST"])
def project_sfx(pid):
    """Add / remove a sound effect placed at a time on the clip."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    meta_path = os.path.join(p, ".project", "project.json")
    meta = _read_meta(meta_path)
    idx = str(request.form.get("idx", 1))
    clip = meta.get("clips", {}).get(idx)
    if not clip:
        return jsonify({"error": "ไม่พบคลิป"}), 404
    sfx = clip.setdefault("sfx", [])
    rm = request.form.get("remove")
    mv = request.form.get("move")
    if mv is not None:                                   # retime by list index (drag)
        try:
            sfx[int(mv)]["at"] = max(0.0, float(request.form.get("at", 0)))
        except (ValueError, IndexError, TypeError):
            pass
    elif rm is not None:                                 # remove by list index
        try:
            entry = sfx.pop(int(rm))
            fp = os.path.join(p, ".project", entry.get("file", ""))
            if os.path.isfile(fp) and not any(s.get("file") == entry["file"] for s in sfx):
                os.remove(fp)
        except (ValueError, IndexError, OSError):
            pass
    else:
        f_up = request.files.get("sfx")
        if not f_up or not f_up.filename:
            return jsonify({"error": "ไม่พบไฟล์เสียง"}), 400
        ext = os.path.splitext(_safe_name(f_up.filename))[1] or ".mp3"
        name = f"sfx{int(time.time() * 1000) % 100000}{ext}"
        f_up.save(os.path.join(p, ".project", name))
        try:
            at = max(0.0, float(request.form.get("at", 0)))
            vol = min(2.0, max(0.05, float(request.form.get("vol", 1.0))))
        except (TypeError, ValueError):
            at, vol = 0.0, 1.0
        sfx.append({"file": name, "at": at, "vol": vol,
                    "name": _safe_name(f_up.filename)})
    _write_meta(meta_path, meta)
    return jsonify({"ok": True, "sfx": sfx})


@app.route("/project/<pid>/music", methods=["POST"])
def project_music(pid):
    """Attach / replace / remove the editor project's background music."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    meta_path = os.path.join(p, ".project", "project.json")
    meta = _read_meta(meta_path)
    f_up = request.files.get("music")
    if f_up and f_up.filename:
        ext = os.path.splitext(_safe_name(f_up.filename))[1] or ".mp3"
        dst = os.path.join(p, ".project", "music" + ext)
        f_up.save(dst)
        meta["music"] = os.path.basename(dst)
        meta["music_name"] = os.path.basename(f_up.filename)
        try:                              # length drives the timeline track width
            meta["music_dur"] = round(float(media.probe(dst).duration or 0.0), 2)
        except Exception:  # noqa: BLE001
            meta["music_dur"] = 0.0
    elif request.form.get("remove") == "true":
        meta.pop("music_name", None)
        meta.pop("music_dur", None)
        old = meta.pop("music", None)
        if old:
            try:
                os.remove(os.path.join(p, ".project", old))
            except OSError:
                pass
    try:
        meta["music_volume"] = min(1.0, max(0.05, float(request.form.get("volume", meta.get("music_volume", 0.2)))))
    except (TypeError, ValueError):
        pass
    _write_meta(meta_path, meta)
    return jsonify({"ok": True, "music": meta.get("music"), "volume": meta.get("music_volume", 0.2)})


@app.route("/voiceover/status")
def voiceover_status():
    """Voices / styles / paces + whether a key is set — for the editor panel."""
    return jsonify(voiceover.status())


@app.route("/voiceover/preview", methods=["POST"])
def voiceover_preview():
    """Speak a short fixed sample in the chosen voice/style so the customer can
    compare voices before writing a script.  Returns WAV audio (or JSON on error)."""
    body = request.get_json(silent=True) or {}
    try:
        wav = voiceover.synthesize(
            voiceover.PREVIEW_TEXT,
            voice=body.get("voice", voiceover.DEFAULT_VOICE),
            style=body.get("style", voiceover.DEFAULT_STYLE),
            pace=body.get("pace", voiceover.DEFAULT_PACE),
            temperature=body.get("temperature", voiceover.DEFAULT_TEMP))
    except voiceover.VoiceoverUnavailable as e:
        return jsonify({"error": str(e), "need_key": True}), 400
    except voiceover.VoiceoverError as e:
        return jsonify({"error": str(e)}), 502
    return Response(wav, mimetype="audio/wav")


@app.route("/voiceover/draft", methods=["POST"])
def voiceover_draft():
    """Mode A: draft a Thai sales voiceover script from typed product info."""
    body = request.get_json(silent=True) or {}
    seconds = _to_int(body.get("seconds"), 45, 10, 180)
    try:
        script = voiceover.draft_script(body.get("info", ""), target_seconds=seconds)
    except voiceover.VoiceoverUnavailable as e:
        return jsonify({"error": str(e), "need_key": True}), 400
    except voiceover.VoiceoverError as e:
        return jsonify({"error": str(e)}), 502
    return jsonify({"ok": True, "script": script})


@app.route("/project/<pid>/voiceover/transcript", methods=["POST"])
def voiceover_transcript(pid):
    """Mode B: transcribe the SELECTED timeline piece → seed the editable script box.

    Same transcription as the subtitle tab (Gemini listens to the audio) and it
    REUSES the piece's cached lines, so transcribing here after doing subs (or vice
    versa) doesn't run again — it just reads the stored lines back as text."""
    ctx, err, code = _select_piece(pid)
    if err:
        return err, code
    p, meta, meta_path, track, piece = ctx
    # want_subs=False → get the script but DON'T store subtitles on the piece
    # (customer doesn't want burned-in captions).  `segment` = how to split the subs.
    _b = request.get_json(silent=True) or {}
    want_subs = bool(_b.get("subs", True))
    segment = str(_b.get("segment", "natural"))
    lines, err, code = _piece_transcribe(p, meta, meta_path, piece,
                                         persist=want_subs, segment=segment)
    if err:
        return err, code
    script = _lines_to_text(lines)
    if not script:
        return jsonify({"error": "ไม่พบเสียงพูดในคลิป — ลองใช้ 'ร่างจากข้อมูลสินค้า' แทน"}), 400
    # Only hand back lines when the caller wants them applied as subtitles.
    return jsonify({"ok": True, "script": script, "tid": piece.get("id"),
                    "lines": lines if want_subs else []})


@app.route("/project/<pid>/voiceover", methods=["POST"])
def project_voiceover(pid):
    """Generate an AI voiceover for one clip (or remove it).  The WAV is stored in
    the project so the render step lays it over the video (muting the original)."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    body = request.get_json(silent=True) or {}
    idx = str(body.get("idx", 1))
    meta_path = os.path.join(p, ".project", "project.json")
    meta = _read_meta(meta_path)
    clip = meta.get("clips", {}).get(idx)
    if not clip:
        return jsonify({"error": "ไม่พบคลิป"}), 404

    name = f"voiceover_{idx}.wav"
    dst = os.path.join(p, ".project", name)

    if body.get("remove") is True:
        for k in ("voiceover", "voiceover_volume", "voiceover_mute_original",
                  "voiceover_orig_volume", "vo_script", "vo_voice", "vo_style", "vo_pace"):
            clip.pop(k, None)
        try:
            os.remove(dst)
        except OSError:
            pass
        _write_meta(meta_path, meta)
        return jsonify({"ok": True, "voiceover": None})

    try:
        voiceover.synthesize_to_file(
            body.get("script", ""), dst,
            voice=body.get("voice", voiceover.DEFAULT_VOICE),
            style=body.get("style", voiceover.DEFAULT_STYLE),
            pace=body.get("pace", voiceover.DEFAULT_PACE),
            temperature=body.get("temperature", voiceover.DEFAULT_TEMP))
    except voiceover.VoiceoverUnavailable as e:
        return jsonify({"error": str(e), "need_key": True}), 400
    except voiceover.VoiceoverError as e:
        return jsonify({"error": str(e)}), 502

    clip["voiceover"] = name
    clip["voiceover_volume"] = _to_float(body.get("volume"), 1.0, 0.1, 2.0)
    clip["voiceover_mute_original"] = bool(body.get("mute_original", True))
    clip["voiceover_orig_volume"] = _to_float(body.get("orig_volume"), 0.15, 0.0, 1.0)
    # Remember the inputs so the panel can reload them next time.
    clip["vo_script"] = str(body.get("script", ""))[:voiceover.MAX_CHARS]
    clip["vo_voice"] = str(body.get("voice", voiceover.DEFAULT_VOICE))
    clip["vo_style"] = str(body.get("style", voiceover.DEFAULT_STYLE))
    clip["vo_pace"] = str(body.get("pace", voiceover.DEFAULT_PACE))
    clip["vo_temp"] = voiceover.clean_temp(body.get("temperature", voiceover.DEFAULT_TEMP))
    _write_meta(meta_path, meta)
    # Cache-buster so the editor's <audio> re-fetches the fresh take.
    return jsonify({"ok": True, "voiceover": name,
                    "url": f"/project/{pid}/asset/{name}?v={int(time.time())}"})


@app.route("/project/<pid>/voiceover/to-timeline", methods=["POST"])
def project_voiceover_to_timeline(pid):
    """Turn a generated voiceover into a normal audio-track clip (like an imported
    sound), so the customer can keep/drag/trim it.  Copies it to its own file and
    clears the render-time voiceover so it isn't applied twice."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    body = request.get_json(silent=True) or {}
    idx = str(body.get("idx", 1))
    meta_path = os.path.join(p, ".project", "project.json")
    meta = _read_meta(meta_path)
    clip = (meta.get("clips") or {}).get(idx)
    if not clip:
        return jsonify({"error": "ไม่พบคลิป"}), 404
    vo = clip.get("voiceover")
    src = os.path.join(p, ".project", vo) if vo else ""
    if not vo or not os.path.isfile(src):
        return jsonify({"error": "ยังไม่มีเสียงพากย์ให้เพิ่ม"}), 400
    # Independent copy so re-generating/removing the voiceover won't affect the clip.
    name = f"aud{int(time.time() * 1000) % 1000000}.wav"
    dst = os.path.join(p, ".project", name)
    try:
        shutil.copy2(src, dst)
    except OSError as e:
        return jsonify({"error": f"เพิ่มเสียงไม่สำเร็จ: {e}"}), 500
    try:
        dur = round(float(media.probe(dst).duration or 0.0), 2)
    except Exception:  # noqa: BLE001
        dur = 0.0
    items = _audio_clips(p, meta, clip)
    items.append({"id": uuid.uuid4().hex[:8], "file": name, "name": "เสียงพากย์ AI",
                  "at": max(0.0, _to_float(body.get("at"), 0.0, 0.0, 86400.0)),
                  "in": 0.0, "out": dur, "srcdur": dur,
                  "vol": _to_float(clip.get("voiceover_volume"), 1.0, 0.05, 4.0)})
    # It's now a timeline clip — drop the render-time overlay (and its file).
    for k in ("voiceover", "voiceover_volume", "voiceover_mute_original", "voiceover_orig_volume"):
        clip.pop(k, None)
    try:
        os.remove(src)
    except OSError:
        pass
    _write_meta(meta_path, meta)
    return jsonify({"ok": True, "audio": _audio_view(p, items)})


# ---------------------------------------------------------------------------
# Media library — the clips available to a project.  Like CapCut, entries just
# POINT at the customer's files (nothing copied), so adding is instant.
# ---------------------------------------------------------------------------
def _load_meta(project_dir: str) -> dict:
    return _read_meta(os.path.join(project_dir, ".project", "project.json"))


def _save_meta(project_dir: str, meta: dict) -> None:
    _write_meta(os.path.join(project_dir, ".project", "project.json"), meta)


def _save_meta_raw(project_dir: str, meta: dict) -> None:
    """Persist a normalisation done on READ (legacy-track / audio migration) —
    not a user edit, so it must NOT create an undo-history entry."""
    _write_meta_raw(os.path.join(project_dir, ".project", "project.json"), meta)


@app.route("/project/<pid>/media")
def project_media_list(pid):
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    lib = _load_meta(p).get("media", [])
    return jsonify({"media": [
        {**m, "missing": not os.path.isfile(m.get("path", ""))} for m in lib
    ]})


@app.route("/project/<pid>/media/add", methods=["POST"])
def project_media_add(pid):
    """Pick one or more videos with the native dialog → add them to the library."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    paths, err = _run_picker("--pick-files")
    if err:
        return jsonify({"ok": False, "error": err}), 500
    if not paths:
        return jsonify({"ok": False, "cancelled": True})

    meta = _load_meta(p)
    lib = meta.setdefault("media", [])
    known = {m.get("path") for m in lib}
    added = 0
    for path in paths:
        if not os.path.isfile(path) or path in known:
            continue
        try:
            dur = float(media.probe(path).duration or 0.0)
        except Exception:  # noqa: BLE001
            dur = 0.0
        lib.append({"id": uuid.uuid4().hex[:8], "path": path,
                    "name": os.path.basename(path), "dur": round(dur, 2),
                    "playable": editor.web_playable(path)})
        added += 1
    _save_meta(p, meta)
    return jsonify({"ok": True, "added": added, "media": lib})


@app.route("/project/<pid>/media/<mid>/thumb")
def project_media_thumb(pid, mid):
    """One cached JPEG poster frame per library item."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    item = next((m for m in _load_meta(p).get("media", []) if m.get("id") == mid), None)
    if not item:
        return jsonify({"error": "ไม่พบมีเดีย"}), 404
    src = item.get("path", "")
    if not os.path.isfile(src):
        return jsonify({"error": MISSING_SRC}), 410
    tdir = os.path.join(p, ".project", "thumbs")
    os.makedirs(tdir, exist_ok=True)
    dst = os.path.join(tdir, f"{_safe_name(mid)}.jpg")
    if not os.path.isfile(dst):
        at = min(1.0, max(0.0, float(item.get("dur") or 0) / 2))
        try:
            tools.ffmpeg(["-y", "-ss", f"{at:.2f}", "-i", src, "-frames:v", "1",
                          "-vf", "scale=240:-2", dst], check=True, timeout=120)
        except tools.ToolError:
            return jsonify({"error": "สร้างภาพตัวอย่างไม่สำเร็จ"}), 500
    return send_file(dst, conditional=True)


@app.route("/project/<pid>/media/remove", methods=["POST"])
def project_media_remove(pid):
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    mid = str((request.get_json(silent=True) or {}).get("id", ""))
    meta = _load_meta(p)
    meta["media"] = [m for m in meta.get("media", []) if m.get("id") != mid]
    _save_meta(p, meta)
    try:
        os.remove(os.path.join(p, ".project", "thumbs", f"{_safe_name(mid)}.jpg"))
    except OSError:
        pass
    return jsonify({"ok": True, "media": meta["media"]})


# ---------------------------------------------------------------------------
# Timeline — the ordered clips on the track.  It is an ASSEMBLY layer in front
# of the existing pipeline: render concatenates the items, then cuts/subtitles/
# voiceover/adjust run on the result exactly as before.
# ---------------------------------------------------------------------------
def _tl_path(project_dir: str, item: dict) -> str | None:
    """Resolve a timeline item to a file on disk (or None if it's gone)."""
    return _clip_src(project_dir, item)


def _timeline(project_dir: str, meta: dict, idx: str = "1") -> list:
    """The track's items, seeding a single-item track from a legacy project."""
    tl = meta.get("timeline")
    if tl is not None:
        return tl
    clip = (meta.get("clips") or {}).get(idx) or {}
    src = _clip_src(project_dir, clip)
    if not src:
        meta["timeline"] = []
        return meta["timeline"]
    try:
        dur = float(media.probe(src).duration or 0.0)
    except Exception:  # noqa: BLE001
        dur = 0.0
    meta["timeline"] = [{"id": uuid.uuid4().hex[:8], "src": src,
                         "name": os.path.basename(src),
                         "in": 0.0, "out": round(dur, 2),
                         "srcdur": round(dur, 2)}]
    return meta["timeline"]


def _timeline_view(project_dir: str, tl: list) -> list:
    out = []
    for it in tl:
        try:
            _vol = float(it.get("vol", 1))
        except (TypeError, ValueError):
            _vol = 1.0
        out.append({**it, "lines": it.get("lines") or [], "vol": _vol,
                    "missing": not _tl_path(project_dir, it),
                    "srcdur": float(it.get("srcdur") or it.get("out") or 0),
                    "dur": round(max(0.0, float(it.get("out") or 0) - float(it.get("in") or 0)), 2)})
    return out


def _shift_line(ln: dict, delta: float) -> dict:
    """Copy a subtitle line with every timestamp shifted by *delta* seconds."""
    return {"start": max(0.0, float(ln.get("start", 0)) + delta),
            "end": max(0.0, float(ln.get("end", 0)) + delta),
            "words": [{"s": max(0.0, float(w.get("s", 0)) + delta),
                       "e": max(0.0, float(w.get("e", 0)) + delta),
                       "t": w.get("t", "")} for w in (ln.get("words") or [])]}


def _migrate_subs_to_pieces(meta: dict) -> bool:
    """One-time: move a legacy global subtitle list (clips[idx].lines, in track
    time) onto the timeline pieces (piece-local time), split by each piece's track
    range.  Best-effort (aligns for the common non-reordered case); the originals
    are kept as clips[idx].lines_legacy so nothing is lost.  Returns True if meta
    changed."""
    if meta.get("subs_per_piece"):
        return False
    tl = meta.get("timeline")
    if tl is None:                              # not a timeline project yet
        return False
    meta["subs_per_piece"] = True
    for it in tl:
        it.setdefault("lines", [])
    legacy = []
    for clip in (meta.get("clips") or {}).values():
        legacy += list(clip.get("lines") or [])
    if legacy:
        legacy.sort(key=lambda l: float(l.get("start", 0)))
        acc = 0.0
        for it in tl:
            d = max(0.0, float(it.get("out") or 0) - float(it.get("in") or 0))
            start, end = acc, acc + d
            acc = end
            mine = [_shift_line(ln, -start) for ln in legacy
                    if start - 1e-6 <= float(ln.get("start", 0)) < end + 1e-6]
            if mine:
                it["lines"] = mine
        for clip in (meta.get("clips") or {}).values():
            if clip.get("lines"):
                clip["lines_legacy"] = clip.pop("lines")   # backup, out of render's way
    return True


@app.route("/project/<pid>/timeline")
def project_timeline(pid):
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    meta = _load_meta(p)
    tl = _timeline(p, meta)
    _migrate_subs_to_pieces(meta)
    _save_meta_raw(p, meta)                  # migration on read → not undoable
    _warm_proxies_async(p, meta)             # pre-build previews for HEVC/10-bit clips
    return jsonify({"timeline": _timeline_view(p, tl)})


@app.route("/project/<pid>/timeline/<tid>/volume", methods=["POST"])
def project_timeline_volume(pid, tid):
    """Set one clip's own-audio volume (0–2, 1 = 100%)."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    meta_path = os.path.join(p, ".project", "project.json")
    meta = _read_meta(meta_path)
    track = _timeline(p, meta)
    piece = next((it for it in track if it.get("id") == tid), None)
    if not piece:
        return jsonify({"error": "ไม่พบคลิปที่เลือก"}), 404
    try:
        vol = min(2.0, max(0.0, float((request.get_json(silent=True) or {}).get("vol", 1))))
    except (TypeError, ValueError):
        vol = 1.0
    piece["vol"] = round(vol, 3)
    _write_meta(meta_path, meta)
    return jsonify({"ok": True, "tid": tid, "vol": piece["vol"]})


@app.route("/project/<pid>/timeline/<tid>/trim", methods=["POST"])
def project_timeline_trim(pid, tid):
    """Trim one piece by dragging its edges (CapCut-style).  Only in/out change —
    lossless + instant — clamped to [0, srcdur] with a minimum length."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    meta_path = os.path.join(p, ".project", "project.json")
    meta = _read_meta(meta_path)
    track = _timeline(p, meta)
    piece = next((it for it in track if it.get("id") == tid), None)
    if not piece:
        return jsonify({"error": "ไม่พบคลิปที่เลือก"}), 404
    body = request.get_json(silent=True) or {}
    MIN = 0.2
    cur_in = float(piece.get("in") or 0.0)
    cur_out = float(piece.get("out") or 0.0)
    srcdur = float(piece.get("srcdur") or piece.get("out") or 0.0)
    def _num(key, default):
        try:
            return float(body[key]) if body.get(key) is not None else default
        except (TypeError, ValueError):
            return default
    new_in = _num("in", cur_in)
    new_out = _num("out", cur_out)
    if srcdur > 0:
        new_in = max(0.0, min(new_in, srcdur - MIN))
        new_out = max(new_in + MIN, min(new_out, srcdur))
    else:                                    # unknown source length → only shrink
        new_in = max(0.0, new_in)
        new_out = max(new_in + MIN, new_out)
    piece["in"] = round(new_in, 3)
    piece["out"] = round(new_out, 3)
    _write_meta(meta_path, meta)
    return jsonify({"ok": True, "timeline": _timeline_view(p, track)})


def _valid_line_style(d):
    """Sanitise a per-chunk caption style override → keep only known keys / safe
    types (this dict feeds the render burn, so keep junk out)."""
    if not isinstance(d, dict):
        return None
    out = {}
    if d.get("style"):
        out["style"] = _valid_sub_style(str(d["style"]))
    if d.get("font") and str(d["font"]) in _SUB_FONTS:
        out["font"] = str(d["font"])
    if d.get("anim") in ("pop", "fade", "slide", "none"):
        out["anim"] = d["anim"]
    if d.get("position"):
        out["position"] = _valid_sub_pos(str(d["position"]))
    for f in ("size", "offset"):
        if d.get(f) is not None:
            try:
                out[f] = float(d[f])
            except (TypeError, ValueError):
                pass
    for f in ("fill", "outline"):
        v = d.get(f)
        if isinstance(v, str) and v.strip():
            out[f] = v.strip()
    return out or None


@app.route("/project/<pid>/timeline/<tid>/subs", methods=["POST"])
def project_timeline_subs(pid, tid):
    """Persist the edited subtitle lines (piece-local time) for one piece.

    A line may carry its own ``style`` dict — a per-chunk caption-style override
    on top of the clip style (sanitised here, merged at render time)."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    meta_path = os.path.join(p, ".project", "project.json")
    meta = _read_meta(meta_path)
    track = _timeline(p, meta)
    piece = next((it for it in track if it.get("id") == tid), None)
    if not piece:
        return jsonify({"error": "ไม่พบคลิปที่เลือก"}), 404
    body = request.get_json(silent=True) or {}
    lines = body.get("lines") if isinstance(body.get("lines"), list) else []
    for ln in lines:                          # keep each chunk's own style, sanitised
        if isinstance(ln, dict):
            s = _valid_line_style(ln.get("style"))
            if s:
                ln["style"] = s
            else:
                ln.pop("style", None)
    piece["lines"] = lines
    meta["subs_per_piece"] = True
    _write_meta(meta_path, meta)
    return jsonify({"ok": True, "tid": tid, "count": len(piece["lines"])})


@app.route("/project/<pid>/timeline/<tid>/voscript", methods=["POST"])
def project_timeline_voscript(pid, tid):
    """Persist one piece's AI-voiceover SCRIPT so each clip remembers its own text
    (the voiceover audio itself is still one per video)."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    meta_path = os.path.join(p, ".project", "project.json")
    meta = _read_meta(meta_path)
    piece = next((it for it in _timeline(p, meta) if it.get("id") == tid), None)
    if not piece:
        return jsonify({"error": "ไม่พบคลิปที่เลือก"}), 404
    piece["vo_script"] = str((request.get_json(silent=True) or {}).get("script", ""))
    _write_meta(meta_path, meta)
    return jsonify({"ok": True, "tid": tid})


@app.route("/project/<pid>/timeline/<tid>/adjust", methods=["POST"])
def project_timeline_adjust(pid, tid):
    """Persist one piece's image adjust (brightness/contrast/saturation/sharpen) so
    each clip keeps its own colour grade."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    meta_path = os.path.join(p, ".project", "project.json")
    meta = _read_meta(meta_path)
    piece = next((it for it in _timeline(p, meta) if it.get("id") == tid), None)
    if not piece:
        return jsonify({"error": "ไม่พบคลิปที่เลือก"}), 404
    piece["adjust"] = editor.clean_adjust((request.get_json(silent=True) or {}).get("adjust") or {})
    _write_meta(meta_path, meta)
    return jsonify({"ok": True, "tid": tid})


# Caption-style fields that can be set per timeline clip.
_STYLE_FIELDS = ("style", "font", "anim", "position", "size", "fill", "outline", "offset")


def _piece_style(clip, it) -> dict:
    """A clip's effective caption style: its own field, else the project-level one."""
    out = {}
    for f in _STYLE_FIELDS:
        v = it.get(f) if it.get(f) is not None else clip.get(f)
        if v is not None:
            out[f] = v
    return out


@app.route("/project/<pid>/timeline/<tid>/style", methods=["POST"])
def project_timeline_style(pid, tid):
    """Persist one piece's caption style so each clip can look different."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    meta_path = os.path.join(p, ".project", "project.json")
    meta = _read_meta(meta_path)
    piece = next((it for it in _timeline(p, meta) if it.get("id") == tid), None)
    if not piece:
        return jsonify({"error": "ไม่พบคลิปที่เลือก"}), 404
    body = request.get_json(silent=True) or {}
    if body.get("style"):
        piece["style"] = _valid_sub_style(str(body["style"]))
    for f in ("font", "anim", "position"):
        if body.get(f):
            piece[f] = str(body[f])
    if "size" in body:
        try:
            piece["size"] = min(1.6, max(0.6, float(body["size"])))
        except (TypeError, ValueError):
            pass
    if "offset" in body:
        try:
            piece["offset"] = min(0.35, max(-0.06, float(body["offset"] or 0.0)))
        except (TypeError, ValueError):
            pass
    for f in ("fill", "outline"):
        if f in body:
            v = str(body.get(f) or "")
            piece[f] = v if re.fullmatch(r"#[0-9a-fA-F]{6}", v) else None
    _write_meta(meta_path, meta)
    return jsonify({"ok": True, "tid": tid})


@app.route("/project/<pid>/timeline/add", methods=["POST"])
def project_timeline_add(pid):
    """Append a library clip to the track — instant, nothing is encoded."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    mid = str((request.get_json(silent=True) or {}).get("media", ""))
    meta = _load_meta(p)
    item = next((m for m in meta.get("media", []) if m.get("id") == mid), None)
    if not item:
        return jsonify({"error": "ไม่พบมีเดียในคลัง"}), 404
    if not os.path.isfile(item.get("path", "")):
        return jsonify({"error": MISSING_SRC}), 410
    tl = _timeline(p, meta)
    _dur = round(float(item.get("dur") or 0.0), 2)
    tl.append({"id": uuid.uuid4().hex[:8], "src": item["path"],
               "media": item["id"],          # so the block can show its poster
               "name": item.get("name") or os.path.basename(item["path"]),
               "in": 0.0, "out": _dur,
               "srcdur": _dur})              # full length — split pieces keep it
    _save_meta(p, meta)
    return jsonify({"ok": True, "timeline": _timeline_view(p, tl)})


@app.route("/project/<pid>/timeline/split", methods=["POST"])
def project_timeline_split(pid):
    """Split the clip under the playhead into two pieces (CapCut's Ctrl+B).

    Body: {"at": <seconds on the TRACK>}.  Both halves keep pointing at the same
    source file — only their in/out change — so splitting is instant and lossless.
    """
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    try:
        at = float((request.get_json(silent=True) or {}).get("at", -1))
    except (TypeError, ValueError):
        at = -1.0
    meta = _load_meta(p)
    tl = _timeline(p, meta)
    if not tl:
        return jsonify({"error": "ยังไม่มีคลิปในไทม์ไลน์"}), 400

    acc = 0.0
    for i, it in enumerate(tl):
        span = max(0.0, float(it.get("out") or 0) - float(it.get("in") or 0))
        if at > acc + 0.15 and at < acc + span - 0.15:      # inside this piece
            local = float(it.get("in") or 0) + (at - acc)
            # Both halves must remember the FULL source length — the waveform is
            # drawn for the whole file and cropped to each piece's in/out.
            if not it.get("srcdur"):
                try:
                    it["srcdur"] = round(float(media.probe(_tl_path(p, it)).duration or 0.0), 2)
                except Exception:  # noqa: BLE001
                    it["srcdur"] = float(it.get("out") or 0.0)
            right = {**it, "id": uuid.uuid4().hex[:8], "in": round(local, 3)}
            it["out"] = round(local, 3)
            # Split subtitles at the cut too (piece-local): lines before the cut
            # stay left, lines after move to the right half (re-based to 0).
            s = at - acc
            old_lines = it.get("lines") or []
            it["lines"] = [ln for ln in old_lines if float(ln.get("start", 0)) < s]
            right["lines"] = [_shift_line(ln, -s) for ln in old_lines
                              if float(ln.get("start", 0)) >= s]
            tl.insert(i + 1, right)
            _save_meta(p, meta)
            return jsonify({"ok": True, "timeline": _timeline_view(p, tl)})
        acc += span
    return jsonify({"error": "เลื่อนหัวเล่นไปกลางคลิปก่อนแบ่ง (ห้ามตรงหัว/ท้ายพอดี)"}), 400


@app.route("/project/<pid>/timeline/<tid>/wave")
def project_timeline_wave(pid, tid):
    """Waveform strip for a clip — shows where it's loud or quiet, like CapCut.

    Rendered for the WHOLE source file and cached under a hash of its path, so
    every split piece of the same video reuses one image (the browser just crops
    it to the piece's in/out).
    """
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    item = next((it for it in _timeline(p, _load_meta(p)) if it.get("id") == tid), None)
    if not item:
        return jsonify({"error": "ไม่พบคลิปในไทม์ไลน์"}), 404
    src = _tl_path(p, item)
    if not src:
        return jsonify({"error": MISSING_SRC}), 410
    if not editor._has_audio(src):
        return jsonify({"error": "คลิปนี้ไม่มีเสียง"}), 404

    wdir = os.path.join(p, ".project", "waves")
    os.makedirs(wdir, exist_ok=True)
    key = hashlib.md5(os.path.abspath(src).encode("utf-8")).hexdigest()[:12]
    dst = os.path.join(wdir, f"{key}.png")
    if not os.path.isfile(dst):
        try:
            tools.ffmpeg([
                "-y", "-i", src, "-filter_complex",
                "showwavespic=s=1600x120:colors=#7ee8c0|#7ee8c0:split_channels=0",
                "-frames:v", "1", dst,
            ], check=True, timeout=600)
        except tools.ToolError:
            return jsonify({"error": "สร้างกราฟเสียงไม่สำเร็จ"}), 500
    return send_file(dst, conditional=True)


# ---------------------------------------------------------------------------
# Audio clips — one editable model for music AND sound effects: every piece can
# be dragged along the timeline, trimmed and split, just like a video clip.
# ---------------------------------------------------------------------------
def _audio_clips(project_dir: str, meta: dict, clip: dict) -> list:
    """The clip's audio items, migrating the old music/sfx fields on first read."""
    if clip.get("audio") is not None:
        return clip["audio"]
    items: list = []

    def _dur(fname: str) -> float:
        try:
            return round(float(media.probe(
                os.path.join(project_dir, ".project", fname)).duration or 0.0), 2)
        except Exception:  # noqa: BLE001
            return 0.0

    music = meta.get("music")
    if music:
        d = float(meta.get("music_dur") or 0) or _dur(music)
        items.append({"id": uuid.uuid4().hex[:8], "file": music,
                      "name": meta.get("music_name") or music,
                      "at": 0.0, "in": 0.0, "out": d, "srcdur": d,
                      "vol": float(meta.get("music_volume") or 0.2)})
    for s in (clip.get("sfx") or []):
        d = float(s.get("dur") or 0) or _dur(s.get("file", ""))
        items.append({"id": uuid.uuid4().hex[:8], "file": s.get("file", ""),
                      "name": s.get("name") or s.get("file", ""),
                      "at": float(s.get("at") or 0.0), "in": 0.0, "out": d,
                      "srcdur": d, "vol": float(s.get("vol") or 1.0)})
    # Retire the legacy fields — clip["audio"] is now the single source of truth
    # (leaving meta["music"] behind made the editor keep playing a deleted song).
    for k in ("music", "music_volume", "music_dur", "music_name"):
        meta.pop(k, None)
    clip.pop("sfx", None)
    clip["audio"] = items
    return items


def _audio_view(project_dir: str, items: list) -> list:
    out = []
    for a in items:
        f = os.path.join(project_dir, ".project", a.get("file", ""))
        out.append({**a, "missing": not os.path.isfile(f),
                    "dur": round(max(0.0, float(a.get("out") or 0) - float(a.get("in") or 0)), 2)})
    return out


def _audiolib(meta: dict) -> list:
    """Reusable audio SOURCE files for this project (drag onto the track like the
    video library).  Placing one just references its file in .project/."""
    return meta.setdefault("audiolib", [])


def _audiolib_view(project_dir: str, lib: list) -> list:
    out = []
    for m in lib:
        f = os.path.join(project_dir, ".project", m.get("file", ""))
        out.append({**m, "missing": not os.path.isfile(f)})
    return out


def _audio_file_used(meta: dict, fname: str) -> bool:
    """True if a .project/ audio file is still referenced by the library or any
    clip — so removing one user of it must NOT delete the shared file."""
    if not fname:
        return False
    if any(m.get("file") == fname for m in meta.get("audiolib", []) or []):
        return True
    for c in (meta.get("clips") or {}).values():
        if any(a.get("file") == fname for a in (c.get("audio") or [])):
            return True
    return False


def _audio_ctx(pid: str, idx_default: str = "1"):
    """Resolve (project_dir, meta, clip, items) or an error response."""
    p = _project_path(pid)
    if not p:
        return None, jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    body = request.get_json(silent=True) or {}
    idx = str(body.get("idx", idx_default))
    meta = _load_meta(p)
    clip = (meta.get("clips") or {}).get(idx)
    if not clip:
        return None, jsonify({"error": "ไม่พบคลิป"}), 404
    return (p, meta, clip, _audio_clips(p, meta, clip), body), None, None


@app.route("/project/<pid>/audio")
def project_audio_list(pid):
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    meta = _load_meta(p)
    clip = (meta.get("clips") or {}).get(str(request.args.get("idx", 1)))
    if not clip:
        return jsonify({"audio": []})
    items = _audio_clips(p, meta, clip)
    _save_meta_raw(p, meta)                  # migration on read → not undoable
    return jsonify({"audio": _audio_view(p, items)})


@app.route("/project/<pid>/audio/add", methods=["POST"])
def project_audio_add(pid):
    """Upload an audio file and drop it on the track at ``at`` seconds."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    meta = _load_meta(p)
    idx = str(request.form.get("idx", 1))
    clip = (meta.get("clips") or {}).get(idx)
    if not clip:
        return jsonify({"error": "ไม่พบคลิป"}), 404
    items = _audio_clips(p, meta, clip)

    # Place an existing library sound (dragged from the audio library) — no upload,
    # the placed clip just references the library file already in .project/.
    libid = request.form.get("libid")
    if libid:
        src = next((m for m in _audiolib(meta) if m.get("id") == str(libid)), None)
        if not src:
            return jsonify({"error": "ไม่พบเสียงในคลัง"}), 404
        d = float(src.get("dur") or 0.0)
        items.append({"id": uuid.uuid4().hex[:8], "file": src.get("file", ""),
                      "name": src.get("name") or src.get("file", ""),
                      "at": max(0.0, _to_float(request.form.get("at"), 0.0, 0.0, 86400.0)),
                      "in": 0.0, "out": d, "srcdur": d,
                      "vol": _to_float(request.form.get("vol"), 1.0, 0.05, 4.0)})
        _save_meta(p, meta)
        return jsonify({"ok": True, "audio": _audio_view(p, items)})

    f_up = request.files.get("audio")
    if not f_up or not f_up.filename:
        return jsonify({"error": "ไม่พบไฟล์เสียง"}), 400
    ext = os.path.splitext(_safe_name(f_up.filename))[1] or ".mp3"
    name = f"aud{int(time.time() * 1000) % 1000000}{ext}"
    dst = os.path.join(p, ".project", name)
    f_up.save(dst)
    try:
        dur = round(float(media.probe(dst).duration or 0.0), 2)
    except Exception:  # noqa: BLE001
        dur = 0.0
    items.append({"id": uuid.uuid4().hex[:8], "file": name,
                  "name": _safe_name(f_up.filename),
                  "at": max(0.0, _to_float(request.form.get("at"), 0.0, 0.0, 86400.0)),
                  "in": 0.0, "out": dur, "srcdur": dur,
                  "vol": _to_float(request.form.get("vol"), 1.0, 0.05, 4.0)})
    _save_meta(p, meta)
    return jsonify({"ok": True, "audio": _audio_view(p, items)})


@app.route("/project/<pid>/audio/update", methods=["POST"])
def project_audio_update(pid):
    """Drag along the timeline (``at``) or change a clip's volume."""
    ctx, err, code = _audio_ctx(pid)
    if err:
        return err, code
    p, meta, clip, items, body = ctx
    a = next((x for x in items if x.get("id") == str(body.get("id", ""))), None)
    if not a:
        return jsonify({"error": "ไม่พบคลิปเสียง"}), 404
    if "at" in body:
        a["at"] = round(max(0.0, _to_float(body.get("at"), 0.0, 0.0, 86400.0)), 3)
    if "vol" in body:
        a["vol"] = _to_float(body.get("vol"), 1.0, 0.05, 4.0)
    if "in" in body or "out" in body:                 # drag the clip edges (trim)
        srcdur = float(a.get("srcdur") or a.get("out") or 0.0)
        MIN = 0.2
        ni = _to_float(body.get("in"), float(a.get("in") or 0.0), 0.0, 86400.0)
        no = _to_float(body.get("out"), float(a.get("out") or 0.0), 0.0, 86400.0)
        if srcdur > 0:
            ni = max(0.0, min(ni, srcdur - MIN))
            no = max(ni + MIN, min(no, srcdur))
        else:
            ni = max(0.0, ni); no = max(ni + MIN, no)
        a["in"] = round(ni, 3)
        a["out"] = round(no, 3)
    _save_meta(p, meta)
    return jsonify({"ok": True, "audio": _audio_view(p, items)})


@app.route("/project/<pid>/audio/split", methods=["POST"])
def project_audio_split(pid):
    """Cut an audio clip in two at ``at`` seconds on the timeline."""
    ctx, err, code = _audio_ctx(pid)
    if err:
        return err, code
    p, meta, clip, items, body = ctx
    at = _to_float(body.get("at"), -1.0, -1.0, 86400.0)
    a = next((x for x in items if x.get("id") == str(body.get("id", ""))), None)
    if not a:
        return jsonify({"error": "เลือกคลิปเสียงก่อน"}), 404
    start = float(a.get("at") or 0)
    span = max(0.0, float(a.get("out") or 0) - float(a.get("in") or 0))
    if not (start + 0.1 < at < start + span - 0.1):
        return jsonify({"error": "เลื่อนหัวเล่นไปกลางคลิปเสียงก่อนตัด"}), 400
    local = float(a.get("in") or 0) + (at - start)
    right = {**a, "id": uuid.uuid4().hex[:8], "in": round(local, 3), "at": round(at, 3)}
    a["out"] = round(local, 3)
    items.insert(items.index(a) + 1, right)
    _save_meta(p, meta)
    return jsonify({"ok": True, "audio": _audio_view(p, items)})


@app.route("/project/<pid>/audio/remove", methods=["POST"])
def project_audio_remove(pid):
    ctx, err, code = _audio_ctx(pid)
    if err:
        return err, code
    p, meta, clip, items, body = ctx
    aid = str(body.get("id", ""))
    keep = [x for x in items if x.get("id") != aid]
    gone = [x for x in items if x.get("id") == aid]
    clip["audio"] = keep
    for g in gone:                     # drop the file only when nothing else uses it
        f = g.get("file", "")
        if f and not _audio_file_used(meta, f):   # checks other clips + the library
            try:
                os.remove(os.path.join(p, ".project", f))
            except OSError:
                pass
    _save_meta(p, meta)
    return jsonify({"ok": True, "audio": _audio_view(p, keep)})


@app.route("/project/<pid>/audiolib")
def project_audiolib_list(pid):
    """The reusable audio library — cards the editor drags onto the track."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    return jsonify({"audio": _audiolib_view(p, _audiolib(_load_meta(p)))})


@app.route("/project/<pid>/audiolib/add", methods=["POST"])
def project_audiolib_add(pid):
    """Upload one or more audio files INTO the library (no timeline placement)."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    ups = [f for f in request.files.getlist("audio") if f and f.filename]
    if not ups:
        return jsonify({"error": "ไม่พบไฟล์เสียง"}), 400
    meta = _load_meta(p)
    lib = _audiolib(meta)
    added = 0
    for f_up in ups:
        ext = os.path.splitext(_safe_name(f_up.filename))[1] or ".mp3"
        name = f"aud{int(time.time() * 1000) % 1000000}{added}{ext}"
        dst = os.path.join(p, ".project", name)
        f_up.save(dst)
        try:
            dur = round(float(media.probe(dst).duration or 0.0), 2)
        except Exception:  # noqa: BLE001
            dur = 0.0
        lib.append({"id": uuid.uuid4().hex[:8], "file": name,
                    "name": _safe_name(f_up.filename), "dur": dur})
        added += 1
    _save_meta(p, meta)
    return jsonify({"ok": True, "added": added, "audio": _audiolib_view(p, lib)})


@app.route("/project/<pid>/audiolib/remove", methods=["POST"])
def project_audiolib_remove(pid):
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    lid = str((request.get_json(silent=True) or {}).get("id", ""))
    meta = _load_meta(p)
    lib = _audiolib(meta)
    gone = [m for m in lib if m.get("id") == lid]
    meta["audiolib"] = [m for m in lib if m.get("id") != lid]
    for g in gone:                     # delete the file only if no clip still uses it
        f = g.get("file", "")
        if f and not _audio_file_used(meta, f):
            try:
                os.remove(os.path.join(p, ".project", f))
            except OSError:
                pass
    _save_meta(p, meta)
    return jsonify({"ok": True, "audio": _audiolib_view(p, meta["audiolib"])})


@app.route("/project/<pid>/asset-wave/<path:name>")
def project_asset_wave(pid, name):
    """Waveform for a music / SFX file stored in the project (own audio track)."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    safe = _safe_name(name)
    src = os.path.join(p, ".project", safe)
    if not safe or not os.path.isfile(src):
        return jsonify({"error": "ไม่พบไฟล์"}), 404
    wdir = os.path.join(p, ".project", "waves")
    os.makedirs(wdir, exist_ok=True)
    dst = os.path.join(wdir, f"a_{hashlib.md5(safe.encode()).hexdigest()[:12]}.png")
    if not os.path.isfile(dst):
        try:
            tools.ffmpeg([
                "-y", "-i", src, "-filter_complex",
                "showwavespic=s=1600x120:colors=#6aa9ff|#6aa9ff:split_channels=0",
                "-frames:v", "1", dst,
            ], check=True, timeout=600)
        except tools.ToolError:
            return jsonify({"error": "สร้างกราฟเสียงไม่สำเร็จ"}), 500
    return send_file(dst, conditional=True)


@app.route("/project/<pid>/timeline/reorder", methods=["POST"])
def project_timeline_reorder(pid):
    """Persist a new clip order (drag-and-drop on the track)."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    order = (request.get_json(silent=True) or {}).get("order") or []
    meta = _load_meta(p)
    tl = _timeline(p, meta)
    by_id = {it.get("id"): it for it in tl}
    new = [by_id[i] for i in order if i in by_id]
    if len(new) != len(tl):                  # ignore a stale/partial order
        return jsonify({"error": "ลำดับไม่ตรงกับคลิปในไทม์ไลน์"}), 400
    meta["timeline"] = new
    _save_meta(p, meta)
    return jsonify({"ok": True, "timeline": _timeline_view(p, new)})


@app.route("/project/<pid>/timeline/remove", methods=["POST"])
def project_timeline_remove(pid):
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    tid = str((request.get_json(silent=True) or {}).get("id", ""))
    meta = _load_meta(p)
    tl = [it for it in _timeline(p, meta) if it.get("id") != tid]
    meta["timeline"] = tl
    _save_meta(p, meta)
    return jsonify({"ok": True, "timeline": _timeline_view(p, tl)})


@app.route("/project/<pid>/timeline/<tid>/video")
def project_timeline_video(pid, tid):
    """Stream one track item — the preview plays these back to back."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    item = next((it for it in _timeline(p, _load_meta(p)) if it.get("id") == tid), None)
    if not item:
        return jsonify({"error": "ไม่พบคลิปในไทม์ไลน์"}), 404
    src = _tl_path(p, item)
    if not src:
        return jsonify({"error": MISSING_SRC}), 410
    return _serve_video(p, src)


def _lines_to_text(lines_json) -> str:
    """Flatten stored subtitle lines into a plain paragraph (for the voiceover box)."""
    parts = []
    for ln in (lines_json or []):
        words = ln.get("words") or []
        t = ("".join(str(w.get("t", "")) for w in words).strip() if words
             else str(ln.get("text", "")).strip())
        if t:
            parts.append(t)
    return " ".join(parts).strip()


SEG_MODES = ("none", "natural", "words", "sentence")


def _spread_lines_if_broken(lines_json, dur):
    """Gemini's audio timestamps are sometimes unusable — every line clipped to a
    near-zero duration and piled at the clip start.  When that's clearly the case
    (most lines are near-instant), lay the lines out across the clip (time ∝ text
    length) so they're at least readable; the user can then drag them to fine-tune.
    Real, usable timings are left untouched."""
    lines = lines_json or []
    if not lines or not dur or dur <= 0.3:
        return lines_json

    def _txt(l):
        return "".join(str(w.get("t", "")) for w in (l.get("words") or [])) or str(l.get("text", ""))

    tiny = sum(1 for l in lines
               if (float(l.get("end", 0)) - float(l.get("start", 0))) < 0.15)
    if tiny < max(2, len(lines) * 0.5):
        return lines_json                       # durations look real → keep them

    lens = [max(1, len(_txt(l).strip())) for l in lines]
    total = sum(lens) or 1
    out, acc = [], 0.0
    for l, wlen in zip(lines, lens):
        s = round(acc / total * dur, 2)
        acc += wlen
        e = round(min(dur, acc / total * dur - 0.05), 2)
        if e <= s:
            e = round(min(dur, s + 0.2), 2)
        t = _txt(l).strip()
        out.append({"start": s, "end": e, "words": [{"s": s, "e": e, "t": t}]})
    return out


_SENT_END = "ฯ.!?…"    # ฯ . ! ? …


def _is_thai_combining(ch: str) -> bool:
    """Thai vowel/tone marks that must never start a line (they cling to a base)."""
    o = ord(ch)
    return o == 0x0E31 or 0x0E33 <= o <= 0x0E3A or 0x0E47 <= o <= 0x0E4E


def _lines_from_script(text: str, mode: str = "natural") -> list[str]:
    """Split a voiceover SCRIPT (free Thai/EN text) into readable subtitle-sized
    line strings.  No word timing — the caller lays them out across the clip."""
    import re
    text = (text or "").replace("\r", "").strip()
    if not text:
        return []
    if mode == "none":
        return [" ".join(text.split())]
    max_chars = {"words": 24, "sentence": 60}.get(mode, 42)
    # 1) hard boundaries: newlines always; sentence enders too in 'sentence' mode.
    segs: list[str] = []
    for para in re.split(r"\n+", text):
        if not para.strip():
            continue
        if mode == "sentence":
            for s in re.split(r"(?<=[" + _SENT_END + r"])\s+", para):
                s = " ".join(s.split()).strip()
                if s:
                    segs.append(s)
        else:
            segs.append(" ".join(para.split()).strip())
    # 2) enforce max length: greedy on spaces, hard-chunk dense (space-less) Thai.
    out: list[str] = []
    for s in segs:
        while len(s) > max_chars:
            cut = s.rfind(" ", 0, max_chars + 1)
            if cut <= 0:
                cut = max_chars                 # no space to break on → hard cut
                while cut > 1 and _is_thai_combining(s[cut]):
                    cut -= 1                     # don't strand a trailing vowel/tone mark
                while cut > 1 and 0x0E40 <= ord(s[cut - 1]) <= 0x0E44:
                    cut -= 1                     # keep a leading vowel (เ แ โ ใ ไ) with its base
            out.append(s[:cut].strip())
            s = s[cut:].strip()
        if s:
            out.append(s)
    return [x for x in out if x]


def _layout_lines_across(texts: list[str], dur: float) -> list[dict]:
    """Lay line strings out across a clip (start/end, time ∝ text length).  If the
    duration is unknown, give each line a fixed ~2.2s slot so it's still usable."""
    texts = [t.strip() for t in texts if t and t.strip()]
    if not texts:
        return []
    if not dur or dur <= 0.3:
        out, acc = [], 0.0
        for t in texts:
            s, e = round(acc, 2), round(acc + 2.2, 2)
            acc += 2.2
            out.append({"start": s, "end": e, "words": [{"s": s, "e": e, "t": t}]})
        return out
    lens = [max(1, len(t)) for t in texts]
    total = sum(lens) or 1
    out, acc = [], 0.0
    for t, wlen in zip(texts, lens):
        s = round(acc / total * dur, 2)
        acc += wlen
        e = round(min(dur, acc / total * dur - 0.05), 2)
        if e <= s:
            e = round(min(dur, s + 0.3), 2)
        out.append({"start": s, "end": e, "words": [{"s": s, "e": e, "t": t}]})
    return out


@app.route("/project/<pid>/timeline/<tid>/subs_from_script", methods=["POST"])
def project_timeline_subs_from_script(pid, tid):
    """Turn one piece's voiceover SCRIPT text into subtitle lines (no audio/AI):
    split into readable lines + lay them out across a duration; user drags/edits after.

    When ``idx`` is given and that clip has a generated voiceover, the lines are laid
    out across the VOICEOVER length (probed from its WAV) instead of the video clip —
    so the captions line up with the narration, which may be shorter/longer than the
    footage."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    meta_path = os.path.join(p, ".project", "project.json")
    meta = _read_meta(meta_path)
    piece = next((it for it in _timeline(p, meta) if it.get("id") == tid), None)
    if not piece:
        return jsonify({"error": "ไม่พบคลิปที่เลือก"}), 404
    body = request.get_json(silent=True) or {}
    script = str(body.get("script", "")).strip()
    if not script:
        return jsonify({"error": "ยังไม่มีบทพูด — พิมพ์หรือให้ AI ร่างบทก่อน"}), 400
    mode = body.get("segment") if body.get("segment") in SEG_MODES else "natural"
    try:
        dur = float(body.get("dur") or 0)
    except (TypeError, ValueError):
        dur = 0.0
    if dur <= 0:
        dur = max(0.0, float(piece.get("out") or 0) - float(piece.get("in") or 0))
    # Prefer the voiceover's own length so the subtitles match the spoken narration.
    matched_vo = False
    idx = body.get("idx")
    if idx is not None:
        clip = meta.get("clips", {}).get(str(idx))
        vo = clip.get("voiceover") if clip else None
        vo_path = os.path.join(p, ".project", vo) if vo else None
        if vo_path and os.path.isfile(vo_path):
            try:
                vo_dur = float(media.probe(vo_path).duration or 0.0)
            except Exception:  # noqa: BLE001
                vo_dur = 0.0
            if vo_dur > 0.3:
                dur, matched_vo = vo_dur, True
    texts = _lines_from_script(script, mode)
    if not texts:
        return jsonify({"error": "แยกบทเป็นบรรทัดไม่ได้"}), 400
    lines_json = _layout_lines_across(texts, dur)
    piece["lines"] = lines_json
    meta["subs_per_piece"] = True
    _write_meta(meta_path, meta)
    return jsonify({"ok": True, "tid": tid, "lines": lines_json, "count": len(lines_json),
                    "matched_voiceover": matched_vo, "dur": round(dur, 2)})


def _piece_transcribe(p, meta, meta_path, piece, persist=True, segment="natural"):
    """Get one piece's timed subtitle lines, transcribing ONCE (Gemini listens to
    the audio, else offline Whisper) and CACHING them on the piece.  Shared by the
    subtitle tab and the voiceover 'ถอดเสียงเดิม' so whichever runs first, the other
    reuses it — the same clip is never transcribed twice.  Returns
    ``(lines_json, err, code)`` — on success ``err`` is None.

    ``persist=False`` transcribes for the text only (voiceover script) WITHOUT
    storing the lines as the piece's subtitles — so a customer who doesn't want
    burned-in captions gets the script but no subtitle track.

    ``segment`` is the user's "การแบ่งซับไตเติล" (none/natural/words/sentence) — the
    cache is reused only when it was built with the SAME split, so picking a new
    split re-transcribes (for the script path the split is irrelevant, so any cache
    is reused)."""
    if segment not in SEG_MODES:
        segment = "natural"
    cached = piece.get("lines")
    if isinstance(cached, list) and cached and (
            not persist or piece.get("seg_mode", "natural") == segment):
        return cached, None, None                      # same split → reuse
    if not transcribe.available() and not (llm and llm.api_key()):
        return None, jsonify({"error": "ถอดเสียงไม่ได้ในเครื่องนี้ (ไม่พบเครื่องมือถอดเสียง)"}), 503
    src = _tl_path(p, piece)
    if not src:
        return None, jsonify({"error": MISSING_SRC}), 410
    t_in = max(0.0, float(piece.get("in") or 0.0))
    t_out = float(piece.get("out") or 0.0)
    dur = (t_out - t_in) if t_out > t_in else None
    with tempfile.TemporaryDirectory(prefix="autocut_subs_") as td:
        wav = editor.extract_audio_segment(src, os.path.join(td, "seg.wav"),
                                           start=t_in, duration=dur)
        if not wav:
            return None, jsonify({"error": "คลิปนี้ไม่มีเสียงพูดให้ถอด"}), 400
        try:
            lines = captions.generate(wav, segment=segment)
        except Exception as e:  # noqa: BLE001
            return None, jsonify({"error": f"ถอดเสียงไม่สำเร็จ: {e}"}), 500
    if not lines:
        return None, jsonify({"error": "ไม่พบเสียงพูดในคลิปนี้ — พิมพ์เองได้"}), 400
    lines_json = captions.lines_to_json(lines)         # piece-local times
    lines_json = _spread_lines_if_broken(lines_json, dur)   # rescue garbage Gemini timing
    if persist:
        piece["lines"] = lines_json
        piece["seg_mode"] = segment
        meta["subs_per_piece"] = True
        _write_meta(meta_path, meta)                    # cache it (undoable)
    return lines_json, None, None


def _select_piece(pid):
    """Resolve (p, meta, meta_path, track, piece) from the request's ``tid``.
    Returns (ctx, err, code); ctx is None on error."""
    p = _project_path(pid)
    if not p:
        return None, jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    tid = str((request.get_json(silent=True) or {}).get("tid", "")).strip()
    if not tid:
        return None, jsonify({"error": "เลือกคลิปในไทม์ไลน์ก่อน (คลิกคลิปให้ขึ้นกรอบฟ้า)"}), 400
    meta_path = os.path.join(p, ".project", "project.json")
    meta = _read_meta(meta_path)
    track = _timeline(p, meta)
    piece = next((it for it in track if it.get("id") == tid), None)
    if not piece:
        return None, jsonify({"error": "ไม่พบคลิปที่เลือก"}), 404
    return (p, meta, meta_path, track, piece), None, None


@app.route("/project/<pid>/subtitles/generate", methods=["POST"])
def project_subtitles(pid):
    """Transcribe the SELECTED timeline piece → subtitle lines cached on that piece.

    Per-piece (piece-local time) so subs travel with the clip on reorder.  Reuses
    the cache if the clip was already transcribed (here or from the voiceover tab)
    so the same audio is never transcribed twice."""
    ctx, err, code = _select_piece(pid)
    if err:
        return err, code
    p, meta, meta_path, track, piece = ctx
    segment = str((request.get_json(silent=True) or {}).get("segment", "natural"))
    lines, err, code = _piece_transcribe(p, meta, meta_path, piece, segment=segment)
    if err:
        return err, code
    return jsonify({"ok": True, "tid": piece.get("id"), "lines": lines,
                    "count": len(lines)})


@app.route("/project/<pid>/deliver/<int:idx>")
def project_deliver(pid, idx):
    """Stream the i-th DELIVERED video (with subs burned) for the in-app preview."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    vdir = os.path.join(p, "Video")
    try:
        files = sorted(f for f in os.listdir(vdir)
                       if not f.lower().endswith(".srt"))
    except OSError:
        return jsonify({"error": "ไม่พบวิดีโอ"}), 404
    if not files or idx < 1 or idx > len(files):
        return jsonify({"error": "ไม่พบคลิป"}), 404
    return send_from_directory(vdir, files[idx - 1], conditional=True)


@app.route("/fonts/<path:fname>")
def serve_font(fname):
    """Bundled caption fonts for the browser's style/font previews."""
    d = captions._fonts_dir()
    if not d:
        return jsonify({"error": "no fonts"}), 404
    return send_from_directory(d, fname, conditional=True)


@app.route("/project/<pid>/save", methods=["POST"])
def save_project(pid):
    """Persist edited lines + style for one clip."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    body = request.get_json(silent=True) or {}
    idx = str(body.get("idx", 1))
    meta_path = os.path.join(p, ".project", "project.json")
    meta = _read_meta(meta_path)
    clip = meta.get("clips", {}).get(idx)
    if not clip:
        return jsonify({"error": "ไม่พบคลิป"}), 404
    if isinstance(body.get("lines"), list):
        clip["lines"] = body["lines"]
    for k in ("style", "position", "font", "anim"):
        if body.get(k):
            clip[k] = body[k]
    if body.get("size"):
        try:
            clip["size"] = min(1.6, max(0.6, float(body["size"])))
        except (TypeError, ValueError):
            pass
    # Custom caption colours (hex overrides; empty string clears → preset colour).
    for k in ("fill", "outline"):
        if k in body:
            v = str(body.get(k) or "")
            clip[k] = v if re.fullmatch(r"#[0-9a-fA-F]{6}", v) else None
    if body.get("crf"):             # export quality (lower = better/bigger file)
        try:
            clip["crf"] = min(30, max(16, int(body["crf"])))
        except (TypeError, ValueError):
            pass
    if body.get("aspect"):          # output canvas (คุณภาพ & ขนาดวิดีโอ)
        clip["aspect"] = _valid_aspect(str(body["aspect"]))
    if body.get("resolution"):
        clip["resolution"] = str(body["resolution"]) if str(body["resolution"]) in (
            "auto", "720", "1080", "4k") else "auto"
    if body.get("fps"):
        clip["fps"] = str(body["fps"]) if str(body["fps"]) in ("auto", "24", "30", "60") else "auto"
    if body.get("fmt"):             # output container (project-wide) — from the Export dialog
        f = str(body["fmt"]).lower()
        if f in ("mp4", "mov"):
            meta["fmt"] = f
    if "offset" in body:            # fine vertical position (fraction of height)
        try:
            clip["offset"] = min(0.35, max(-0.06, float(body["offset"] or 0.0)))
        except (TypeError, ValueError):
            pass
    if isinstance(body.get("adjust"), dict):  # image colour/sharpness sliders
        clip["adjust"] = editor.clean_adjust(body["adjust"])
    if isinstance(body.get("cuts"), list):        # timeline: regions to remove
        clip["cuts"] = [[float(c[0]), float(c[1])] for c in body["cuts"]
                        if isinstance(c, (list, tuple)) and len(c) == 2]
    if isinstance(body.get("splits"), list):      # timeline: split markers (visual)
        try:
            clip["splits"] = sorted(float(s) for s in body["splits"])
        except (TypeError, ValueError):
            pass
    if "smooth" in body:
        clip["smooth"] = bool(body["smooth"])     # L-cut transition at joins
    _write_meta(meta_path, meta)
    return jsonify({"ok": True})


@app.route("/project/<pid>/render", methods=["POST"])
def render_project(pid):
    """Re-burn the edited subtitles onto the stored clean video → a new file in
    Video/ named "<ชื่อ> (แก้ไข).mp4".  Small job, so it runs synchronously."""
    p = _project_path(pid)
    if not p:
        return jsonify({"error": "ไม่พบโปรเจกต์"}), 404
    body = request.get_json(silent=True) or {}
    idx = str(body.get("idx", 1))
    meta = _read_meta(os.path.join(p, ".project", "project.json"))
    clip = meta.get("clips", {}).get(idx)
    if not clip:
        return jsonify({"error": "ไม่พบคลิป"}), 404
    track = _timeline(p, meta)
    _save_meta_raw(p, meta)                   # seeding on read → not undoable
    if not track or any(not _tl_path(p, it) for it in track):
        return jsonify({"error": MISSING_SRC}), 410
    base_video = _tl_path(p, track[0])
    fmt = meta.get("fmt", "mp4")
    stem = meta.get("name", "Project") + ("" if len(meta.get("clips", {})) == 1
                                          else f" {int(idx):02d}")
    # Where the finished file lands: the customer-chosen export folder, else the
    # project's own Video/ (automatic).
    _exp = _export_dir()
    out = os.path.join(_exp if _exp and os.path.isdir(_exp) else os.path.join(p, "Video"),
                       f"{stem} (แก้ไข).{fmt}")
    # Subtitles are per-piece (piece-local time) — offset each piece's lines by
    # its position on the assembled track so they burn in the right place, and
    # travel correctly when pieces were reordered.  Fall back to the legacy
    # global clip.lines for projects that pre-date per-piece subs.
    if meta.get("subs_per_piece") or any(it.get("lines") for it in track):
        acc, lines_json = 0.0, []
        for it in track:
            st = _piece_style(clip, it)             # this clip's own caption style
            for ln in (it.get("lines") or []):
                shifted = _shift_line(ln, acc)
                own = ln.get("style") if isinstance(ln.get("style"), dict) else None
                eff = {**st, **own} if own else st  # per-chunk override wins over the clip style
                if eff:
                    shifted["style"] = eff          # resolved per line in captions._burn_overlay
                lines_json.append(shifted)
            acc += max(0.0, float(it.get("out") or 0) - float(it.get("in") or 0))
    else:
        lines_json = clip.get("lines") or []
    cuts = clip.get("cuts") or []

    with tempfile.TemporaryDirectory(prefix="autocut_edit_",
                                     ignore_cleanup_errors=True) as td:
        src = base_video

        # 0a. Assemble the track: several clips → one video, matched to the first
        #     clip's canvas/fps so the seams are clean.  Everything after this
        #     (cuts, subtitles, voiceover, music…) works on the assembled result.
        # Also needed for a SINGLE item that was split/trimmed (in/out ≠ whole file).
        def _trimmed(it) -> bool:
            src_path = _tl_path(p, it)
            if float(it.get("in") or 0) > 0.05:
                return True
            try:
                whole = float(media.probe(src_path).duration or 0.0)
            except Exception:  # noqa: BLE001
                return False
            out_t = float(it.get("out") or 0.0)
            return bool(out_t) and out_t < whole - 0.05

        def _has_vol(it) -> bool:
            try:
                return abs(float(it.get("vol", 1)) - 1.0) > 1e-3
            except (TypeError, ValueError):
                return False

        # Per-clip colour grade: a piece uses its own adjust, else the old
        # project-level one (clip.adjust), else none.
        def _eff_adjust(it) -> dict:
            return it.get("adjust") or clip.get("adjust") or {}

        def _has_adjust(it) -> bool:
            return not editor.is_default_adjust(_eff_adjust(it))

        has_adjust = any(_has_adjust(it) for it in track)   # any clip needs grading?

        if len(track) > 1 or (track and (_trimmed(track[0]) or _has_vol(track[0]))) \
                or any(_has_vol(it) for it in track) or has_adjust:
            try:
                info0 = media.probe(base_video)
                canvas0 = (int(info0.width or 1080), int(info0.height or 1920))
                fps0 = int(round(info0.fps or 30))
                parts = []
                for n, it in enumerate(track):
                    normed = os.path.join(td, f"tl{n:02d}.{fmt}")
                    # Each item carries its own in/out — that's how split pieces
                    # are stored, so trim while normalising.  Its per-clip volume
                    # is baked in here too.
                    t_in = max(0.0, float(it.get("in") or 0.0))
                    t_out = float(it.get("out") or 0.0)
                    try:
                        _vol = float(it.get("vol", 1))
                    except (TypeError, ValueError):
                        _vol = 1.0
                    media.normalize(_tl_path(p, it), normed, canvas0, fps=fps0, crf=20,
                                    start=t_in,
                                    duration=(t_out - t_in) if t_out > t_in else None,
                                    vol=_vol)
                    eff = _eff_adjust(it)                    # this clip's own colour grade
                    if not editor.is_default_adjust(eff):
                        graded = os.path.join(td, f"tl{n:02d}g.{fmt}")
                        res = editor.apply_filters(normed, graded, adjust=eff, fmt=fmt, crf=20)
                        if os.path.abspath(res) != os.path.abspath(normed):
                            normed = graded
                    parts.append(normed)
                joined = os.path.join(td, f"track.{fmt}")
                editor.concat(parts, joined, fmt=fmt)
                src = joined
            except Exception as e:  # noqa: BLE001
                return jsonify({"error": f"ต่อคลิปในไทม์ไลน์ไม่สำเร็จ: {e}"}), 500


        # 1. Timeline: drop the cut-out regions (smooth = L-cut audio transition).
        if cuts:
            try:                       # probe *src* — it's longer than base_video
                dur = float(media.probe(src).duration or 0.0)   # of the assembled track
            except Exception:  # noqa: BLE001
                dur = 0.0
            keeps = _keep_ranges(cuts, dur) if dur else []
            if not keeps:
                return jsonify({"error": "ตัดออกหมดทั้งคลิป — เหลือช่วงไว้บ้างนะครับ"}), 400
            parts = editor.cut_clips(src, [analyze.Clip(s, e) for s, e in keeps], td,
                                     prefix="edit", fmt=fmt)
            joined = os.path.join(td, f"joined.{fmt}")
            overlap = 0.5 if clip.get("smooth", True) and len(parts) > 1 else 0.0
            editor.concat(parts, joined, fmt=fmt, audio_overlap=overlap)
            src = joined
            lines_json = _remap_lines_json(lines_json, keeps)
            # SFX times were placed on the original timeline — shift them too.
            for s in clip.get("sfx") or []:
                s["at"] = _remap_time(float(s.get("at", 0)), keeps)
            clip["sfx"] = [s for s in clip.get("sfx") or [] if s["at"] is not None]

        crf = min(30, max(16, int(clip.get("crf") or 20)))

        # 2. Canvas (คุณภาพ & ขนาดวิดีโอ): aspect / resolution / fps — before the
        #    subtitles so captions are laid out on the final frame.
        aspect = clip.get("aspect") or "auto"
        resolution = clip.get("resolution") or "auto"
        fps_sel = str(clip.get("fps") or "auto")
        if aspect != "auto" or resolution != "auto" or fps_sel != "auto":
            try:
                info = media.probe(src)
                canvas = media.resolve_canvas([info], aspect, resolution)
                fps_out = int(fps_sel) if fps_sel != "auto" else int(round(info.fps or 30))
                reframed = os.path.join(td, f"reframed.{fmt}")
                media.normalize(src, reframed, canvas, fps=fps_out, crf=crf)
                src = reframed
            except Exception:  # noqa: BLE001 — reframe must not sink the render
                pass

        # (Image adjust is now applied per-clip during assembly above — has_adjust
        #  was computed there.)

        # 3. Subtitles (skip cleanly when the project has none).
        lines = captions.lines_from_json(lines_json)
        if lines:
            styled = os.path.join(td, f"styled.{fmt}")
            res = captions.burn(src, style=clip.get("style", "clean"),
                                position=clip.get("position", "bottom"),
                                font=clip.get("font", "kanit"),
                                anim=clip.get("anim", "pop"),
                                size=float(clip.get("size", 1.0)),
                                fill=clip.get("fill") or None,
                                outline_color=clip.get("outline") or None,
                                offset=float(clip.get("offset") or 0.0),
                                crf=crf,
                                export_srt=bool(clip.get("export_srt")),
                                lines=lines, out_path=styled)
            if os.path.abspath(res) != os.path.abspath(src):
                src = styled
        elif not cuts and not has_adjust and not (
                _audio_clips(p, meta, clip) or clip.get("voiceover")
                or len(track) > 1
                or aspect != "auto" or resolution != "auto" or fps_sel != "auto"):
            return jsonify({"error": "ไม่มีอะไรให้เรนเดอร์ — แก้ซับ ตัดช่วง ปรับภาพ แทรกคลิป หรือใส่เสียงก่อน"}), 400

        # 3.5 AI voiceover — replace the speaker's voice with the generated
        #     narration (mutes the original by default), before music ducks under it.
        vo = clip.get("voiceover")
        if vo and os.path.isfile(os.path.join(p, ".project", vo)):
            voiced = os.path.join(td, f"voiced.{fmt}")
            res = editor.add_voiceover(
                src, os.path.join(p, ".project", vo), voiced, fmt=fmt,
                mute_original=bool(clip.get("voiceover_mute_original", True)),
                original_volume=float(clip.get("voiceover_orig_volume", 0.0)),
                voice_volume=float(clip.get("voiceover_volume", 1.0)))
            if os.path.abspath(res) != os.path.abspath(src):
                src = voiced

        # 4. Audio clips (music + effects) — each trimmed to its in/out and laid
        #    at its own spot on the timeline, mixed under the existing sound.
        audio_items = [
            {"path": os.path.join(p, ".project", a.get("file", "")),
             "at": float(a.get("at") or 0), "in": float(a.get("in") or 0),
             "out": float(a.get("out") or 0), "vol": float(a.get("vol") or 1.0)}
            for a in _audio_clips(p, meta, clip)
        ]
        if audio_items:
            mixed = os.path.join(td, f"mixed.{fmt}")
            res = editor.add_audio(src, audio_items, mixed, fmt=fmt)
            if os.path.abspath(res) != os.path.abspath(src):
                src = mixed

        try:
            # Editing-first projects (/editor/new) have no Video/ dir yet — the
            # AutoCut pipeline makes it, but an uploaded-to-edit project doesn't.
            os.makedirs(os.path.dirname(out), exist_ok=True)
            shutil.copy2(src, out)
        except OSError as e:
            return jsonify({"error": f"บันทึกไฟล์ไม่สำเร็จ: {e}"}), 500

    try:                                    # pop the file manager AT the new file
        target = os.path.abspath(out)
        folder = os.path.dirname(target)
        if os.name == "nt":
            # explorer.exe uses NON-standard argument parsing: to highlight a file,
            # the path after "/select," must be a SINGLE quoted token.  Passing a
            # list makes subprocess quote the whole "/select,<path>" chunk, which
            # explorer misreads whenever the path has spaces/Thai — it then silently
            # opens the default Documents folder (the bug users hit).  Pass one
            # verbatim command line with only the PATH quoted, and fall back to just
            # opening the containing folder if the file isn't there.
            if os.path.isfile(target):
                subprocess.Popen(f'explorer /select,"{target}"')
            else:
                os.startfile(folder)
        elif sys.platform == "darwin":
            subprocess.Popen(["open", "-R", target])
        else:
            subprocess.Popen(["xdg-open", folder])
    except Exception:  # noqa: BLE001
        pass
    return jsonify({"ok": True, "file": os.path.basename(out)})


# ===========================================================================
#  Helpers
# ===========================================================================
def _safe_name(name: str | None) -> str:
    if not name:
        return ""
    return os.path.basename(name).replace("\\", "_").replace("/", "_")


def _project_base(name: str | None) -> str:
    """A clean, Windows-safe base name for the project folder & clip files.

    Strips characters illegal in filenames, collapses whitespace, caps the
    length, and falls back to ``"Project"`` when the customer leaves it blank.
    """
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "", (name or "")).strip(" .")
    name = re.sub(r"\s+", " ", name)
    return name[:60] or "Project"


def _natural_key(path: str):
    """Sort key so 'clip2' < 'clip10' (numbers compared as numbers)."""
    name = os.path.basename(path).lower()
    return [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", name)]


def _to_int(value, default, lo, hi):
    try:
        return max(lo, min(hi, int(value)))
    except (TypeError, ValueError):
        return default


def _to_float(value, default, lo, hi):
    try:
        return max(lo, min(hi, float(value)))
    except (TypeError, ValueError):
        return default


def _valid_format(fmt: str) -> str:
    return fmt if fmt in editor.FORMATS else "mp4"


def _valid_lj_mode(m: str) -> str:
    return "j" if str(m).lower().startswith("j") else "l"


def _valid_aggr(a: str) -> str:
    return a if a in ("gentle", "medium", "strong") else "medium"


# Output quality / size validators.
_CRF = {"high": 18, "medium": 24, "saver": 28}  # high = sharp, large (the only UI option now)


def _valid_aspect(a: str) -> str:
    return a if a in ("auto", "16:9", "9:16", "1:1", "4:3", "3:4") else "auto"


# Subtitle option validators (keep in sync with SUB_PRESETS in index.html).
_SUB_STYLES = ("clean", "box", "pop", "neon", "karaoke", "impact", "boxYellow", "fire")


def _valid_sub_style(s: str) -> str:
    return s if s in _SUB_STYLES else "clean"


def _valid_sub_pos(s: str) -> str:
    return s if s in ("bottom", "center", "top") else "bottom"


def _valid_sub_seg(s: str) -> str:
    return s if s in ("natural", "words", "sentence") else "natural"


_SUB_FONTS = ("kanit", "prompt", "mali", "itim", "noto")


def _valid_sub_font(s: str) -> str:
    return s if s in _SUB_FONTS else "kanit"


def _valid_sub_anim(s: str) -> str:
    return s if s in ("pop", "fade", "slide", "none") else "pop"


def _valid_resolution(r: str) -> str:
    return r if str(r).lower() in ("auto", "720", "1080", "4k") else "auto"


def _valid_fps(f: str) -> int:
    return int(f) if str(f) in ("24", "30", "60") else 30


# ===========================================================================
#  Run
# ===========================================================================
if __name__ == "__main__":
    st = tools.status()
    port = int(os.environ.get("AUTOCUT_PORT") or os.environ.get("PORT") or 5000)
    print("=" * 56)
    print("  AI-SmartSale backend")
    print(f"  ffmpeg : {st.ffmpeg or 'NOT FOUND'}")
    print(f"  ai     : {'whisper' if transcribe.available() else 'silence-fallback'} ({WHISPER_MODEL})")
    print(f"  เปิดเว็บที่ >> http://localhost:{port} <<")
    print("=" * 56)
    app.run(host="0.0.0.0", port=port, threaded=True)
